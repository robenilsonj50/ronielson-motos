# Assinatura fixa do APK (GitHub Actions)

**Por que:** o *ID do aparelho* (usado nos códigos de ativação) e a atualização "por cima" dependem do APK ser assinado
sempre com a **mesma chave**. Se o GitHub gera uma chave nova a cada build, o ID muda e os códigos antigos deixam de servir.

O `app/build.gradle` já está preparado: ele só usa a chave fixa quando as variáveis abaixo existirem. Sem elas, o build continua como antes.

## 1) Criar a chave (uma vez só, no computador)
```
keytool -genkeypair -v -keystore ronielson.jks -alias ronielson -keyalg RSA -keysize 2048 -validity 10000
```
Guarde o arquivo `ronielson.jks` e as senhas em lugar seguro (backup!). **Se perder, não dá para atualizar o app dos clientes.**

## 2) Converter para texto (Base64)
- Linux/Mac: `base64 -w0 ronielson.jks > keystore.b64`
- Windows (PowerShell): `[Convert]::ToBase64String([IO.File]::ReadAllBytes("ronielson.jks")) > keystore.b64`

## 3) Cadastrar os Secrets no GitHub
Repositório → Settings → Secrets and variables → Actions → New repository secret:
`KEYSTORE_BASE64` (conteúdo do keystore.b64), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (ex.: ronielson), `KEY_PASSWORD`.

## 4) Acrescentar este passo no workflow, ANTES do passo "Compilar APK"
```yaml
      - name: Preparar chave de assinatura
        run: |
          echo "${{ secrets.KEYSTORE_BASE64 }}" | base64 -d > "$RUNNER_TEMP/keystore.jks"
          echo "KEYSTORE_PATH=$RUNNER_TEMP/keystore.jks" >> "$GITHUB_ENV"
          echo "KEYSTORE_PASSWORD=${{ secrets.KEYSTORE_PASSWORD }}" >> "$GITHUB_ENV"
          echo "KEY_ALIAS=${{ secrets.KEY_ALIAS }}" >> "$GITHUB_ENV"
          echo "KEY_PASSWORD=${{ secrets.KEY_PASSWORD }}" >> "$GITHUB_ENV"
```
Observação: a primeira vez que o APK passar a ser assinado com a chave fixa, o Android não deixa instalar por cima de um APK
assinado com outra chave. Faça **backup pelo app**, desinstale a versão antiga e instale a nova (restaure o backup depois).
Dali em diante, todas as versões instalam por cima, mantendo os dados.

# Ronielson Motos — v0.8

## O que há de novo
**Ordens de serviço:** orçamento → aprovação → OS → concluída → entregue; peças do estoque (ou escaneadas) dentro da OS com
baixa automática; desconto; mecânico; pagamentos parciais; garantia; próxima revisão; **PDF** com logo (orçamento/OS) e envio por **WhatsApp**;
**fotos antes/depois** (câmera).
**Clientes e motos:** busca por placa e **histórico completo da moto** (com selo de garantia e próxima revisão).
**Lembretes de revisão:** lista de quem está para revisar/atrasado, mensagem pronta no WhatsApp (editável em Ajustes).
**Estoque:** alerta de mínimo, margem de lucro, lista de reposição (copiar/enviar), edição de peças.
**Financeiro (dono):** caixa com categorias, **fiado/a receber** (com cobrança no WhatsApp), **contas a pagar**, **fechamento de caixa** (com PDF) e **lucro por período**.
**Mecânicos:** % de comissão sobre a mão de obra, relatório e pagamento de comissões.
**PIN do dono / modo funcionário:** esconde caixa, financeiro, custos e ajustes; recuperação do PIN por código do administrador.
**Ajustes:** dados da oficina (cabeçalho do PDF), garantia/lembretes padrão, assinatura (ativar/renovar código), backup, termos de uso e LGPD, relatório de erros, aviso de atualização.

## Não mudou (de propósito)
O armazenamento continua **igual**: `localStorage`, mesma chave (`oficinaOS_v01`). Dados e backups da versão anterior abrem normalmente
(são completados automaticamente com os campos novos). Quando for ligar ao Supabase, o ponto de troca é `RM.load()` / `RM.save()` em `assets/js/core.js`.
(A permissão de internet já foi adicionada ao manifesto para isso.)

## Configure antes de vender — `app/src/main/assets/js/config.js`
`adminWhatsapp`, `pixKey`, `pixName`, `valor` (tela de bloqueio) e, se quiser aviso de atualização, `versionUrl` (veja `docs/version.json.exemplo`).

## Estrutura
`assets/index.html` (esqueleto) · `assets/css/app.css` · `assets/js/`: `core` (dados/migração) · `domain` (regras de negócio) · `ui` (telas/modais) ·
`pages-ops` (visão geral, OS, clientes, lembretes) · `pages-fin` (estoque, financeiro, mecânicos) · `pages-admin` (ajustes) · `print` · `photos` · `license` · `legal` · `config`.
Java novo: `PhotoBridge.java` (fotos), `PrintBridge.java` (PDF), mais `verifyPinReset` e `getAppVersion` na ponte de licença.

## Atenção
- As **fotos** ficam no aparelho (pasta privada do app) e **não** vão dentro do arquivo de backup.
- Os termos de uso/privacidade são um **modelo**: peça revisão de um advogado antes de comercializar.
- Veja `docs/ASSINATURA-FIXA-DO-APK.md` (ID do aparelho estável entre versões).
- Histórico das correções anteriores: `docs/historico/`.

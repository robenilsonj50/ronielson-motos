/* photos.js — fotos antes/depois da OS (arquivos ficam no aparelho; o JSON guarda só o nome) */
(function(){
'use strict';
var RM=window.RM,P=RM.photos={cache:{},pending:null};
P.bridge=function(){var b=RM.br('AndroidPhoto');return b&&b.capture?b:null};
P.available=function(){return !!P.bridge()};
P.capture=function(orderId,kind){
  var b=P.bridge();if(!b){RM.ui.toast('As fotos funcionam no aplicativo Android.','err');return}
  P.pending={orderId:orderId,kind:kind};b.capture(orderId,kind);
};
P.get=function(name,max){
  var k=name+'@'+max;if(P.cache[k]!==undefined)return P.cache[k];
  var b=RM.br('AndroidPhoto'),v='';try{v=b&&b.getPhoto?b.getPhoto(name,max):''}catch(e){RM.logError('foto',e.message)}
  if(v)P.cache[k]=v;return v;
};
P.remove=function(orderId,name){
  var o=RM.data.orders.find(function(x){return x.id===orderId});if(!o)return;
  o.photos=(o.photos||[]).filter(function(p){return p.name!==name});
  try{var b=RM.br('AndroidPhoto');if(b&&b.deletePhoto)b.deletePhoto(name)}catch(e){}
  Object.keys(P.cache).forEach(function(k){if(k.indexOf(name+'@')===0)delete P.cache[k]});
  RM.persist();
};
/* retorno do app Android */
window.onNativePhotoTaken=function(name){
  var p=P.pending;P.pending=null;
  var m=/^os([a-z0-9]+)_(antes|depois)_\d+\.jpg$/.exec(String(name));
  var orderId=p?p.orderId:(m?m[1]:''),kind=p?p.kind:(m?m[2]:'antes');
  var o=RM.data.orders.find(function(x){return x.id===orderId});
  if(!o){RM.ui.toast('Foto salva, mas a ordem não foi encontrada.','err');return}
  o.photos=o.photos||[];o.photos.push({name:name,kind:kind,at:new Date().toISOString()});
  RM.persist();RM.ui.toast('Foto adicionada.');
};
window.onNativePhotoCancelled=function(){P.pending=null};
})();

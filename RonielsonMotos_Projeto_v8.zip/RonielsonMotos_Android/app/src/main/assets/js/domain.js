/* domain.js — regras de negócio puras (sem tela). Tudo recebe "data" por parâmetro, o que permite testar sem navegador. */
(function(){
'use strict';
var RM=window.RM,num=RM.num,r2=RM.r2;
var d=RM.d={};

/* ---------- status ---------- */
d.STATUSES=['Orçamento','Aprovada','Em andamento','Aguardando peça','Concluída','Entregue','Cancelada'];
d.DONE=['Concluída','Entregue'];
d.CONSUME=['Em andamento','Concluída','Entregue'];          // a partir daqui as peças saem do estoque
d.RELEASE=['Orçamento','Aprovada','Aberta','Cancelada'];     // voltar para cá devolve as peças ao estoque
d.isDone=function(s){return d.DONE.indexOf(s)>-1};
d.isOpen=function(s){return ['Concluída','Entregue','Cancelada','Orçamento'].indexOf(s)<0};
d.statusOptions=function(current){var l=d.STATUSES.slice();if(current==='Aberta'&&l.indexOf('Aberta')<0)l.splice(1,0,'Aberta');return l};

/* ---------- valores da ordem ---------- */
d.itemsTotal=function(o){return (o.items&&o.items.length)?r2(o.items.reduce(function(a,i){return a+num(i.qty)*num(i.price)},0)):r2(num(o.partsCost))};
d.itemsCost=function(o){return r2((o.items||[]).reduce(function(a,i){return a+num(i.qty)*num(i.cost)},0))};
d.orderTotal=function(o){return Math.max(0,r2(num(o.labor)+d.itemsTotal(o)-num(o.discount)))};
d.paid=function(o){return r2((o.payments||[]).reduce(function(a,p){return a+num(p.amount)},0))};
d.balance=function(o){if(o.balanceExempt||['Orçamento','Cancelada'].indexOf(o.status)>-1)return 0;return Math.max(0,r2(d.orderTotal(o)-d.paid(o)))};
d.refresh=function(o){o.partsCost=d.itemsTotal(o);o.total=d.orderTotal(o);return o};
d.orderDate=function(o){return o.doneAt||o.deliveredAt||o.created||''};

/* ---------- estoque ---------- */
d.applyStock=function(data,o,sign){
  var short=[];
  (o.items||[]).forEach(function(i){
    if(!i.partId)return;var p=data.parts.find(function(x){return x.id===i.partId});if(!p)return;var q=num(i.qty);
    if(sign<0){var take=Math.min(num(p.qty),q);i.consumed=take;p.qty=num(p.qty)-take;if(take<q)short.push(p.name+' (faltam '+(q-take)+')')}
    else{p.qty=num(p.qty)+num(i.consumed);i.consumed=0}
  });
  return short;
};
d.setStatus=function(data,id,status,today){
  var o=data.orders.find(function(x){return x.id===id}),warnings=[];
  if(!o)return {ok:false,warnings:warnings};
  var prev=o.status;if(prev===status)return {ok:true,warnings:warnings};
  if(d.CONSUME.indexOf(status)>-1&&!o.stockApplied){d.applyStock(data,o,-1).forEach(function(w){warnings.push('Estoque insuficiente: '+w)});o.stockApplied=true}
  else if(d.RELEASE.indexOf(status)>-1&&o.stockApplied){d.applyStock(data,o,+1);o.stockApplied=false}
  if(prev==='Orçamento'&&status!=='Cancelada')o.approvedAt=o.approvedAt||today;
  if(d.isDone(status)){
    o.doneAt=o.doneAt||today;
    if(status==='Entregue')o.deliveredAt=o.deliveredAt||today;else o.deliveredAt='';
    if(o.mechanicId&&(o.commissionPct===undefined||o.commissionPct===''||o.commissionPct===null)){var m=data.mechanics.find(function(x){return x.id===o.mechanicId});if(m)o.commissionPct=num(m.commission)}
  }else if(['Orçamento','Aprovada','Aberta','Em andamento','Aguardando peça'].indexOf(status)>-1){o.doneAt='';o.deliveredAt=''}
  o.status=status;o.history=o.history||[];o.history.push({date:today,from:prev,to:status});
  return {ok:true,warnings:warnings};
};
d.nextNumber=function(data){var n=num(data.settings.seq)||1;data.settings.seq=n+1;return String(n).padStart(4,'0')};

/* Salva (cria/edita) uma ordem a partir de um rascunho. Mantém o estoque coerente se já tinha sido baixado. */
d.saveOrder=function(data,draft,today){
  var o=draft.id?data.orders.find(function(x){return x.id===draft.id}):null,isNew=!o,warnings=[];
  if(isNew){o={id:RM.uid(),number:d.nextNumber(data),created:today,items:[],payments:[],photos:[],history:[],status:'Orçamento'};data.orders.unshift(o)}
  var wasApplied=!!o.stockApplied;if(wasApplied)d.applyStock(data,o,+1);
  o.customerId=draft.customerId||'';o.customer=draft.customer||'';o.bike=draft.bike||'';o.plate=draft.plate||'';o.km=draft.km===''||draft.km==null?'':num(draft.km);
  o.problem=draft.problem||'';o.labor=r2(num(draft.labor));o.discount=r2(num(draft.discount));
  o.items=(draft.items||[]).filter(function(i){return String(i.name||'').trim()&&num(i.qty)>0}).map(function(i){return {partId:i.partId||'',name:String(i.name).trim(),qty:num(i.qty),price:r2(num(i.price)),cost:r2(num(i.cost)),consumed:0}});
  o.mechanicId=draft.mechanicId||'';o.warrantyDays=Math.max(0,Math.round(num(draft.warrantyDays)));
  o.nextDate=draft.nextDate||'';o.nextKm=draft.nextKm===''||draft.nextKm==null?'':num(draft.nextKm);o.notes=draft.notes||'';
  if(o.mechanicId&&d.isDone(o.status)){var m=data.mechanics.find(function(x){return x.id===o.mechanicId});if(m&&(o.commissionPct===undefined||o.commissionPct===''))o.commissionPct=num(m.commission)}
  if(!o.mechanicId)o.commissionPct='';
  d.refresh(o);
  if(wasApplied)d.applyStock(data,o,-1).forEach(function(w){warnings.push('Estoque insuficiente: '+w)});
  // atualiza a km da moto cadastrada, se maior
  if(o.customerId&&o.km!==''){var c=data.customers.find(function(x){return x.id===o.customerId});if(c&&num(o.km)>num(c.km))c.km=num(o.km)}
  return {order:o,isNew:isNew,warnings:warnings};
};
d.deleteOrder=function(data,id){
  var o=data.orders.find(function(x){return x.id===id});if(!o)return;
  if(o.stockApplied)d.applyStock(data,o,+1);
  data.cash=data.cash.filter(function(x){return !(x.ref&&x.ref.type==='os'&&x.ref.id===id)});   // pagamentos dessa OS saem do caixa junto
  data.orders=data.orders.filter(function(x){return x.id!==id});
};

/* ---------- pagamentos / fiado ---------- */
d.addPayment=function(data,id,p){
  var o=data.orders.find(function(x){return x.id===id});if(!o)return {ok:false,error:'Ordem não encontrada.'};
  var amount=r2(num(p.amount));if(amount<=0)return {ok:false,error:'Informe um valor maior que zero.'};
  if(amount>d.balance(o)+0.009)return {ok:false,error:'O valor é maior que o saldo a receber ('+RM.money(d.balance(o))+').'};
  var pay={id:RM.uid(),date:p.date||RM.today(),amount:amount,method:p.method||'Pix'};
  o.payments.push(pay);
  data.cash.unshift({id:RM.uid(),desc:'OS #'+o.number+' — '+(o.customer||'Cliente'),type:'Entrada',amount:amount,method:pay.method,date:pay.date,category:'Serviço',ref:{type:'os',id:o.id,pay:pay.id}});
  return {ok:true,payment:pay};
};
d.removePayment=function(data,orderId,payId){
  var o=data.orders.find(function(x){return x.id===orderId});if(!o)return;
  o.payments=o.payments.filter(function(p){return p.id!==payId});
  data.cash=data.cash.filter(function(x){return !(x.ref&&x.ref.type==='os'&&x.ref.pay===payId)});
};
d.recvBalance=function(r){return Math.max(0,r2(num(r.amount)-(r.payments||[]).reduce(function(a,p){return a+num(p.amount)},0)))};
d.addReceivable=function(data,r){var rec={id:RM.uid(),desc:r.desc||'Valor a receber',customerId:r.customerId||'',customer:r.customer||'',amount:r2(num(r.amount)),due:r.due||'',created:RM.today(),payments:[]};data.receivables.unshift(rec);return rec};
d.receiveManual=function(data,id,p){
  var r=data.receivables.find(function(x){return x.id===id});if(!r)return {ok:false,error:'Registro não encontrado.'};
  var amount=r2(num(p.amount));if(amount<=0)return {ok:false,error:'Informe um valor maior que zero.'};
  if(amount>d.recvBalance(r)+0.009)return {ok:false,error:'O valor é maior que o saldo ('+RM.money(d.recvBalance(r))+').'};
  var pay={id:RM.uid(),date:p.date||RM.today(),amount:amount,method:p.method||'Pix'};r.payments.push(pay);
  data.cash.unshift({id:RM.uid(),desc:r.desc+(r.customer?' — '+r.customer:''),type:'Entrada',amount:amount,method:pay.method,date:pay.date,category:'Fiado',ref:{type:'rec',id:r.id,pay:pay.id}});
  return {ok:true};
};
d.debtors=function(data){
  var map={},list=[];
  function slot(customerId,name){
    var c=customerId?data.customers.find(function(x){return x.id===customerId}):null;
    if(!c&&name){c=data.customers.find(function(x){return x.name&&x.name.toLowerCase()===String(name).toLowerCase()})||null}
    var key=c?c.id:('n:'+String(name||'Sem nome').toLowerCase());
    if(!map[key]){map[key]={key:key,name:c?c.name:(name||'Sem nome'),phone:c?c.phone:'',total:0,items:[]};list.push(map[key])}
    return map[key];
  }
  data.orders.forEach(function(o){var b=d.balance(o);if(b>0){var s=slot(o.customerId,o.customer);s.total=r2(s.total+b);s.items.push({kind:'os',id:o.id,label:'OS #'+o.number+(o.problem?' — '+o.problem:''),balance:b,date:d.orderDate(o)})}});
  data.receivables.forEach(function(r){var b=d.recvBalance(r);if(b>0){var s=slot(r.customerId,r.customer);s.total=r2(s.total+b);s.items.push({kind:'rec',id:r.id,label:r.desc,balance:b,date:r.due||r.created})}});
  list.sort(function(a,b){return b.total-a.total});return list;
};
d.totalReceivable=function(data){return r2(d.debtors(data).reduce(function(a,x){return a+x.total},0))};

/* ---------- contas a pagar ---------- */
d.addPayable=function(data,p){var rec={id:RM.uid(),desc:p.desc||'Conta',supplier:p.supplier||'',amount:r2(num(p.amount)),due:p.due||RM.today(),category:p.category||'Despesa',paid:false,paidDate:'',method:''};data.payables.unshift(rec);return rec};
d.payPayable=function(data,id,p){
  var r=data.payables.find(function(x){return x.id===id});if(!r||r.paid)return {ok:false};
  r.paid=true;r.paidDate=p.date||RM.today();r.method=p.method||'Pix';
  data.cash.unshift({id:RM.uid(),desc:r.desc+(r.supplier?' — '+r.supplier:''),type:'Saída',amount:r.amount,method:r.method,date:r.paidDate,category:r.category||'Despesa',ref:{type:'pay',id:r.id}});
  return {ok:true};
};
d.unpayPayable=function(data,id){var r=data.payables.find(function(x){return x.id===id});if(!r)return;r.paid=false;r.paidDate='';data.cash=data.cash.filter(function(x){return !(x.ref&&x.ref.type==='pay'&&x.ref.id===id)})};
d.payablesPending=function(data){return data.payables.filter(function(x){return !x.paid})};

/* ---------- caixa / fechamento ---------- */
d.CASH_OUT=['Despesa','Compra de estoque','Comissão','Retirada do dono'];
d.CASH_IN=['Serviço','Venda de peça','Fiado','Outros'];
d.cashTotals=function(data,from,to){var inR=function(x){return (!from||x>=from)&&(!to||x<=to)},i=0,o=0;data.cash.forEach(function(x){if(!inR(x.date))return;if(x.type==='Entrada')i+=num(x.amount);else o+=num(x.amount)});return {in:r2(i),out:r2(o),balance:r2(i-o)}};
d.dayTotals=function(data,date){
  var byIn={},byOut={},i=0,o=0,n=0;
  data.cash.forEach(function(x){if(x.date!==date)return;n++;var a=num(x.amount),m=x.method||'Outro';if(x.type==='Entrada'){i+=a;byIn[m]=r2((byIn[m]||0)+a)}else{o+=a;byOut[m]=r2((byOut[m]||0)+a)}});
  return {date:date,count:n,in:r2(i),out:r2(o),balance:r2(i-o),byIn:byIn,byOut:byOut,cashIn:byIn['Dinheiro']||0,cashOut:byOut['Dinheiro']||0};
};
d.saveClosing=function(data,c){
  var t=d.dayTotals(data,c.date),expected=r2(num(c.opening)+t.cashIn-t.cashOut),diff=r2(num(c.counted)-expected);
  var rec={id:RM.uid(),date:c.date,opening:r2(num(c.opening)),counted:r2(num(c.counted)),expected:expected,diff:diff,in:t.in,out:t.out,byIn:t.byIn,byOut:t.byOut,note:c.note||'',at:new Date().toISOString()};
  data.closings=data.closings.filter(function(x){return x.date!==c.date});data.closings.unshift(rec);
  data.closings.sort(function(a,b){return b.date.localeCompare(a.date)});
  return rec;
};

/* ---------- comissão ---------- */
d.commission=function(data,o){
  if(!o.mechanicId)return 0;var m=data.mechanics.find(function(x){return x.id===o.mechanicId});
  var pct=(o.commissionPct!==undefined&&o.commissionPct!==''&&o.commissionPct!==null)?num(o.commissionPct):(m?num(m.commission):0);
  return r2(num(o.labor)*pct/100);
};
d.mechanicReport=function(data,from,to){
  return data.mechanics.map(function(m){
    var done=data.orders.filter(function(o){return o.mechanicId===m.id&&d.isDone(o.status)});
    var inRange=done.filter(function(o){var x=d.orderDate(o);return x>=from&&x<=to});
    var pendingOrders=done.filter(function(o){return !o.commissionPaid});
    var sum=function(arr,f){return r2(arr.reduce(function(a,o){return a+f(o)},0))};
    return {mechanic:m,orders:inRange,labor:sum(inRange,function(o){return num(o.labor)}),commission:sum(inRange,function(o){return d.commission(data,o)}),
      pendingOrders:pendingOrders,pending:sum(pendingOrders,function(o){return d.commission(data,o)})};
  });
};
d.payCommissions=function(data,mechId,orderIds,p){
  var m=data.mechanics.find(function(x){return x.id===mechId});if(!m)return 0;var total=0;
  data.orders.forEach(function(o){if(orderIds.indexOf(o.id)>-1&&o.mechanicId===mechId&&!o.commissionPaid){total+=d.commission(data,o);o.commissionPaid=true;o.commissionPaidAt=p.date}});
  total=r2(total);
  if(total>0)data.cash.unshift({id:RM.uid(),desc:'Comissão — '+m.name,type:'Saída',amount:total,method:p.method||'Dinheiro',date:p.date||RM.today(),category:'Comissão',ref:{type:'comm',id:mechId}});
  return total;
};

/* ---------- lucro por período ---------- */
d.profit=function(data,from,to){
  var inR=function(x){return x>=from&&x<=to};
  var orders=data.orders.filter(function(o){return d.isDone(o.status)&&inR(d.orderDate(o))});
  var sum=function(f){return r2(orders.reduce(function(a,o){return a+f(o)},0))};
  var revenue=sum(d.orderTotal),labor=sum(function(o){return num(o.labor)}),parts=sum(d.itemsTotal),discount=sum(function(o){return num(o.discount)}),costParts=sum(d.itemsCost);
  var commissions=sum(function(o){return d.commission(data,o)});
  var outIn=function(cat){return r2(data.cash.filter(function(x){return x.type==='Saída'&&inR(x.date)&&((x.category||'Despesa')===cat)}).reduce(function(a,x){return a+num(x.amount)},0))};
  var expenses=outIn('Despesa'),purchases=outIn('Compra de estoque'),withdrawals=outIn('Retirada do dono');
  var gross=r2(revenue-costParts),net=r2(gross-commissions-expenses);
  var agg={};orders.forEach(function(o){(o.items||[]).forEach(function(i){var k=i.name;agg[k]=agg[k]||{name:k,qty:0,revenue:0};agg[k].qty+=num(i.qty);agg[k].revenue=r2(agg[k].revenue+num(i.qty)*num(i.price))})});
  var top=Object.keys(agg).map(function(k){return agg[k]}).sort(function(a,b){return b.qty-a.qty}).slice(0,5);
  var legacyNoCost=orders.filter(function(o){return !(o.items&&o.items.length)&&num(o.partsCost)>0}).length;
  return {from:from,to:to,count:orders.length,revenue:revenue,labor:labor,parts:parts,discount:discount,costParts:costParts,gross:gross,commissions:commissions,expenses:expenses,purchases:purchases,withdrawals:withdrawals,net:net,avgTicket:orders.length?r2(revenue/orders.length):0,top:top,legacyNoCost:legacyNoCost,received:d.cashTotals(data,from,to).in};
};

/* ---------- motos, histórico, garantia, lembretes ---------- */
d.normPlate=function(p){return String(p||'').toUpperCase().replace(/[^A-Z0-9]/g,'')};
d.vehicleOrders=function(data,c){
  return data.orders.filter(function(o){
    if(o.customerId)return o.customerId===c.id;
    return o.customer===c.name&&(!c.bike||String(o.bike||'').indexOf(c.bike)>-1);
  }).sort(function(a,b){return (d.orderDate(b)+b.number).localeCompare(d.orderDate(a)+a.number)});
};
d.warrantyUntil=function(o){var base=o.deliveredAt||o.doneAt,days=num(o.warrantyDays);return base&&days>0?RM.addDays(base,days):''};
d.inWarranty=function(o,today){var u=d.warrantyUntil(o);return !!u&&u>=today&&d.isDone(o.status)};
d.fillTemplate=function(tpl,vars){return String(tpl||'').replace(/\{(\w+)\}/g,function(m,k){return vars[k]!==undefined?vars[k]:m})};
d.reminderVars=function(data,c,o){return {nome:String(c.name||'').split(' ')[0]||'cliente',moto:c.bike||'moto',placa:c.plate||'—',data:RM.dateBR(o.nextDate),oficina:data.settings.company.name||'Oficina',km:o.nextKm?String(o.nextKm):''}};
d.reminders=function(data,today,windowDays){
  var limit=RM.addDays(today,windowDays),out=[];
  data.customers.forEach(function(c){
    var done=d.vehicleOrders(data,c).filter(function(o){return d.isDone(o.status)});
    var o=done[0];if(!o||!o.nextDate||o.nextDate>limit)return;
    out.push({customer:c,order:o,date:o.nextDate,overdue:o.nextDate<today,days:RM.daysBetween(today,o.nextDate),sent:!!o.reminderSentAt});
  });
  out.sort(function(a,b){return a.date.localeCompare(b.date)});return out;
};

/* ---------- estoque: alerta, margem, reposição ---------- */
d.margin=function(p){return num(p.price)>0?r2((num(p.price)-num(p.cost))/num(p.price)*100):0};
d.lowParts=function(data){return data.parts.filter(function(p){return num(p.qty)<=num(p.min)})};
d.restock=function(data){return d.lowParts(data).map(function(p){return {part:p,suggest:Math.max(1,num(p.min)*2-num(p.qty))}})};
d.stockValue=function(data){return r2(data.parts.reduce(function(a,p){return a+num(p.qty)*num(p.cost)},0))};

/* ---------- PIN ---------- */
d.pinHas=function(data){return !!data.settings.pinHash};
d.pinSet=function(data,pin){var salt=RM.uid()+RM.uid();data.settings.pinSalt=salt;data.settings.pinHash=RM.sha256(salt+':'+pin)};
d.pinCheck=function(data,pin){return !!data.settings.pinHash&&RM.sha256(data.settings.pinSalt+':'+pin)===data.settings.pinHash};
d.pinClear=function(data){data.settings.pinHash='';data.settings.pinSalt=''};

/* ---------- permissões (modo dono x funcionário) ---------- */
d.STAFF_PAGES=['dashboard','orders','customers','inventory','reminders'];
d.OWNER_PAGES=['dashboard','orders','customers','inventory','reminders','finance','team','settings'];
d.can=function(mode,perm){
  if(mode==='owner')return true;
  return ['orders.edit','orders.status','orders.payment','customers.edit','parts.adjust','photos','reminders'].indexOf(perm)>-1;
};
})();

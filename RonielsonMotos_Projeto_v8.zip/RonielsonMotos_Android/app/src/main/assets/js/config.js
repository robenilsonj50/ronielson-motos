/* ============================================================
   CONFIGURAÇÕES DO ADMINISTRADOR  (edite aqui e gere o APK de novo)
   ============================================================ */
window.RM = window.RM || {};
RM.CONFIG = {
  companyName: 'Ronielson Motos',

  /* Assinatura / tela de bloqueio */
  adminWhatsapp: '',   // ex.: '5511999999999' (país + DDD + número, só números). Vazio = esconde o botão
  pixKey: '',          // chave Pix para pagamento da assinatura. Vazio = esconde o botão "Pagar via Pix"
  pixName: '',         // nome do recebedor (opcional)
  valor: '',           // ex.: 'R$ 35,00/mês' (opcional)

  /* Aviso de atualização (opcional). Aponte para um arquivo version.json público, ex.:
     {"version":"0.9","url":"https://github.com/SEU-USUARIO/SEU-REPO/releases","notes":"Novidades..."}
     Vazio = não verifica. */
  versionUrl: ''
};

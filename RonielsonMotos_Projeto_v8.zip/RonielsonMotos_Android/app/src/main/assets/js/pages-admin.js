/* pages-admin.js — Ajustes: oficina, padrões, PIN, assinatura, backup, termos, erros e atualização */
(function(){
'use strict';
var RM=window.RM,ui=RM.ui,d=RM.d,esc=RM.esc,money=RM.money,A=RM.act,pages=RM.pages;
function DATA(){return RM.data}
function kv(k,v){return '<div class="kv"><span>'+esc(k)+'</span><b>'+v+'</b></div>'}
RM.appVersion=function(){try{var b=RM.br('AndroidLicense');var v=b&&b.getAppVersion?b.getAppVersion():'';return v||RM.VERSION}catch(e){return RM.VERSION}};

/* ---------- backup / restauração (mesmo formato do app original) ---------- */
RM.backup={
  export:function(){
    var filename='backup-ronielson-motos-'+RM.today()+'.json';
    var json=JSON.stringify({app:'Ronielson Motos',version:RM.VERSION,exportedAt:new Date().toISOString(),data:RM.data},null,2);
    var b=RM.br('AndroidBackup');
    if(b&&b.saveBackup){b.saveBackup(json,filename)}
    else{var blob=new Blob([json],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url)},1000)}
    RM.data.settings.lastBackupAt=new Date().toISOString();RM.persist();
  },
  importFile:function(input){
    var file=input.files&&input.files[0];if(!file)return;
    var reader=new FileReader();
    reader.onload=function(){
      try{
        var bk=JSON.parse(String(reader.result||''));
        if(!bk||bk.app!=='Ronielson Motos'||!bk.data||!Array.isArray(bk.data.orders)||!Array.isArray(bk.data.parts))throw new Error('formato');
        ui.confirm('Restaurar este backup? Os dados atuais deste aparelho serão SUBSTITUÍDOS.\n\nBackup de: '+(bk.exportedAt?RM.dateBR(bk.exportedAt.slice(0,10)):'data desconhecida'),function(){
          RM.data=RM.migrate(bk.data);RM.persist();ui.closeAll();ui.toast('Backup restaurado.');
        },{danger:true,okLabel:'Restaurar'});
      }catch(e){ui.toast('Arquivo de backup inválido.','err')}
      input.value='';
    };
    reader.readAsText(file);
  }
};
A['settings.backup']=function(){RM.backup.export()};
A['settings.import']=function(){var el=RM.$('importFile');if(el)el.click()};
document.addEventListener('change',function(e){if(e.target&&e.target.id==='importFile')RM.backup.importFile(e.target)});

/* ---------- atualização (opcional) ---------- */
RM.update={available:null,
  cmp:function(a,b){var x=String(a).split('.').map(Number),y=String(b).split('.').map(Number);for(var i=0;i<Math.max(x.length,y.length);i++){var p=(x[i]||0)-(y[i]||0);if(p)return p>0?1:-1}return 0},
  check:function(manual){
    var url=RM.CONFIG&&RM.CONFIG.versionUrl;
    if(!url){if(manual)ui.toast('A verificação de atualização não está configurada.');return}
    var S=RM.data.settings,now=Date.now();
    if(!manual&&S.lastUpdateCheck&&now-S.lastUpdateCheck<20*3600*1000)return;
    if(typeof fetch!=='function')return;
    fetch(url,{cache:'no-store'}).then(function(r){return r.json()}).then(function(j){
      S.lastUpdateCheck=Date.now();RM.save();
      if(j&&j.version&&RM.update.cmp(j.version,RM.appVersion())>0){
        RM.update.available=j;
        ui.open({title:'Nova versão disponível',render:function(){return '<p>Versão <b>'+esc(j.version)+'</b> disponível (você usa a '+esc(RM.appVersion())+').</p>'+(j.notes?'<p class="muted">'+esc(j.notes)+'</p>':'')+'<p class="muted small">Baixe e instale por cima — seus dados são mantidos.</p>'},
          actions:function(){return '<button type="button" class="btn" data-act="ui.close">Depois</button>'+(j.url?'<button type="button" class="btn primary" data-act="upd.open">Baixar</button>':'')}});
      }else if(manual)ui.toast('Você já está na versão mais recente.');
    }).catch(function(){if(manual)ui.toast('Não foi possível verificar agora.','err')});
  }
};
A['upd.open']=function(){var j=RM.update.available;if(j&&/^https:\/\//.test(j.url||''))RM.open(j.url)};
A['upd.check']=function(){RM.update.check(true)};

/* ---------- termos e privacidade ---------- */
ui.checkTerms=function(){
  var S=RM.data&&RM.data.settings;if(!S)return;var t=S.termsAccepted;if(t&&t.version===RM.LEGAL_VERSION)return;
  ui.open({title:'Termos de uso e privacidade',
    render:function(){return '<div class="legalbox">'+RM.legalHtml('terms')+RM.legalHtml('privacy')+'</div><label class="check"><input type="checkbox" name="ok" required> Li e aceito os Termos de Uso e a Política de Privacidade.</label>'},
    actions:function(){return '<button type="submit" class="btn primary">Aceitar e continuar</button>'},
    onSubmit:function(){S.termsAccepted={version:RM.LEGAL_VERSION,at:new Date().toISOString()};RM.persist()}});
};
A['legal.show']=function(ds){ui.open({title:RM.LEGAL[ds.key].title,render:function(){return '<div class="legalbox">'+RM.legalHtml(ds.key)+'</div>'}})};

/* ---------- relatório de erros ---------- */
function errorReportText(){
  var lines=['Relatório de erros — Ronielson Motos v'+RM.appVersion(),'Aparelho: '+(navigator.userAgent||''),'ID: '+ui.deviceId(),''];
  var errs=RM.getErrors();if(!errs.length)lines.push('(nenhum erro registrado)');
  errs.forEach(function(e){lines.push(e.at+' ['+e.kind+'] '+e.msg+(e.src?' ('+e.src+')':''))});return lines.join('\n');
}
A['err.show']=function(){
  ui.open({title:'Relatório de erros',live:true,render:function(){var errs=RM.getErrors();return errs.length?'<div class="list">'+errs.map(function(e){return '<div class="hrow"><div><b>'+esc(e.kind)+'</b> · '+esc(e.msg)+'<div class="muted small">'+esc(e.at.replace('T',' ').slice(0,19))+(e.src?' · '+esc(e.src):'')+'</div></div></div>'}).join('')+'</div>':ui.empty('Nenhum erro registrado','Tudo funcionando. 👍')},
    actions:function(){return '<button type="button" class="btn" data-act="ui.close">Fechar</button><button type="button" class="btn" data-act="err.copy">Copiar</button><button type="button" class="btn" data-act="err.clear">Limpar</button>'+((RM.CONFIG||{}).adminWhatsapp?'<button type="button" class="btn primary" data-act="err.send">💬 Enviar ao suporte</button>':'')}});
};
A['err.copy']=function(){RM.copy(errorReportText());ui.toast('Relatório copiado.')};
A['err.clear']=function(){RM.clearErrors();ui.refresh();ui.toast('Relatório limpo.')};
A['err.send']=function(){RM.open(RM.waLink((RM.CONFIG||{}).adminWhatsapp,errorReportText()))};

/* ---------- formulários ---------- */
A['set.company']=function(){
  var c=DATA().settings.company;
  ui.open({title:'Dados da oficina',submitLabel:'Salvar',
    render:function(){return '<p class="muted small">Aparecem no cabeçalho dos PDFs (orçamento, OS e fechamento).</p>'+ui.fields([{name:'name',label:'Nome da oficina',value:c.name,full:true},{name:'phone',label:'Telefone / WhatsApp',type:'tel',value:c.phone,required:false},{name:'doc',label:'CNPJ / CPF (opcional)',value:c.doc,required:false},{name:'address',label:'Endereço',value:c.address,required:false,full:true}])},
    onSubmit:function(v){Object.assign(DATA().settings.company,{name:String(v.name).trim(),phone:String(v.phone||'').trim(),doc:String(v.doc||'').trim(),address:String(v.address||'').trim()});RM.persist();ui.toast('Dados salvos.')}});
};
A['set.defaults']=function(){
  var S=DATA().settings;
  ui.open({title:'Garantia e lembretes',submitLabel:'Salvar',
    render:function(){return ui.fields([{name:'warrantyDays',label:'Garantia padrão (dias)',type:'number',value:S.warrantyDays,step:'1',min:0},{name:'reminderMonths',label:'Revisão sugerida após (meses)',type:'number',value:S.reminderMonths,step:'1',min:0},{name:'reminderTemplate',label:'Mensagem do lembrete (WhatsApp)',type:'textarea',rows:4,full:true,value:S.reminderTemplate,hint:'Use {nome} {moto} {placa} {data} {oficina}'}])},
    onSubmit:function(v){S.warrantyDays=Math.max(0,Math.round(RM.num(v.warrantyDays)));S.reminderMonths=Math.max(0,Math.round(RM.num(v.reminderMonths)));S.reminderTemplate=String(v.reminderTemplate||'').trim()||RM.DEFAULT_REMINDER;RM.persist();ui.toast('Salvo.')}});
};
A['set.pin']=function(){
  var has=d.pinHas(DATA());
  ui.open({title:has?'Alterar PIN do dono':'Definir PIN do dono',submitLabel:'Salvar PIN',
    render:function(){return '<p class="muted small">Com PIN, o app abre em <b>modo funcionário</b> (sem caixa, financeiro, custos e ajustes). Só quem sabe o PIN entra no modo dono.</p>'+ui.fields([{name:'pin',label:'Novo PIN (4 a 8 números)',type:'password',maxlength:8,attrs:'inputmode="numeric"'},{name:'pin2',label:'Repita o PIN',type:'password',maxlength:8,attrs:'inputmode="numeric"'}])},
    onSubmit:function(v){
      if(!/^\d{4,8}$/.test(String(v.pin||''))){ui.toast('Use de 4 a 8 números.','err');return false}
      if(v.pin!==v.pin2){ui.toast('Os PINs não conferem.','err');return false}
      d.pinSet(DATA(),String(v.pin));RM.persist();ui.toast('PIN definido. Anote-o em local seguro.');
    }});
};
A['set.pinOff']=function(){ui.confirm('Remover o PIN? O acesso total ficará liberado para qualquer pessoa que abrir o app.',function(){d.pinClear(DATA());RM.persist();ui.toast('PIN removido.')},{danger:true,okLabel:'Remover'})};
A['lic.activateSettings']=function(){
  var el=RM.$('licCodeSettings'),code=el?String(el.value||'').trim():'';
  if(!code){ui.toast('Cole o código de ativação.','err');return}
  var b=RM.br('AndroidLicense'),r;try{r=JSON.parse(b.activate(code))}catch(e){ui.toast('Não foi possível ativar agora.','err');return}
  ui.toast(r.message,r.ok?'':'err');if(r.ok){if(el)el.value='';RM.license.check();ui.render(true)}
};
A['lic.copyIdSettings']=function(){RM.copy(ui.deviceId());ui.toast('ID copiado.')};
A['lic.contactSettings']=function(){var n=RM.phoneDigits((RM.CONFIG||{}).adminWhatsapp);if(!n){ui.toast('WhatsApp do administrador não configurado.','err');return}RM.open('https://wa.me/'+n+'?text='+encodeURIComponent('Olá! Quero renovar o sistema. ID do aparelho: '+ui.deviceId()))};

/* ---------- página ---------- */
pages.settings={title:'Ajustes',icon:'⚙',label:'Ajustes',
render:function(){
  var data=DATA(),S=data.settings,c=S.company,st=RM.license.status(),has=d.pinHas(data),errN=RM.getErrors().length;
  var lic='';
  if(st){
    var line=st.mode==='licensed'?(st.licenseYear>=9000?'Assinatura <b>vitalícia</b>':'Assinatura ativa até <b>'+esc(st.licenseDate)+'</b> ('+st.remainingDays+' dia(s))'):(st.mode==='trial'?'Período de teste: <b>'+st.remainingDays+' dia(s)</b> restantes':'Acesso vencido');
    lic='<div class="card"><div class="cardhead"><h2>Assinatura</h2></div><p>'+line+'</p>'+kv('ID deste aparelho','<span class="mono">'+esc(st.deviceId)+'</span>')
     +ui.field({name:'licCodeSettings',label:'Código de ativação / renovação',type:'textarea',rows:2,required:false,attrs:'id="licCodeSettings" placeholder="Cole aqui o código enviado pelo administrador"'})
     +'<div class="btnrow"><button type="button" class="btn primary" data-act="lic.activateSettings">Ativar código</button><button type="button" class="btn" data-act="lic.copyIdSettings">Copiar ID</button>'+((RM.CONFIG||{}).adminWhatsapp?'<button type="button" class="btn" data-act="lic.contactSettings">💬 Falar com o administrador</button>':'')+'</div></div>';
  }
  var lb=S.lastBackupAt?RM.dateBR(S.lastBackupAt.slice(0,10)):'nunca';
  return '<div class="toolbar"><h2>Ajustes</h2></div><div class="grid2"><div>'
   +'<div class="card"><div class="cardhead"><h2>Oficina</h2><button type="button" class="btn sm" data-act="set.company">Editar</button></div>'+kv('Nome',esc(c.name||'—'))+kv('Telefone',esc(c.phone||'—'))+kv('Endereço',esc(c.address||'—'))+kv('CNPJ/CPF',esc(c.doc||'—'))+'</div>'
   +'<div class="card"><div class="cardhead"><h2>Garantia e lembretes</h2><button type="button" class="btn sm" data-act="set.defaults">Editar</button></div>'+kv('Garantia padrão',RM.num(S.warrantyDays)+' dias')+kv('Revisão sugerida após',RM.num(S.reminderMonths)+' meses')+'<div class="note small">'+esc(S.reminderTemplate)+'</div></div>'
   +'<div class="card"><div class="cardhead"><h2>Segurança (PIN)</h2></div><p class="muted">'+(has?'PIN ativo: o app abre em modo funcionário.':'Sem PIN: qualquer pessoa vê o caixa e os custos.')+'</p><div class="btnrow"><button type="button" class="btn primary" data-act="set.pin">'+(has?'Alterar PIN':'Definir PIN')+'</button>'+(has?'<button type="button" class="btn" data-act="ui.lock">Sair do modo dono</button><button type="button" class="btn danger" data-act="set.pinOff">Remover PIN</button>':'')+'</div></div>'
   +'</div><div>'+lic
   +'<div class="card"><div class="cardhead"><h2>Backup</h2></div><p class="muted">Último backup: <b>'+lb+'</b>. Guarde o arquivo fora do celular (WhatsApp, e-mail, nuvem).</p><div class="notice">As <b>fotos</b> das ordens ficam no aparelho e não vão dentro do arquivo de backup.</div><div class="btnrow"><button type="button" class="btn primary" data-act="settings.backup">💾 Exportar backup</button><button type="button" class="btn" data-act="settings.import">📥 Restaurar backup</button></div></div>'
   +'<div class="card"><div class="cardhead"><h2>Sobre</h2></div>'+kv('Versão',esc(RM.appVersion()))+'<div class="btnrow"><button type="button" class="btn" data-act="legal.show" data-key="terms">Termos de uso</button><button type="button" class="btn" data-act="legal.show" data-key="privacy">Privacidade (LGPD)</button><button type="button" class="btn" data-act="upd.check">Verificar atualização</button><button type="button" class="btn" data-act="err.show">Relatório de erros'+(errN?' ('+errN+')':'')+'</button></div></div>'
   +'</div></div>';
}};
})();

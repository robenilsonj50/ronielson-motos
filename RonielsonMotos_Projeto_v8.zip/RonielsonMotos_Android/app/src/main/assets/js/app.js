/* app.js — inicialização */
(function(){
'use strict';
var RM=window.RM,ui=RM.ui,d=RM.d;
function boot(){
  RM.load();
  ui.mode=d.pinHas(RM.data)?'staff':'owner';          // com PIN definido, o app sempre abre em modo funcionário
  var t=RM.$('today');if(t)t.textContent=new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'long'});
  ui.render(false);
  RM.license.check();
  RM.update.check(false);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();

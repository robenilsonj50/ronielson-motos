/* legal.js — Termos de Uso e Política de Privacidade (MODELO). Recomenda-se revisão por um advogado antes da comercialização. */
(function(){
var RM=window.RM;
RM.LEGAL_VERSION='1.0';
RM.LEGAL_DATE='2026-10-14';
RM.LEGAL={
  terms:{title:'Termos de Uso',sections:[
    ['1. O que é o sistema','O sistema é um aplicativo de gestão para oficinas (ordens de serviço, clientes e motos, estoque, caixa e financeiro), licenciado para uso em um aparelho por vez.'],
    ['2. Licença e assinatura','O uso é liberado por um período de teste e, depois, mediante assinatura. A ativação é feita por código vinculado ao aparelho, informado pelo administrador. Ao fim da validade, o acesso é bloqueado até a renovação. A licença é pessoal, intransferível e não pode ser copiada, revendida ou modificada.'],
    ['3. Seus dados e responsabilidade','Os dados cadastrados ficam armazenados neste aparelho. Você é responsável por manter cópias de segurança (backup), por manter o aparelho protegido e por cadastrar apenas informações que tenha o direito de usar. Limpar os dados do aplicativo, desinstalá-lo ou perder/trocar o aparelho pode apagar os dados se não houver backup.'],
    ['4. Funcionários e PIN','O PIN do dono restringe áreas sensíveis (caixa, financeiro, preços e ajustes). Guarde o PIN com cuidado; a recuperação depende de um código emitido pelo administrador.'],
    ['5. Limitações','O sistema é uma ferramenta de apoio e não substitui obrigações fiscais, contábeis ou legais da oficina (como emissão de nota fiscal). Valores, comissões e relatórios dependem dos dados informados por você. O serviço é fornecido "no estado em que se encontra", e o administrador não responde por perdas decorrentes de falta de backup ou de uso indevido.'],
    ['6. Atualizações e suporte','Podem ser disponibilizadas atualizações. O suporte e as condições comerciais (valor de venda e mensalidade) são os combinados com o administrador.'],
    ['7. Alterações','Estes termos podem ser atualizados; a continuidade de uso após o aviso indica concordância.']
  ]},
  privacy:{title:'Política de Privacidade (LGPD)',sections:[
    ['1. Quais dados o sistema trata','Dados que a oficina cadastra: nome, telefone, moto e placa de clientes, histórico de serviços, valores, fotos das ordens de serviço e dados da própria oficina. Também são tratados dados técnicos mínimos: um identificador do aparelho (usado só para a licença) e um registro local de erros.'],
    ['2. Onde ficam os dados','Neste aparelho. Atualmente o sistema não envia seus dados nem os dados dos seus clientes para servidores. Os backups são arquivos que VOCÊ gera e guarda. Se, no futuro, houver sincronização em nuvem, esta política será atualizada e você será avisado.'],
    ['3. Quando algo sai do aparelho','Somente por ação sua: ao tocar em enviar por WhatsApp (o texto é aberto no WhatsApp), imprimir/salvar PDF ou exportar um backup. Se configurado pelo administrador, o aplicativo pode consultar um endereço público apenas para saber se existe versão nova (sem enviar dados de clientes).'],
    ['4. Papéis na LGPD','A oficina é a controladora dos dados dos seus clientes e decide como usá-los. O administrador do sistema fornece a ferramenta e não acessa os dados armazenados no seu aparelho.'],
    ['5. Boas práticas para a oficina','Use os dados dos clientes apenas para atendimento, cobrança, garantia e lembretes de revisão; informe os clientes sobre isso; atenda pedidos de correção ou exclusão de dados (os registros podem ser editados ou excluídos no sistema); proteja o aparelho com senha e use o PIN do dono.'],
    ['6. Direitos dos titulares','Clientes cujos dados estão cadastrados podem pedir à oficina acesso, correção, exclusão e informações sobre o uso dos seus dados.'],
    ['7. Contato','Dúvidas sobre o sistema: fale com o administrador (ver Ajustes).']
  ]},
  note:'Este texto é um modelo informativo e não constitui aconselhamento jurídico.'
};
RM.legalHtml=function(key){
  var L=RM.LEGAL[key];
  return '<div class="legal"><p class="muted small">Versão '+RM.LEGAL_VERSION+' • '+RM.dateBR(RM.LEGAL_DATE)+'</p>'+L.sections.map(function(s){return '<h3>'+RM.esc(s[0])+'</h3><p>'+RM.esc(s[1])+'</p>'}).join('')+'<p class="muted small">'+RM.esc(RM.LEGAL.note)+'</p></div>';
};
})();

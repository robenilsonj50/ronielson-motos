/* license.js — tela de bloqueio (teste de 30 dias / assinatura) e ativação por código. A verificação criptográfica é feita no Android. */
(function(){
'use strict';
var RM=window.RM,ui=RM.ui,esc=RM.esc,A=RM.act,$=RM.$;
var L=RM.license={state:null};
function cfg(){return RM.CONFIG||{}}
L.status=function(){try{var b=RM.br('AndroidLicense');if(b&&typeof b.getTrialStatus==='function')return JSON.parse(b.getTrialStatus())}catch(e){RM.logError('licença',e.message)}return null};
function waNumber(){return RM.phoneDigits(cfg().adminWhatsapp)}
function gateMessage(){var s=L.state||{};return 'Olá! Quero '+(s.hadLicense?'renovar':'ativar')+' o sistema '+(cfg().companyName||'Ronielson Motos')+'. ID do aparelho: '+(s.deviceId||'')}
function renderGate(s){
  $('gateDeviceId').textContent=s.deviceId||'—';
  $('gateTitle').textContent=s.hadLicense?'Sua assinatura venceu':'Seu período de teste terminou';
  $('gateText').textContent=s.hadLicense?'Para continuar usando o sistema, renove a assinatura. Seus dados continuam salvos neste aparelho.':'Para continuar usando o sistema, ative a sua assinatura. Seus dados continuam salvos neste aparelho.';
  $('gateWhats').style.display=waNumber()?'':'none';
  $('gatePix').style.display=cfg().pixKey?'':'none';
}
function licToast(t){var el=$('licToast');if(!el)return;el.textContent=t;el.style.display='block';clearTimeout(licToast._t);licToast._t=setTimeout(function(){el.style.display='none'},10000)}
function maybeToast(s){
  if(s.mode==='licensed'&&s.licenseYear>=9000)return;
  if(s.remainingDays<=7){var dd=s.remainingDays,what=s.mode==='trial'?'O período de teste termina':'A assinatura vence';licToast(what+(dd<=1?' hoje ou amanhã':' em '+dd+' dias')+'. Fale com o administrador para renovar.')}
}
L.check=function(){
  var s=L.status();if(!s)return;var first=!L.state;L.state=s;var g=$('trialGate');if(!g)return;
  if(s.active){g.style.display='none';if(first)maybeToast(s)}else{renderGate(s);g.style.display='flex'}
};
A['gate.copyId']=function(){RM.copy($('gateDeviceId').textContent)};
A['gate.hideToast']=function(){var el=$('licToast');if(el)el.style.display='none'};
A['gate.contact']=function(){var n=waNumber();if(!n)return;RM.open('https://wa.me/'+n+'?text='+encodeURIComponent(gateMessage()))};
A['gate.pix']=function(){
  var box=$('gatePixBox'),c=cfg();box.style.display='block';
  box.innerHTML='<b>Chave Pix</b><br>'+esc(c.pixKey||'')+(c.pixName?'<br>Recebedor: '+esc(c.pixName):'')+(c.valor?'<br>Valor: '+esc(c.valor):'')+'<br><br><button type="button" class="gateMini" data-act="gate.copyPix">Copiar chave Pix</button><br><br>Depois de pagar, envie o comprovante e o <b>ID do aparelho</b> ao administrador para receber o código.';
};
A['gate.copyPix']=function(){RM.copy(cfg().pixKey||'')};
A['gate.activate']=function(){
  var msg=$('gateMsg'),code=String($('gateCode').value||'').trim();
  if(!code){msg.textContent='Cole o código de ativação enviado pelo administrador.';msg.className='gateMsg err';return}
  try{var r=JSON.parse(RM.br('AndroidLicense').activate(code));msg.textContent=r.message;msg.className='gateMsg '+(r.ok?'ok':'err');if(r.ok)setTimeout(L.check,900)}
  catch(e){msg.textContent='Não foi possível ativar. Tente novamente.';msg.className='gateMsg err'}
};
document.addEventListener('visibilitychange',function(){if(!document.hidden)L.check()});
setInterval(L.check,5*60*1000);
})();

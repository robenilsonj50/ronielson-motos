package br.com.ronielsonmotos.oficina;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import org.json.JSONObject;

/** Fotos antes/depois da ordem de serviço. Os arquivos ficam na pasta privada do app (files/fotos); o JSON do app guarda só o nome. */
public class PhotoBridge {
    public static final int REQUEST_CODE = 4711;
    private final Activity activity;
    private final WebView webView;
    private String pendingName;

    public PhotoBridge(Activity a, WebView w) { activity = a; webView = w; }

    private File dir() {
        File d = new File(activity.getFilesDir(), "fotos");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private String safe(String s) { return s == null ? "" : s.replaceAll("[^a-zA-Z0-9_-]", ""); }

    private File fileFor(String name) {
        if (name == null) return null;
        String n = new File(name).getName();
        if (!n.matches("[a-zA-Z0-9_.-]+")) return null;
        return new File(dir(), n);
    }

    private void js(String code) {
        if (webView != null) webView.evaluateJavascript(code, null);
    }

    private void cancelled() { js("window.onNativePhotoCancelled && window.onNativePhotoCancelled()"); }

    @JavascriptInterface
    public void capture(final String orderId, final String kind) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    if (activity.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        activity.requestPermissions(new String[]{Manifest.permission.CAMERA}, 913);
                        Toast.makeText(activity, "Permita o uso da câmera e toque novamente.", Toast.LENGTH_LONG).show();
                        cancelled();
                        return;
                    }
                    String name = "os" + safe(orderId) + "_" + safe(kind) + "_" + System.currentTimeMillis() + ".jpg";
                    File f = new File(dir(), name);
                    Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
                    Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                    i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    pendingName = name;
                    activity.startActivityForResult(i, REQUEST_CODE);
                } catch (Exception e) {
                    pendingName = null;
                    Toast.makeText(activity, "Não foi possível abrir a câmera: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    cancelled();
                }
            }
        });
    }

    /** Chamado pela MainActivity em onActivityResult. Retorna true se o resultado era da câmera de fotos. */
    public boolean handleResult(int requestCode, int resultCode) {
        if (requestCode != REQUEST_CODE) return false;
        String name = pendingName;
        pendingName = null;
        if (name == null) return true;
        File f = fileFor(name);
        if (resultCode == Activity.RESULT_OK && f != null && f.exists() && f.length() > 0) {
            shrink(f);
            js("window.onNativePhotoTaken && window.onNativePhotoTaken(" + JSONObject.quote(name) + ")");
        } else {
            if (f != null) f.delete();
            cancelled();
        }
        return true;
    }

    private int exifDegrees(String path) {
        try {
            int o = new ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) return 90;
            if (o == ExifInterface.ORIENTATION_ROTATE_180) return 180;
            if (o == ExifInterface.ORIENTATION_ROTATE_270) return 270;
        } catch (Exception ignored) { }
        return 0;
    }

    /** Reduz para no máximo ~1800 px, corrige a rotação e regrava como JPEG (economiza espaço do aparelho). */
    private void shrink(File f) {
        try {
            String path = f.getAbsolutePath();
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            int sample = 1;
            while (max / sample > 1800) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeFile(path, opts);
            if (b == null) return;
            int deg = exifDegrees(path);
            if (deg != 0) {
                Matrix m = new Matrix();
                m.postRotate(deg);
                Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (r != null && r != b) { b.recycle(); b = r; }
            }
            FileOutputStream out = new FileOutputStream(f);
            b.compress(Bitmap.CompressFormat.JPEG, 82, out);
            out.flush();
            out.close();
            b.recycle();
        } catch (Throwable ignored) { /* mantém o arquivo original */ }
    }

    /** Devolve a foto como data URI JPEG redimensionada (maxDim = lado maior). Vazio se não existir. */
    @JavascriptInterface
    public String getPhoto(String name, int maxDim) {
        try {
            File f = fileFor(name);
            if (f == null || !f.exists()) return "";
            String path = f.getAbsolutePath();
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            int target = maxDim <= 0 ? 1200 : maxDim;
            int sample = 1;
            while (max / (sample * 2) >= target) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeFile(path, opts);
            if (b == null) return "";
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 80, bos);
            b.recycle();
            return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) {
            return "";
        }
    }

    @JavascriptInterface
    public boolean deletePhoto(String name) {
        try {
            File f = fileFor(name);
            return f != null && f.exists() && f.delete();
        } catch (Exception e) {
            return false;
        }
    }
}

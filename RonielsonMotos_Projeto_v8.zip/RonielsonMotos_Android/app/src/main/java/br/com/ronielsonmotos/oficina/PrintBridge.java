package br.com.ronielsonmotos.oficina;

import android.app.Activity;
import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Imprime/salva em PDF um HTML (orçamento, ordem de serviço, fechamento de caixa) usando o diálogo de impressão do Android. */
public class PrintBridge {
    private final Activity activity;
    private WebView printView; // referência mantida enquanto o diálogo de impressão está aberto

    public PrintBridge(Activity a) { activity = a; }

    @JavascriptInterface
    public void printHtml(final String html, final String title) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    final String job = (title == null || title.length() == 0) ? "Documento" : title;
                    final boolean[] started = new boolean[]{false};
                    WebView w = new WebView(activity);
                    w.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            if (started[0]) return;
                            started[0] = true;
                            try {
                                PrintManager pm = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(job);
                                pm.print(job, adapter, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                            } catch (Exception e) {
                                Toast.makeText(activity, "Não foi possível abrir a impressão: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    printView = w;
                    w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(activity, "Falha ao preparar o documento: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}

package br.com.ronielsonmotos.oficina;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.content.pm.PackageManager;
import android.Manifest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.graphics.Color;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.json.JSONObject;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 7821;
    private static final long TRIAL_MILLIS = 30L * 24L * 60L * 60L * 1000L;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,16,32));
        getWindow().setNavigationBarColor(Color.rgb(11,16,32));
        webView = new WebView(this); webView.setBackgroundColor(Color.rgb(11,16,32));
        WebSettings settings=webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new BackupBridge(this),"AndroidBackup");
        webView.addJavascriptInterface(new ScannerBridge(this),"AndroidScanner");
        webView.addJavascriptInterface(new LicenseBridge(this),"AndroidLicense");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(PermissionRequest request){ runOnUiThread(()->{ boolean camera=false; for(String resource:request.getResources()){if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource))camera=true;} if(camera && checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}); else request.deny(); }); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null)filePathCallback.onReceiveValue(null); filePathCallback=callback;
                Intent intent=new Intent(Intent.ACTION_GET_CONTENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json");
                try{startActivityForResult(Intent.createChooser(intent,"Selecionar backup JSON"),FILE_CHOOSER_REQUEST);}catch(Exception e){filePathCallback=null;Toast.makeText(MainActivity.this,"Não foi possível abrir os arquivos.",Toast.LENGTH_LONG).show();return false;} return true;
            }
        }); setContentView(webView); if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_REQUEST); webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        IntentResult scanResult=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if(scanResult!=null){
            String value=scanResult.getContents();
            if(value!=null && webView!=null){
                String escaped=JSONObject.quote(value);
                webView.evaluateJavascript("window.onNativeBarcodeScanned && window.onNativeBarcodeScanned("+escaped+")",null);
            } else if(webView!=null){webView.evaluateJavascript("window.onNativeBarcodeCancelled && window.onNativeBarcodeCancelled()",null);}
        }
        if(requestCode==FILE_CHOOSER_REQUEST&&filePathCallback!=null){Uri[] results=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)results=new Uri[]{data.getData()};filePathCallback.onReceiveValue(results);filePathCallback=null;}
    }

    private static final int CAMERA_PERMISSION_REQUEST = 913;
    private boolean pendingScan = false;

    private void notifyScanCancelled(){
        if(webView!=null)webView.evaluateJavascript("window.onNativeBarcodeCancelled && window.onNativeBarcodeCancelled()",null);
    }

    private void launchScanner(){
        try{
            IntentIntegrator integrator=new IntentIntegrator(this);
            integrator.setCaptureActivity(BarcodeCaptureActivity.class);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
            integrator.setPrompt("Aponte a câmera para o código de barras");
            integrator.setCameraId(0); integrator.setBeepEnabled(false); integrator.setBarcodeImageEnabled(false);
            integrator.setOrientationLocked(false); integrator.initiateScan();
        }catch(Throwable t){
            Toast.makeText(this,"Não foi possível abrir o leitor: "+t.getMessage(),Toast.LENGTH_LONG).show();
            notifyScanCancelled();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode!=CAMERA_PERMISSION_REQUEST)return;
        boolean granted=grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED;
        if(pendingScan){
            pendingScan=false;
            if(granted){launchScanner();}
            else{Toast.makeText(this,"Permissão da câmera negada. Ative em Configurações > Apps > Ronielson Motos > Permissões, ou digite o código.",Toast.LENGTH_LONG).show();notifyScanCancelled();}
        }
    }

    public class ScannerBridge {
        private final Activity activity; ScannerBridge(Activity a){activity=a;}
        @JavascriptInterface public void scan(String target){runOnUiThread(()->{
            if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED){launchScanner();}
            else{pendingScan=true;requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_REQUEST);}
        });}
    }

    public class LicenseBridge {
        // Chave PÚBLICA (X.509/DER em Base64). Ela só VERIFICA os códigos; a chave privada fica somente com o administrador.
        private static final String PUBLIC_KEY_B64 = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEuk3CaRa4Lk+E+ZldMilV2mi7+KjTFEQUzHLWSDBQAtoJoP82F60xYj4GrQ8GSjDc8AdmHWmkmi77hMYuWWi0VA==";
        private static final long DAY_MS = 24L*60L*60L*1000L;
        private final Context context; LicenseBridge(Context c){context=c;}
        private android.content.SharedPreferences prefs(){return context.getSharedPreferences("ronielson_license",Context.MODE_PRIVATE);}

        private String rawDeviceId(){
            try{
                String id=android.provider.Settings.Secure.getString(context.getContentResolver(),android.provider.Settings.Secure.ANDROID_ID);
                if(id==null||id.length()==0){
                    android.content.SharedPreferences p=prefs(); id=p.getString("fallback_id",null);
                    if(id==null){id=java.util.UUID.randomUUID().toString();p.edit().putString("fallback_id",id).apply();}
                }
                java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");
                byte[] h=md.digest(("RM|"+id).getBytes("UTF-8"));
                StringBuilder sb=new StringBuilder();
                for(int i=0;i<6;i++)sb.append(String.format(java.util.Locale.US,"%02X",h[i]&0xff));
                return sb.toString();
            }catch(Exception e){return "000000000000";}
        }
        private String prettyId(String raw){return raw.substring(0,4)+"-"+raw.substring(4,8)+"-"+raw.substring(8,12);}

        // Relógio protegido: nunca volta atrás. Se o relógio for atrasado em mais de 24h, o teste fica vencido.
        private long touchClock(){
            android.content.SharedPreferences p=prefs(); long real=System.currentTimeMillis(); long last=p.getLong("last_seen",0L);
            if(last>0L&&real<last-DAY_MS)p.edit().putBoolean("expired_by_clock_change",true).apply();
            if(real>last)p.edit().putLong("last_seen",real).apply();
            return Math.max(real,last);
        }

        // Retorna o fim da validade (ms) se o código for autêntico e deste aparelho; -1 se inválido; -2 se for de outro aparelho.
        private long checkCode(String code){
            try{
                if(code==null)return -1L;
                String c=code.replaceAll("\\s+","");
                int dot=c.indexOf('.'); if(dot<=0||dot>=c.length()-1)return -1L;
                byte[] payloadBytes=android.util.Base64.decode(c.substring(0,dot),android.util.Base64.URL_SAFE);
                byte[] sig=android.util.Base64.decode(c.substring(dot+1),android.util.Base64.URL_SAFE);
                java.security.PublicKey pk=java.security.KeyFactory.getInstance("EC").generatePublic(new java.security.spec.X509EncodedKeySpec(android.util.Base64.decode(PUBLIC_KEY_B64,android.util.Base64.DEFAULT)));
                java.security.Signature s=java.security.Signature.getInstance("SHA256withECDSA"); s.initVerify(pk); s.update(payloadBytes);
                if(!s.verify(sig))return -1L;
                String[] parts=new String(payloadBytes,"UTF-8").split("\\|");
                if(parts.length!=3||!"RM1".equals(parts[0]))return -1L;
                if(!parts[1].equalsIgnoreCase(rawDeviceId()))return -2L;
                String d=parts[2]; if(d.length()!=8)return -1L;
                int y=Integer.parseInt(d.substring(0,4)),m=Integer.parseInt(d.substring(4,6)),day=Integer.parseInt(d.substring(6,8));
                java.util.Calendar cal=java.util.Calendar.getInstance(); cal.clear(); cal.set(y,m-1,day,23,59,59);
                return cal.getTimeInMillis();
            }catch(Exception e){return -1L;}
        }

        @JavascriptInterface public String getDeviceId(){return prettyId(rawDeviceId());}

        @JavascriptInterface public String activate(String code){
            try{
                JSONObject r=new JSONObject(); long exp=checkCode(code);
                if(exp==-2L){r.put("ok",false);r.put("message","Este código é de outro aparelho. Envie ao administrador o ID mostrado nesta tela.");return r.toString();}
                if(exp<0L){r.put("ok",false);r.put("message","Código inválido. Confira se copiou o código inteiro.");return r.toString();}
                long now=touchClock();
                if(exp<now){r.put("ok",false);r.put("message","Este código já venceu. Peça um código novo ao administrador.");return r.toString();}
                android.content.SharedPreferences p=prefs(); String old=p.getString("lic_code",null); long oldExp=old==null?-1L:checkCode(old);
                if(oldExp>exp){r.put("ok",true);r.put("message","Seu acesso já está ativo até uma data posterior.");return r.toString();}
                p.edit().putString("lic_code",code.replaceAll("\\s+","")).apply();
                r.put("ok",true);r.put("message","Ativado com sucesso!");return r.toString();
            }catch(Exception e){return "{\"ok\":false,\"message\":\"Falha ao ativar. Tente novamente.\"}";}
        }

        @JavascriptInterface public String getTrialStatus(){
            try{
                android.content.SharedPreferences p=prefs(); long real=System.currentTimeMillis();
                if(p.getLong("trial_start",0L)==0L)p.edit().putLong("trial_start",real).putLong("last_seen",real).apply();
                long now=touchClock(); long start=p.getLong("trial_start",real);
                long elapsed=Math.max(0L,now-start), remaining=Math.max(0L,TRIAL_MILLIS-elapsed);
                boolean trialActive=!p.getBoolean("expired_by_clock_change",false)&&elapsed<TRIAL_MILLIS;
                String code=p.getString("lic_code",null); long exp=code==null?-1L:checkCode(code);
                boolean hadLicense=exp>0L; boolean licensed=hadLicense&&now<=exp;
                String mode=licensed?"licensed":(trialActive?"trial":"expired");
                long days=licensed?(exp-now+DAY_MS-1L)/DAY_MS:(remaining+DAY_MS-1L)/DAY_MS;
                JSONObject r=new JSONObject();
                r.put("active",licensed||trialActive); r.put("mode",mode); r.put("hadLicense",hadLicense);
                r.put("remainingDays",(licensed||trialActive)?days:0L); r.put("trialDays",30); r.put("trialStart",start);
                r.put("deviceId",prettyId(rawDeviceId()));
                if(hadLicense){
                    java.util.Calendar c=java.util.Calendar.getInstance(); c.setTimeInMillis(exp);
                    r.put("licenseYear",c.get(java.util.Calendar.YEAR));
                    r.put("licenseDate",String.format(java.util.Locale.US,"%02d/%02d/%04d",c.get(java.util.Calendar.DAY_OF_MONTH),c.get(java.util.Calendar.MONTH)+1,c.get(java.util.Calendar.YEAR)));
                }
                return r.toString();
            }catch(Exception e){return "{\"active\":false,\"mode\":\"expired\",\"remainingDays\":0,\"trialDays\":30,\"deviceId\":\"\"}";}
        }

        @JavascriptInterface public void copyText(String text){runOnUiThread(()->{try{
            android.content.ClipboardManager cm=(android.content.ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Ronielson Motos",text==null?"":text));
            Toast.makeText(context,"Copiado",Toast.LENGTH_SHORT).show();
        }catch(Exception ignored){}});}

        @JavascriptInterface public void openExternal(String url){runOnUiThread(()->{try{
            if(url==null||!url.startsWith("https://"))return;
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i);
        }catch(Exception e){Toast.makeText(context,"Não foi possível abrir o link.",Toast.LENGTH_LONG).show();}});}
    }
    public class BackupBridge {
        private final Context context; BackupBridge(Context c){context=c;}
        @JavascriptInterface public void saveBackup(String json,String filename){runOnUiThread(()->{OutputStream output=null;try{
            String safe=filename==null?"backup-ronielson-motos.json":filename.replaceAll("[^a-zA-Z0-9._-]","_");
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,safe);values.put(MediaStore.Downloads.MIME_TYPE,"application/json");values.put(MediaStore.Downloads.RELATIVE_PATH,"Download");values.put(MediaStore.Downloads.IS_PENDING,1);Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("Não foi possível criar o arquivo.");output=getContentResolver().openOutputStream(uri);if(output==null)throw new IOException("Não foi possível gravar o arquivo.");output.write(json.getBytes("UTF-8"));output.flush();output.close();output=null;ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,done,null,null);
            }else{File dir=getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);if(dir==null)throw new IOException("Pasta de downloads indisponível.");output=new FileOutputStream(new File(dir,safe));output.write(json.getBytes("UTF-8"));output.flush();output.close();output=null;}
            Toast.makeText(context,"Backup salvo em Downloads: "+safe,Toast.LENGTH_LONG).show();
        }catch(Exception e){try{if(output!=null)output.close();}catch(Exception ignored){}Toast.makeText(context,"Falha ao salvar backup: "+e.getMessage(),Toast.LENGTH_LONG).show();}});}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}

/* pc-pages.js — telas e recursos exclusivos da versão para computador */
(function(){
'use strict';
var RM=window.RM,ui=RM.ui,d=RM.d,esc=RM.esc,money=RM.money,A=RM.act,pages=RM.pages,CH=RM.charts,BC=RM.barcode,P=RM.print;
function DATA(){return RM.data}
var pc=RM.pc={};

/* ======================= TABELA ORDENÁVEL ======================= */
ui.table=function(o){
  var sort=ui.q['sort:'+o.id]||o.sort||null,rows=o.rows.slice();
  if(sort){var col=o.cols.filter(function(c){return c.k===sort.k})[0];
    if(col&&col.sort){var dir=sort.dir==='desc'?-1:1;rows.sort(function(a,b){var x=col.sort(a),y=col.sort(b);if(typeof x==='number'&&typeof y==='number')return (x-y)*dir;return String(x).localeCompare(String(y),'pt-BR',{numeric:true})*dir})}}
  var head=o.cols.map(function(c){var arrow=sort&&sort.k===c.k?(sort.dir==='desc'?' ▼':' ▲'):'';
    return '<th class="'+(c.align==='r'?'r':'')+(c.sort?' sortable':'')+'"'+(c.sort?' data-act="tbl.sort" data-tbl="'+o.id+'" data-k="'+c.k+'" title="Ordenar"':'')+'>'+esc(c.label)+arrow+'</th>'}).join('');
  var body=rows.map(function(r){
    return '<tr'+(o.rowAct?' data-act="'+o.rowAct+'" data-id="'+esc(r.id)+'"':'')+(o.rowClass?' class="'+o.rowClass(r)+'"':'')+'>'+o.cols.map(function(c){return '<td class="'+(c.align==='r'?'r':'')+'">'+c.get(r)+'</td>'}).join('')+'</tr>';
  }).join('');
  return '<div class="tablewrap"><table class="tbl"><thead><tr>'+head+'</tr></thead><tbody>'+body+'</tbody></table><div class="tblfoot">'+rows.length+' registro(s)</div></div>';
};
A['tbl.sort']=function(ds){
  var key='sort:'+ds.tbl,cur=ui.q[key];
  ui.q[key]=(cur&&cur.k===ds.k)?{k:ds.k,dir:cur.dir==='asc'?'desc':'asc'}:{k:ds.k,dir:'asc'};
  ui.renderList(ds.tbl);
};

/* ======================= ORDENS: tabela + quadro Kanban ======================= */
var ORDER_COLS=[
  {k:'number',label:'Nº',sort:function(o){return o.number},get:function(o){return '<b>#'+esc(o.number)+'</b>'}},
  {k:'date',label:'Data',sort:function(o){return o.created||''},get:function(o){return RM.dateBR(o.created)}},
  {k:'customer',label:'Cliente',sort:function(o){return o.customer||''},get:function(o){return '<b>'+esc(o.customer||'—')+'</b>'}},
  {k:'bike',label:'Moto / placa',sort:function(o){return o.bike||''},get:function(o){var c=o.plate?null:P.customerOf(o);return esc(String(o.bike||'—').replace(/ — .*$/,''))+((o.plate||(c&&c.plate))?' <span class="muted">· '+esc(o.plate||c.plate)+'</span>':'')}},
  {k:'problem',label:'Serviço',get:function(o){return '<span class="clip">'+esc(o.problem||'')+'</span>'}},
  {k:'status',label:'Situação',sort:function(o){return d.STATUSES.indexOf(o.status)},get:function(o){return ui.statusPill(o.status)+(d.inWarranty(o,RM.today())?' '+ui.pill('Garantia','green'):'')}},
  {k:'total',label:'Total',align:'r',sort:function(o){return d.orderTotal(o)},get:function(o){return money(d.orderTotal(o))}},
  {k:'bal',label:'Saldo',align:'r',sort:function(o){return d.balance(o)},get:function(o){var b=d.balance(o);return b>0?'<span class="owe">'+money(b)+'</span>':'<span class="muted">—</span>'}}
];
var BOARD=['Orçamento','Aprovada','Em andamento','Aguardando peça','Concluída','Entregue'];
function boardColumn(status){return status==='Aberta'?'Aprovada':status}
pc.boardData=function(){
  var f=ui.q.ordersFilter;ui.q.ordersFilter='all';var list=pages.orders.filtered();ui.q.ordersFilter=f;
  var cols={};BOARD.forEach(function(s){cols[s]=[]});
  list.forEach(function(o){var s=boardColumn(o.status);if(cols[s])cols[s].push(o)});
  BOARD.forEach(function(s){cols[s].sort(function(a,b){return String(d.orderDate(b)||b.created).localeCompare(String(d.orderDate(a)||a.created))||String(b.number).localeCompare(String(a.number))})});
  return cols;
};
function kcard(o){
  var bal=d.balance(o),m=o.mechanicId&&DATA().mechanics.find(function(x){return x.id===o.mechanicId});
  return '<div class="kcard" draggable="true" data-act="order.view" data-id="'+esc(o.id)+'"><div class="ktop"><b>#'+esc(o.number)+'</b><span class="muted small">'+RM.dateBR(o.created)+'</span></div>'
   +'<div class="kname">'+esc(o.customer||'Cliente')+'</div><div class="muted small">'+esc(String(o.bike||'').replace(/ — .*$/,''))+(o.plate?' · '+esc(o.plate):'')+'</div>'
   +(o.problem?'<div class="small clip2">'+esc(o.problem)+'</div>':'')
   +'<div class="kfoot"><b>'+money(d.orderTotal(o))+'</b>'+(bal>0?'<span class="owe">Deve '+money(bal)+'</span>':'')+(m?'<span class="chipmini">'+esc(m.name.split(' ')[0])+'</span>':'')+'</div></div>';
}
pc.boardHtml=function(){
  var cols=pc.boardData(),owner=ui.isOwner();
  return '<div class="board">'+BOARD.map(function(s){
    var list=cols[s],done=d.isDone(s),shown=done?list.slice(0,25):list,sum=RM.r2(list.reduce(function(a,o){return a+d.orderTotal(o)},0));
    return '<div class="kcol" data-status="'+esc(s)+'"><div class="khead"><span class="kdot" style="background:'+CH.STATUS_COLORS[s]+'"></span><b>'+esc(s)+'</b><span class="kcount">'+list.length+'</span>'+(owner&&list.length?'<span class="ksum">'+esc(CH.compact(sum))+'</span>':'')+'</div><div class="kbody">'
      +(shown.map(kcard).join('')||'<div class="kempty">Solte uma ordem aqui</div>')+(list.length>shown.length?'<div class="kempty">+ '+(list.length-shown.length)+' mais antigas (use a Lista)</div>':'')+'</div></div>';
  }).join('')+'</div><p class="muted small" style="margin-top:8px">Arraste os cartões entre as colunas para mudar a situação da ordem. As peças saem do estoque ao iniciar o serviço.</p>';
};
pc.moveOrder=function(id,status){
  var o=DATA().orders.find(function(x){return x.id===id});if(!o)return false;
  if(boardColumn(o.status)===status)return false;
  RM.changeStatus(id,status);return true;
};
pages.orders.list=function(){
  if(ui.q.ordersView==='board')return pc.boardHtml();
  var list=pages.orders.filtered();
  return list.length?ui.table({id:'orders',cols:ORDER_COLS,rows:list,rowAct:'order.view',sort:{k:'date',dir:'desc'}}):ui.empty('Nenhuma ordem encontrada','Ajuste o filtro ou crie um novo orçamento.');
};
pages.orders.render=function(){
  var cur=ui.q.ordersFilter||'all',board=ui.q.ordersView==='board',F=RM.ORDER_FILTERS;
  var chips=Object.keys(F).map(function(k){return '<button type="button" class="chip'+(cur===k?' active':'')+'" data-act="orders.filter" data-k="'+k+'">'+esc(F[k][0])+'</button>'}).join('');
  var toggle='<div class="viewtoggle"><button type="button" class="'+(board?'':'active')+'" data-act="pc.view" data-v="list">☰ Lista</button><button type="button" class="'+(board?'active':'')+'" data-act="pc.view" data-v="board">▥ Quadro</button></div>';
  return '<div class="toolbar"><h2>Ordens de serviço</h2><div class="toolbar-r">'+toggle+'<button type="button" class="btn primary" data-act="order.new" data-status="Orçamento">＋ Novo orçamento <kbd>N</kbd></button></div></div>'
   +'<div class="card">'+(board?'':'<div class="chips">'+chips+'</div>')+'<div class="toolbar">'+ui.searchBox('orders','Buscar nº, cliente, moto, placa ou serviço...  ( / )')+'</div><div id="list-orders">'+pages.orders.list()+'</div></div>';
};
A['pc.view']=function(ds){ui.q.ordersView=ds.v;ui.render(true)};
document.addEventListener('dragstart',function(e){var c=e.target&&e.target.closest?e.target.closest('.kcard'):null;if(!c)return;try{e.dataTransfer.setData('text/plain',c.getAttribute('data-id'));e.dataTransfer.effectAllowed='move'}catch(x){}c.classList.add('drag')});
document.addEventListener('dragend',function(e){var c=e.target&&e.target.closest?e.target.closest('.kcard'):null;if(c)c.classList.remove('drag')});
document.addEventListener('dragover',function(e){var col=e.target&&e.target.closest?e.target.closest('.kcol'):null;if(col){e.preventDefault();col.classList.add('over')}});
document.addEventListener('dragleave',function(e){var col=e.target&&e.target.closest?e.target.closest('.kcol'):null;if(col&&!(e.relatedTarget&&col.contains&&col.contains(e.relatedTarget)))col.classList.remove('over')});
document.addEventListener('drop',function(e){
  var col=e.target&&e.target.closest?e.target.closest('.kcol'):null;if(!col)return;e.preventDefault();col.classList.remove('over');
  var id='';try{id=e.dataTransfer.getData('text/plain')}catch(x){}
  if(id)pc.moveOrder(id,col.getAttribute('data-status'));
});

/* ======================= CLIENTES: tabela ======================= */
pages.customers.list=function(){
  var data=DATA(),owe={};d.debtors(data).forEach(function(x){owe[x.key]=x.total});
  var rows=pages.customers.filtered().map(function(c){var os=d.vehicleOrders(data,c),last=os.filter(function(o){return d.isDone(o.status)})[0];return {id:c.id,c:c,n:os.length,last:last?d.orderDate(last):'',owe:owe[c.id]||0}});
  var owner=ui.isOwner();
  var cols=[
    {k:'name',label:'Cliente',sort:function(r){return r.c.name},get:function(r){return '<b>'+esc(r.c.name)+'</b>'}},
    {k:'phone',label:'Telefone',get:function(r){return esc(r.c.phone||'—')}},
    {k:'bike',label:'Moto',sort:function(r){return r.c.bike||''},get:function(r){return esc(r.c.bike||'—')}},
    {k:'plate',label:'Placa',sort:function(r){return r.c.plate||''},get:function(r){return '<span class="mono">'+esc(r.c.plate||'—')+'</span>'}},
    {k:'km',label:'Km',align:'r',sort:function(r){return RM.num(r.c.km)},get:function(r){return r.c.km!==''&&r.c.km!=null?RM.num(r.c.km).toLocaleString('pt-BR'):'—'}},
    {k:'n',label:'Serviços',align:'r',sort:function(r){return r.n},get:function(r){return String(r.n)}},
    {k:'last',label:'Última visita',sort:function(r){return r.last},get:function(r){return r.last?RM.dateBR(r.last):'—'}}
  ];
  if(owner)cols.push({k:'owe',label:'Em aberto',align:'r',sort:function(r){return r.owe},get:function(r){return r.owe>0?'<span class="owe">'+money(r.owe)+'</span>':'<span class="muted">—</span>'}});
  return rows.length?ui.table({id:'customers',cols:cols,rows:rows,rowAct:'customer.view',sort:{k:'name',dir:'asc'}}):ui.empty(ui.q.customers?'Nada encontrado':'Nenhum cliente cadastrado',ui.q.customers?'Tente outro nome, telefone ou placa.':'Cadastre clientes e suas motocicletas.');
};

/* ======================= ESTOQUE: tabela + etiquetas ======================= */
pages.inventory.list=function(){
  var owner=ui.isOwner(),rows=pages.inventory.filtered();
  var cols=[
    {k:'name',label:'Peça',sort:function(p){return p.name},get:function(p){return '<b>'+esc(p.name)+'</b>'}},
    {k:'sku',label:'Código',sort:function(p){return p.sku||''},get:function(p){return '<span class="mono">'+esc(p.sku||'—')+'</span>'}},
    {k:'qty',label:'Qtd',align:'r',sort:function(p){return RM.num(p.qty)},get:function(p){var low=RM.num(p.qty)<=RM.num(p.min);return '<b class="'+(low?'warn':'')+'">'+RM.num(p.qty)+'</b>'+(low?' '+ui.pill('Baixo','yellow'):'')}},
    {k:'min',label:'Mín.',align:'r',sort:function(p){return RM.num(p.min)},get:function(p){return String(RM.num(p.min))}}
  ];
  if(owner)cols.push({k:'cost',label:'Custo',align:'r',sort:function(p){return RM.num(p.cost)},get:function(p){return money(p.cost)}});
  cols.push({k:'price',label:'Venda',align:'r',sort:function(p){return RM.num(p.price)},get:function(p){return money(p.price)}});
  if(owner)cols.push({k:'margin',label:'Margem',align:'r',sort:function(p){return d.margin(p)},get:function(p){return d.margin(p)+'%'}});
  cols.push({k:'act',label:'',align:'r',get:function(p){return '<div class="btnrow tight"><button type="button" class="btn sm" data-act="part.adj" data-id="'+esc(p.id)+'" data-delta="-1">−1</button><button type="button" class="btn sm" data-act="part.adj" data-id="'+esc(p.id)+'" data-delta="1">+1</button>'+(owner?'<button type="button" class="btn sm" data-act="part.edit" data-id="'+esc(p.id)+'">✏️</button><button type="button" class="btn danger sm" data-act="part.del" data-id="'+esc(p.id)+'">🗑</button>':'')+'</div>'}});
  return rows.length?ui.table({id:'inventory',cols:cols,rows:rows,sort:{k:'name',dir:'asc'}}):ui.empty(DATA().parts.length?'Nenhuma peça encontrada':'Estoque vazio',DATA().parts.length?'Ajuste a busca ou o filtro.':'Cadastre suas primeiras peças.');
};
var invRender=pages.inventory.render;
pages.inventory.render=function(){var h=invRender();return ui.isOwner()?h.replace('＋ Cadastrar peça</button>','＋ Cadastrar peça <kbd>P</kbd></button><button type="button" class="btn" data-act="pc.labels">🏷 Etiquetas</button>'):h};
A['pc.part']=function(ds){ui.q.inventory=ds.name;ui.q.invFilter='all';ui.go('inventory')};
A['pc.fin']=function(ds){ui.tab.finance=ds.tab;ui.go('finance')};

/* ---- etiquetas com código de barras ---- */
var lab=null;
function labelsBody(){
  var parts=DATA().parts.slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name))}),noCode=parts.filter(function(p){return !p.sku}).length;
  var rows=parts.map(function(p){var on=!!lab.sel[p.id];return '<tr><td><input type="checkbox" data-bind="sel.'+esc(p.id)+'"'+(on?' checked':'')+(p.sku?'':' disabled')+'></td><td><b>'+esc(p.name)+'</b></td><td class="mono">'+(p.sku?esc(p.sku):'<span class="warn">sem código</span>')+'</td><td class="r">'+money(p.price)+'</td><td class="r"><input class="qtyin" type="number" min="1" max="200" data-bind="qty.'+esc(p.id)+'" value="'+esc(lab.qty[p.id]||1)+'"'+(p.sku?'':' disabled')+'></td></tr>'}).join('');
  return '<p class="muted small">Marque as peças e a quantidade de etiquetas. Folha A4 com 21 etiquetas (3 × 7). O código impresso é lido pelo leitor do celular e pelo leitor USB.</p>'
   +(noCode?'<div class="notice">'+noCode+' peça(s) sem código. <button type="button" class="btn sm" data-act="pc.labelsGen">Gerar códigos internos</button></div>':'')
   +'<div class="btnrow tight" style="justify-content:flex-start"><button type="button" class="btn sm" data-act="pc.labelsAll">Marcar todas</button><button type="button" class="btn sm" data-act="pc.labelsLow">Só as em falta (repor)</button><button type="button" class="btn sm" data-act="pc.labelsNone">Limpar</button></div>'
   +'<div class="tablewrap" style="max-height:48vh;overflow:auto"><table class="tbl"><thead><tr><th></th><th>Peça</th><th>Código</th><th class="r">Venda</th><th class="r">Etiquetas</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
}
pc.labelItems=function(){
  var items=[];DATA().parts.forEach(function(p){if(lab.sel[p.id]&&p.sku)items.push({name:p.name,price:p.price,code:p.sku,copies:lab.qty[p.id]||1})});return items;
};
A['pc.labels']=function(){
  lab={sel:{},qty:{}};
  ui.open({title:'Etiquetas de código de barras',submitLabel:'🖨 Imprimir etiquetas',render:labelsBody,
    onBind:function(k,v,el){var m=/^(sel|qty)\.(.+)$/.exec(k);if(!m)return;if(m[1]==='sel')lab.sel[m[2]]=!!el.checked;else lab.qty[m[2]]=Math.max(1,Math.min(200,parseInt(v,10)||1))},
    onSubmit:function(){var items=pc.labelItems();if(!items.length){ui.toast('Marque pelo menos uma peça com código.','err');return false}P.doc(BC.sheetHtml(items,DATA().settings.company.name),'Etiquetas')}});
};
A['pc.labelsAll']=function(){DATA().parts.forEach(function(p){if(p.sku)lab.sel[p.id]=true});ui.refresh()};
A['pc.labelsNone']=function(){lab.sel={};ui.refresh()};
A['pc.labelsLow']=function(){lab.sel={};d.lowParts(DATA()).forEach(function(p){if(p.sku){lab.sel[p.id]=true;lab.qty[p.id]=Math.max(1,d.restock(DATA()).filter(function(x){return x.part.id===p.id})[0].suggest)}});ui.refresh()};
A['pc.labelsGen']=function(){
  var data=DATA(),n=0;data.parts.forEach(function(p){if(!p.sku){p.sku=BC.nextInternalCode(data);n++}});
  RM.persist();ui.refresh();ui.toast(n+' código(s) interno(s) gerado(s). Eles ficam salvos na peça.');
};

/* ======================= VISÃO GERAL com gráficos ======================= */
var baseDash=pages.dashboard.render;
pages.dashboard.render=function(){
  var html=baseDash(),data=DATA(),owner=ui.isOwner(),today=RM.today(),cards='';
  if(owner){
    cards+='<div class="card"><div class="cardhead"><h2>Faturamento e lucro</h2><span class="legendline"><i style="background:#60a5fa"></i>Faturamento<i style="background:#34d399"></i>Lucro líquido</span></div>'+CH.barsSvg(CH.monthly(data,today,6))+'<div class="muted small">Últimos 6 meses · considera ordens concluídas/entregues</div></div>';
  }
  var dn=CH.donut(CH.statusItems(data));
  cards+='<div class="card"><div class="cardhead"><h2>Ordens por situação</h2></div><div class="donutbox">'+dn.svg+'<div class="legend">'+dn.legend+'</div></div></div>';
  var ag=pc.agenda(data,today,owner);
  cards+='<div class="card"><div class="cardhead"><h2>Agenda dos próximos 7 dias</h2></div>'+(ag.length?'<div class="list">'+ag.map(function(x){return '<div class="hrow static"><div>'+x.icon+' <b>'+esc(x.title)+'</b><div class="muted small">'+esc(x.sub)+'</div></div><div class="item-side"><span class="'+(x.late?'owe':'muted')+'">'+esc(x.when)+'</span></div></div>'}).join('')+'</div>':ui.empty('Nada agendado','Revisões e contas a vencer aparecem aqui.'))+'</div>';
  if(owner){var top=CH.topParts(data,today);cards+='<div class="card"><div class="cardhead"><h2>Peças mais vendidas (30 dias)</h2></div>'+(top.length?top.map(function(x){return '<div class="payrow"><span>'+esc(x.name)+'</span><b>'+x.qty+' un · '+money(x.revenue)+'</b></div>'}).join(''):'<div class="muted small">Sem vendas de peças no período.</div>')+'</div>'}
  return html.replace('<div class="grid2">','<div class="grid2 charts">'+cards+'</div><div class="grid2">');
};
pc.agenda=function(data,today,owner){
  var out=[];
  d.reminders(data,today,7).forEach(function(r){out.push({date:r.date,icon:'⏰',title:r.customer.name+' — revisão',sub:(r.customer.bike||'Moto')+(r.customer.plate?' · '+r.customer.plate:''),when:r.overdue?'atrasada':RM.dateBR(r.date),late:r.overdue})});
  if(owner)d.payablesPending(data).filter(function(x){return x.due<=RM.addDays(today,7)}).forEach(function(x){out.push({date:x.due,icon:'💳',title:x.desc+' — '+money(x.amount),sub:x.supplier||x.category,when:x.due<today?'vencida':RM.dateBR(x.due),late:x.due<today})});
  out.sort(function(a,b){return a.date.localeCompare(b.date)});return out.slice(0,8);
};

/* ======================= AJUSTES: planilhas, etiquetas, atalhos ======================= */
var baseSet=pages.settings.render;
pages.settings.render=function(){
  var ex=[['clientes','Clientes'],['estoque','Estoque'],['ordens','Ordens de serviço'],['itens','Peças das ordens'],['caixa','Caixa'],['pagar','Contas a pagar'],['receber','A receber (fiado)']];
  return baseSet()+'<div class="card" style="margin-top:16px"><div class="cardhead"><h2>Computador</h2></div>'
   +'<p class="muted">Exporte para o <b>Excel</b> (arquivos .csv abrem direto, com acentos e vírgula decimal).</p><div class="btnrow" style="margin-top:6px">'+ex.map(function(x){return '<button type="button" class="btn" data-act="pc.exportOne" data-key="'+x[0]+'">⬇ '+esc(x[1])+'</button>'}).join('')+'</div>'
   +'<div class="btnrow"><button type="button" class="btn" data-act="pc.labels">🏷 Imprimir etiquetas de código de barras</button><button type="button" class="btn" data-act="pc.help">⌨ Atalhos do teclado</button></div>'
   +'<div class="note small">Seus dados ficam guardados neste computador, dentro do perfil “Ronielson Motos” do navegador. Faça backup com frequência e guarde o arquivo fora do PC.</div></div>';
};
A['pc.exportOne']=function(ds){if(!RM.csv.exportOne(ds.key))ui.toast('Nada para exportar.','err');else ui.toast('Planilha gerada. Veja a pasta Downloads.')};
A['pc.export']=function(){ui.go('settings')};

/* ======================= BUSCA GLOBAL (Ctrl+K) E ATALHOS ======================= */
var pal=pc.palette={open:false,q:'',items:[],sel:0};
pal.render=function(){
  var el=RM.$('palList');if(!el)return;
  el.innerHTML=pal.items.length?pal.items.map(function(x,i){return '<div class="palitem'+(i===pal.sel?' sel':'')+'" data-act="pal.pick" data-i="'+i+'"><span class="tag t'+esc(x.type.charAt(0))+'">'+esc(x.type)+'</span><span class="pt"><b>'+esc(x.title)+'</b><small>'+esc(x.sub||'')+'</small></span></div>'}).join(''):'<div class="palempty">Nada encontrado para “'+esc(pal.q)+'”.</div>';
};
pal.query=function(q){pal.q=q;pal.items=RM.searchTools.run(q,ui.isOwner(),DATA());pal.sel=0;pal.render()};
pal.show=function(){var el=RM.$('palette');if(!el)return;pal.open=true;el.classList.add('show');var i=RM.$('palInput');if(i){i.value='';try{i.focus()}catch(e){}}pal.query('')};
pal.hide=function(){var el=RM.$('palette');pal.open=false;if(el)el.classList.remove('show')};
pal.move=function(delta){if(!pal.items.length)return;pal.sel=(pal.sel+delta+pal.items.length)%pal.items.length;pal.render()};
pal.pick=function(i){var x=pal.items[i==null?pal.sel:i];pal.hide();if(!x)return;var fn=A[x.act];if(fn)fn(x.ds||{})};
A['pc.palette']=function(){pal.show()};
A['pal.pick']=function(ds){pal.pick(+ds.i)};
A['pal.close']=function(){pal.hide()};
document.addEventListener('input',function(e){if(e.target&&e.target.id==='palInput')pal.query(e.target.value)});

A['pc.help']=function(){
  var rows=[['Ctrl + K','Busca global (clientes, placas, ordens, peças, ações)'],['N','Novo orçamento'],['C','Novo cliente'],['P','Cadastrar peça (dono)'],['/','Ir para a busca da tela'],['Alt + 1…8','Trocar de tela'],['Esc','Fechar janela / busca'],['?','Mostrar esta ajuda']];
  ui.open({center:true,title:'Atalhos do teclado',render:function(){return '<div class="list">'+rows.map(function(r){return '<div class="hrow static"><b><kbd>'+esc(r[0])+'</kbd></b><span>'+esc(r[1])+'</span></div>'}).join('')+'</div>'}});
};
function typing(t){return !!t&&(/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName||'')||t.isContentEditable===true)}
document.addEventListener('keydown',function(e){
  var k=String(e.key||'');
  if(pal.open){
    if(k==='Escape'){e.preventDefault();pal.hide()}
    else if(k==='ArrowDown'){e.preventDefault();pal.move(1)}
    else if(k==='ArrowUp'){e.preventDefault();pal.move(-1)}
    else if(k==='Enter'){e.preventDefault();pal.pick()}
    return;
  }
  if((e.ctrlKey||e.metaKey)&&k.toLowerCase()==='k'){e.preventDefault();pal.show();return}
  if(e.altKey&&/^[1-8]$/.test(k)){var pgs=ui.pages(),p=pgs[+k-1];if(p){e.preventDefault();ui.closeAll();ui.go(p)}return}
  if(k==='Escape'){var t=ui.top();if(t&&!t.onSubmit)ui.close();return}
  if(typing(e.target)||e.ctrlKey||e.metaKey||e.altKey||ui.top())return;
  var lk=k.toLowerCase();
  if(lk==='n'){e.preventDefault();A['order.new']({status:'Orçamento'})}
  else if(lk==='c'){e.preventDefault();A['customer.new']({})}
  else if(lk==='p'&&ui.isOwner()){e.preventDefault();A['part.new']({})}
  else if(k==='/'){var s=document.querySelector('[data-search]');if(s&&s.focus){e.preventDefault();s.focus()}}
  else if(k==='?'){e.preventDefault();A['pc.help']({})}
});
})();
/* cliques dentro da caixa de busca não fecham */
(function(){var RM=window.RM;RM.act['pal.stop']=function(){}})();

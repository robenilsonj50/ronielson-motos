/* pc-tools.js — ferramentas da versão para computador: exportação CSV (Excel), busca global, gráficos e etiquetas com código de barras */
(function(){
'use strict';
var RM=window.RM,d=RM.d,esc=RM.esc,money=RM.money;

/* ======================= CSV para Excel (pt-BR: separador ; e vírgula decimal) ======================= */
var CSV=RM.csv={};
CSV.cell=function(v){v=String(v==null?'':v);return /[;"\n\r]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
CSV.num=function(n){return RM.r2(RM.num(n)).toFixed(2).replace('.',',')};
CSV.build=function(headers,rows){return '\uFEFF'+[headers].concat(rows).map(function(r){return r.map(CSV.cell).join(';')}).join('\r\n')+'\r\n'};
CSV.date=function(s){return s?RM.dateBR(s):''};
CSV.datasets=function(data){
  var mech=function(o){var m=o.mechanicId&&data.mechanics.find(function(x){return x.id===o.mechanicId});return m?m.name:''};
  var custOf=function(o){return RM.print.customerOf(o)};
  return {
    clientes:{name:'clientes',headers:['Nome','Telefone','Moto','Placa','Km','Observações','Cadastro'],
      rows:data.customers.map(function(c){return [c.name,c.phone,c.bike,c.plate,c.km,c.notes,CSV.date(c.created)]})},
    estoque:{name:'estoque',headers:['Peça','Código','Quantidade','Mínimo','Custo','Preço de venda','Margem %'],
      rows:data.parts.map(function(p){return [p.name,p.sku,p.qty,p.min,CSV.num(p.cost),CSV.num(p.price),CSV.num(d.margin(p))]})},
    ordens:{name:'ordens-de-servico',headers:['Número','Data','Situação','Cliente','Moto','Placa','Km','Serviço','Mecânico','Mão de obra','Peças','Desconto','Total','Pago','Saldo','Entregue em','Garantia até'],
      rows:data.orders.map(function(o){var c=o.plate?null:custOf(o);return [o.number,CSV.date(o.created),o.status,o.customer,String(o.bike||'').replace(/ — .*$/,''),o.plate||(c&&c.plate)||'',o.km,o.problem,mech(o),CSV.num(o.labor),CSV.num(d.itemsTotal(o)),CSV.num(o.discount),CSV.num(d.orderTotal(o)),CSV.num(d.paid(o)),CSV.num(d.balance(o)),CSV.date(o.deliveredAt),CSV.date(d.warrantyUntil(o))]})},
    itens:{name:'pecas-das-ordens',headers:['Número da OS','Data','Peça','Quantidade','Valor unitário','Total','Custo unitário'],
      rows:data.orders.reduce(function(a,o){(o.items||[]).forEach(function(i){a.push([o.number,CSV.date(o.created),i.name,i.qty,CSV.num(i.price),CSV.num(RM.num(i.qty)*RM.num(i.price)),CSV.num(i.cost)])});return a},[])},
    caixa:{name:'caixa',headers:['Data','Tipo','Categoria','Descrição','Forma de pagamento','Valor'],
      rows:data.cash.slice().sort(function(a,b){return String(a.date).localeCompare(String(b.date))}).map(function(x){return [CSV.date(x.date),x.type,x.category,x.desc,x.method,CSV.num(x.amount)]})},
    pagar:{name:'contas-a-pagar',headers:['Vencimento','Descrição','Fornecedor','Categoria','Valor','Situação','Pago em'],
      rows:data.payables.map(function(x){return [CSV.date(x.due),x.desc,x.supplier,x.category,CSV.num(x.amount),x.paid?'Paga':'Pendente',CSV.date(x.paidDate)]})},
    receber:{name:'a-receber',headers:['Cliente','Telefone','Origem','Saldo'],
      rows:d.debtors(data).reduce(function(a,x){x.items.forEach(function(i){a.push([x.name,x.phone,i.label,CSV.num(i.balance)])});return a},[])}
  };
};
CSV.exportOne=function(key){var ds=CSV.datasets(RM.data)[key];if(!ds)return false;RM.download('ronielson-motos-'+ds.name+'-'+RM.today()+'.csv',CSV.build(ds.headers,ds.rows),'text/csv;charset=utf-8');return true};

/* ======================= Código de barras Code 128 (etiquetas) ======================= */
var BC=RM.barcode={};
BC.PATTERNS=["212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213", "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132", "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211", "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313", "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331", "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111", "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214", "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111", "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141", "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141", "114131", "311141", "411131", "211412", "211214", "211232", "2331112"];
BC.clean=function(t){return String(t==null?'':t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^\x20-\x7e]/g,'').slice(0,40)};
BC.values=function(text){
  var t=BC.clean(text),v=[],i;if(!t)return null;
  if(/^\d+$/.test(t)&&t.length%2===0){v.push(105);for(i=0;i<t.length;i+=2)v.push(parseInt(t.substr(i,2),10))}
  else{v.push(104);for(i=0;i<t.length;i++)v.push(t.charCodeAt(i)-32)}
  var sum=v[0];for(i=1;i<v.length;i++)sum+=v[i]*i;
  v.push(sum%103);v.push(106);return v;
};
BC.modules=function(text){
  var v=BC.values(text);if(!v)return '';var out='';
  v.forEach(function(val){var p=BC.PATTERNS[val],bar=true;for(var i=0;i<p.length;i++){out+=(bar?'1':'0').repeat(+p[i]);bar=!bar}});
  return out;
};
BC.svg=function(text,o){
  o=o||{};var m=BC.modules(text);if(!m)return '';var q=10,h=o.height||50,W=m.length+q*2,rects='',i=0;
  while(i<m.length){if(m[i]==='1'){var j=i;while(j<m.length&&m[j]==='1')j++;rects+='<rect x="'+(q+i)+'" y="0" width="'+(j-i)+'" height="'+h+'"/>';i=j}else i++}
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+W+' '+h+'" preserveAspectRatio="none" style="width:'+(o.width||'100%')+';height:'+(o.cssHeight||'12mm')+';display:block" shape-rendering="crispEdges"><g fill="#000">'+rects+'</g></svg>';
};
BC.nextInternalCode=function(data){
  var max=0;data.parts.forEach(function(p){var m=/^RM(\d{6})$/.exec(String(p.sku||''));if(m)max=Math.max(max,parseInt(m[1],10))});
  return 'RM'+String(max+1).padStart(6,'0');
};
/* folha A4 de etiquetas: 3 colunas x 7 linhas. items: [{name,price,code,copies}] */
BC.sheetHtml=function(items,company){
  var labels=[];items.forEach(function(it){for(var i=0;i<Math.max(1,Math.min(200,parseInt(it.copies,10)||1));i++)labels.push(it)});
  var cells=labels.map(function(it){return '<div class="lb"><div class="co">'+esc(company||'')+'</div><div class="nm">'+esc(it.name)+'</div><div class="pr">'+money(it.price)+'</div><div class="bc">'+BC.svg(it.code,{cssHeight:'11mm'})+'</div><div class="cd">'+esc(it.code)+'</div></div>'}).join('');
  var css='@page{size:A4;margin:6mm}*{box-sizing:border-box}body{margin:0;font-family:Arial,Helvetica,sans-serif;color:#000}.sheet{display:grid;grid-template-columns:repeat(3,1fr);grid-auto-rows:39.5mm;gap:2mm}.lb{border:.2mm dashed #bbb;padding:2mm 3mm;display:flex;flex-direction:column;justify-content:space-between;overflow:hidden;page-break-inside:avoid}.co{font-size:6.5pt;color:#555;text-transform:uppercase;letter-spacing:.3px}.nm{font-size:9pt;font-weight:700;line-height:1.15;max-height:2.4em;overflow:hidden}.pr{font-size:13pt;font-weight:800}.cd{font-size:7pt;text-align:center;letter-spacing:1px}';
  return '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Etiquetas</title><style>'+css+'</style></head><body><div class="sheet">'+cells+'</div></body></html>';
};

/* ======================= Busca global (Ctrl+K) ======================= */
var S=RM.searchTools={};
S.score=function(text,q){text=String(text||'').toLowerCase();if(!q)return 0;var i=text.indexOf(q);if(i<0)return 0;return i===0?100:(text.charAt(i-1)===' '?70:40)};
S.actions=function(owner){
  var a=[{label:'Novo orçamento',sub:'Criar orçamento / ordem de serviço',act:'order.new',ds:{status:'Orçamento'},kw:'nova os ordem orçamento'},
         {label:'Nova OS direta',sub:'Abrir serviço já aprovado',act:'order.new',ds:{status:'Aprovada'},kw:'ordem servico'},
         {label:'Novo cliente',sub:'Cadastrar cliente e moto',act:'customer.new',ds:{},kw:'cadastrar moto'}];
  if(owner)a.push({label:'Cadastrar peça',sub:'Adicionar ao estoque',act:'part.new',ds:{},kw:'estoque produto'},{label:'Lançar no caixa',sub:'Entrada ou saída',act:'cash.new',ds:{},kw:'financeiro dinheiro'},
    {label:'Fechar o caixa',sub:'Conferência do dia',act:'pc.fin',ds:{tab:'close'},kw:'fechamento'},{label:'Lucro do mês',sub:'Relatório financeiro',act:'pc.fin',ds:{tab:'profit'},kw:'resultado relatorio'},
    {label:'Imprimir etiquetas',sub:'Código de barras das peças',act:'pc.labels',ds:{},kw:'barras codigo'},{label:'Exportar planilhas (Excel)',sub:'CSV de clientes, estoque, caixa...',act:'pc.export',ds:{},kw:'csv excel planilha'},
    {label:'Fazer backup',sub:'Salvar arquivo de segurança',act:'settings.backup',ds:{},kw:'backup copia'});
  d.OWNER_PAGES.forEach(function(p){if(!owner&&d.STAFF_PAGES.indexOf(p)<0)return;var pg=RM.pages[p];if(pg)a.push({label:'Ir para: '+pg.label,sub:pg.title,act:'go',ds:{page:p},kw:'abrir menu'})});
  return a;
};
S.run=function(q,owner,data){
  data=data||RM.data;q=String(q||'').toLowerCase().trim();var np=d.normPlate(q),out=[];
  if(!q){return S.actions(owner).slice(0,8).map(function(x){return {type:'Ação',title:x.label,sub:x.sub,act:x.act,ds:x.ds}})}
  var sc=[];
  data.customers.forEach(function(c){var s=Math.max(S.score(c.name,q),S.score(c.phone,q),S.score(c.bike,q),S.score(c.plate,q),np&&d.normPlate(c.plate).indexOf(np)===0?90:(np&&d.normPlate(c.plate).indexOf(np)>-1?50:0));if(s)sc.push({s:s+5,type:'Cliente',title:c.name,sub:(c.bike||'')+(c.plate?' · '+c.plate:'')+(c.phone?' · '+c.phone:''),act:'customer.view',ds:{id:c.id}})});
  data.orders.forEach(function(o){var pl=o.plate||(RM.print.customerOf(o)||{}).plate||'';var s=Math.max(S.score(o.number,q),S.score(o.customer,q),S.score(o.problem,q),np&&d.normPlate(pl).indexOf(np)>-1?60:0,('#'+o.number).toLowerCase()===q?100:0);if(s)sc.push({s:s,type:'Ordem',title:'#'+o.number+' · '+(o.customer||'Cliente'),sub:o.status+' · '+money(d.orderTotal(o))+(o.problem?' · '+o.problem:''),act:'order.view',ds:{id:o.id}})});
  data.parts.forEach(function(p){var s=Math.max(S.score(p.name,q),S.score(p.sku,q)*1.2);if(s)sc.push({s:s,type:'Peça',title:p.name,sub:'Estoque '+RM.num(p.qty)+' · '+money(p.price)+(p.sku?' · '+p.sku:''),act:'pc.part',ds:{name:p.name}})});
  S.actions(owner).forEach(function(x){var s=Math.max(S.score(x.label,q),S.score(x.kw,q)*0.6);if(s)sc.push({s:s-10,type:'Ação',title:x.label,sub:x.sub,act:x.act,ds:x.ds})});
  sc.sort(function(a,b){return b.s-a.s});
  var per={},cap={Cliente:5,Ordem:5,'Peça':4,'Ação':4};
  sc.forEach(function(x){per[x.type]=(per[x.type]||0)+1;if(per[x.type]<=cap[x.type]&&out.length<14)out.push(x)});
  return out;
};

/* ======================= Gráficos (SVG, sem bibliotecas) ======================= */
var CH=RM.charts={};
CH.MONTHS=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
CH.compact=function(n){var a=Math.abs(n),s=n<0?'-':'';if(a>=1e6)return s+'R$ '+(a/1e6).toFixed(1).replace('.',',')+' mi';if(a>=1e3)return s+'R$ '+(a/1e3).toFixed(1).replace('.',',')+' mil';return s+'R$ '+Math.round(a)};
CH.monthly=function(data,today,n){
  n=n||6;var out=[],ms=RM.monthStart(today);
  for(var i=n-1;i>=0;i--){var st=RM.addMonths(ms,-i),en=RM.monthEnd(st),p=d.profit(data,st,en);out.push({label:CH.MONTHS[+st.slice(5,7)-1],revenue:p.revenue,net:p.net,count:p.count})}
  return out;
};
CH.barsSvg=function(series,o){
  o=o||{};var W=o.w||560,H=o.h||230,pl=12,pr=12,pt=26,pb=28,iw=W-pl-pr,ih=H-pt-pb;
  var max=Math.max(1,Math.max.apply(null,series.map(function(s){return Math.max(s.revenue,s.net)}))),min=Math.min(0,Math.min.apply(null,series.map(function(s){return s.net})));
  var y=function(v){return pt+ih*(1-(v-min)/(max-min))},y0=y(0),gw=iw/series.length,bw=Math.min(34,gw*0.32),svg='';
  svg+='<line x1="'+pl+'" x2="'+(W-pr)+'" y1="'+y0+'" y2="'+y0+'" stroke="#334155" stroke-width="1"/>';
  series.forEach(function(s,i){
    var cx=pl+gw*i+gw/2,yr=y(s.revenue),yn=y(s.net);
    svg+='<rect x="'+(cx-bw-2)+'" y="'+Math.min(yr,y0)+'" width="'+bw+'" height="'+Math.max(1,Math.abs(y0-yr))+'" rx="3" fill="#60a5fa"><title>Faturamento '+esc(money(s.revenue))+'</title></rect>';
    svg+='<rect x="'+(cx+2)+'" y="'+Math.min(yn,y0)+'" width="'+bw+'" height="'+Math.max(1,Math.abs(y0-yn))+'" rx="3" fill="'+(s.net<0?'#fb7185':'#34d399')+'"><title>Lucro líquido '+esc(money(s.net))+'</title></rect>';
    svg+='<text x="'+cx+'" y="'+(H-9)+'" text-anchor="middle" fill="#94a3b8" font-size="12">'+s.label+'</text>';
    if(s.revenue>0)svg+='<text x="'+(cx-bw/2-2)+'" y="'+(Math.min(yr,y0)-5)+'" text-anchor="middle" fill="#cbd5e1" font-size="10">'+esc(CH.compact(s.revenue).replace('R$ ',''))+'</text>';
  });
  return '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Faturamento e lucro por mês" style="width:100%;height:auto">'+svg+'</svg>';
};
CH.STATUS_COLORS={'Orçamento':'#a78bfa','Aprovada':'#60a5fa','Aberta':'#60a5fa','Em andamento':'#38bdf8','Aguardando peça':'#fcd34d','Concluída':'#34d399','Entregue':'#10b981','Cancelada':'#64748b'};
CH.donut=function(items){
  var total=items.reduce(function(a,x){return a+x.value},0),R=42,C=2*Math.PI*R,off=0,seg='';
  if(!total)return {svg:'<svg viewBox="0 0 120 120" style="width:150px;height:150px"><circle cx="60" cy="60" r="'+R+'" fill="none" stroke="#243247" stroke-width="16"/><text x="60" y="65" text-anchor="middle" fill="#94a3b8" font-size="12">sem dados</text></svg>',legend:''};
  items.forEach(function(x){if(!x.value)return;var len=C*x.value/total;seg+='<circle cx="60" cy="60" r="'+R+'" fill="none" stroke="'+x.color+'" stroke-width="16" stroke-dasharray="'+len.toFixed(2)+' '+(C-len).toFixed(2)+'" stroke-dashoffset="'+(-off).toFixed(2)+'" transform="rotate(-90 60 60)"><title>'+esc(x.label)+': '+x.value+'</title></circle>';off+=len});
  return {svg:'<svg viewBox="0 0 120 120" style="width:150px;height:150px">'+seg+'<text x="60" y="58" text-anchor="middle" fill="#f1f5f9" font-size="22" font-weight="700">'+total+'</text><text x="60" y="74" text-anchor="middle" fill="#94a3b8" font-size="10">ordens</text></svg>',
    legend:items.filter(function(x){return x.value}).map(function(x){return '<div class="lg"><i style="background:'+x.color+'"></i>'+esc(x.label)+' <b>'+x.value+'</b></div>'}).join('')};
};
CH.statusItems=function(data){
  var order=['Orçamento','Aprovada','Em andamento','Aguardando peça','Concluída','Entregue'],cnt={};
  data.orders.forEach(function(o){var s=o.status==='Aberta'?'Aprovada':o.status;if(s==='Cancelada')return;if(d.isDone(s)&&RM.daysBetween(d.orderDate(o)||RM.today(),RM.today())>60)return;cnt[s]=(cnt[s]||0)+1});
  return order.map(function(s){return {label:s,value:cnt[s]||0,color:CH.STATUS_COLORS[s]}});
};
CH.topParts=function(data,today){var p=d.profit(data,RM.addDays(today,-29),today);return p.top};
})();

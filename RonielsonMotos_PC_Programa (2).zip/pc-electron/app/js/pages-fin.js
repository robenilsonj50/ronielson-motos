/* pages-fin.js — Estoque, Financeiro (caixa, a receber, a pagar, fechamento, lucro) e Mecânicos/comissões */
(function(){
'use strict';
var RM=window.RM,ui=RM.ui,d=RM.d,esc=RM.esc,money=RM.money,P=RM.print,A=RM.act,pages=RM.pages;
function DATA(){return RM.data}
function kv(k,v){return '<div class="kv"><span>'+esc(k)+'</span><b>'+v+'</b></div>'}

/* ---------- períodos ---------- */
var RANGES=[['today','Hoje'],['7d','7 dias'],['month','Este mês'],['lastmonth','Mês passado'],['year','Ano'],['all','Tudo']];
function rangeFor(key){
  var t=RM.today();
  if(key==='today')return [t,t];
  if(key==='7d')return [RM.addDays(t,-6),t];
  if(key==='lastmonth'){var p=RM.addMonths(RM.monthStart(t),-1);return [p,RM.monthEnd(p)]}
  if(key==='year')return [t.slice(0,4)+'-01-01',t.slice(0,4)+'-12-31'];
  if(key==='all')return ['0000-01-01','9999-12-31'];
  return [RM.monthStart(t),RM.monthEnd(t)];
}
function rangeChips(stateKey,def){
  var cur=ui.q[stateKey]||def;
  return '<div class="chips">'+RANGES.map(function(r){return '<button type="button" class="chip'+(cur===r[0]?' active':'')+'" data-act="fin.range" data-key="'+stateKey+'" data-v="'+r[0]+'">'+r[1]+'</button>'}).join('')+'</div>';
}
A['fin.range']=function(ds){ui.q[ds.key]=ds.v;ui.render(true)};

/* ======================= ESTOQUE ======================= */
function partCard(p){
  var owner=ui.isOwner(),low=RM.num(p.qty)<=RM.num(p.min);
  return '<div class="item static"><div class="item-main"><b>'+esc(p.name)+'</b><span class="muted small">'+(p.sku?'Código: '+esc(p.sku)+' · ':'')+'Mínimo: '+RM.num(p.min)+'</span>'
   +'<span class="muted small">Venda '+money(p.price)+(owner?' · Custo '+money(p.cost)+' · Margem '+d.margin(p)+'%':'')+'</span></div>'
   +'<div class="item-side"><span class="bigqty">'+RM.num(p.qty)+'</span>'+(low?ui.pill('Baixo','yellow'):'')
   +'<div class="btnrow tight"><button type="button" class="btn sm" data-act="part.adj" data-id="'+esc(p.id)+'" data-delta="-1" aria-label="Menos um">−1</button><button type="button" class="btn sm" data-act="part.adj" data-id="'+esc(p.id)+'" data-delta="1" aria-label="Mais um">+1</button>'
   +(owner?'<button type="button" class="btn sm" data-act="part.edit" data-id="'+esc(p.id)+'">✏️</button><button type="button" class="btn danger sm" data-act="part.del" data-id="'+esc(p.id)+'" aria-label="Excluir">🗑</button>':'')+'</div></div></div>';
}
pages.inventory={title:'Estoque de peças',icon:'▤',label:'Estoque',
filtered:function(){
  var q=String(ui.q.inventory||'').toLowerCase().trim(),low=ui.q.invFilter==='low';
  return DATA().parts.filter(function(p){return (!low||RM.num(p.qty)<=RM.num(p.min))&&(!q||(p.name+' '+(p.sku||'')).toLowerCase().indexOf(q)>-1)}).sort(function(a,b){return String(a.name).localeCompare(String(b.name))});
},
list:function(){
  var list=pages.inventory.filtered();
  return list.length?'<div class="list">'+list.map(partCard).join('')+'</div>':ui.empty(DATA().parts.length?'Nenhuma peça encontrada':'Estoque vazio',DATA().parts.length?'Ajuste a busca ou o filtro.':'Cadastre suas primeiras peças.');
},
render:function(){
  var data=DATA(),owner=ui.isOwner(),lowN=d.lowParts(data).length,f=ui.q.invFilter||'all';
  return '<div class="toolbar"><h2>Estoque de peças</h2>'+(owner?'<button type="button" class="btn primary" data-act="part.new">＋ Cadastrar peça</button>':'')+'</div>'
   +'<div class="stats mini3">'+ui.stat('Itens',String(data.parts.length),'','')+ui.stat('Em falta / mínimo',String(lowN),'','warning')+(owner?ui.stat('Valor em estoque',money(d.stockValue(data)),'A preço de custo',''):'')+'</div>'
   +'<div class="card"><div class="chips"><button type="button" class="chip'+(f==='all'?' active':'')+'" data-act="inv.filter" data-v="all">Todas</button><button type="button" class="chip'+(f==='low'?' active':'')+'" data-act="inv.filter" data-v="low">Em falta ('+lowN+')</button>'
   +(lowN?'<button type="button" class="chip" data-act="inv.restock">📋 Lista de reposição</button>':'')+'</div><div class="toolbar">'+ui.searchBox('inventory','Buscar peça ou código...')+'</div><div id="list-inventory">'+pages.inventory.list()+'</div></div>';
}};
A['inv.filter']=function(ds){ui.q.invFilter=ds.v;ui.render(true)};
A['part.adj']=function(ds){
  var p=DATA().parts.find(function(x){return x.id===ds.id});if(!p)return;var delta=+ds.delta;
  if(RM.num(p.qty)+delta<0){ui.toast('O estoque não pode ficar negativo.','err');return}
  p.qty=RM.num(p.qty)+delta;RM.persist();
};
function openPartForm(p){
  ui.open({title:p?'Editar peça':'Cadastrar peça no estoque',submitLabel:'Salvar',
    render:function(){var v=p||{};
      return '<div class="formgrid">'+ui.field({name:'name',label:'Nome da peça',value:v.name,full:true})
       +'<div class="field full"><label>Código de barras / referência</label><div class="scanrow"><input name="sku" type="text" value="'+esc(v.sku||'')+'" placeholder="Escaneie ou digite o código" autocomplete="off"><button type="button" class="btn" data-act="part.scan">📷 Escanear</button></div></div>'
       +ui.field({name:'qty',label:'Quantidade',type:'number',value:v.qty!==undefined?v.qty:'',step:'1',min:0})+ui.field({name:'min',label:'Estoque mínimo',type:'number',value:v.min!==undefined?v.min:'',step:'1',min:0})
       +ui.field({name:'cost',label:'Custo unitário (R$)',type:'number',value:v.cost!==undefined?v.cost:'',step:'0.01',min:0})+ui.field({name:'price',label:'Preço de venda (R$)',type:'number',value:v.price!==undefined?v.price:'',step:'0.01',min:0})+'</div>';
    },
    onSubmit:function(v){
      var data=DATA(),sku=String(v.sku||'').trim();
      if(sku&&data.parts.some(function(x){return x.id!==(p&&p.id)&&String(x.sku)===sku})){ui.toast('Já existe uma peça com este código.','err');return false}
      var rec={name:String(v.name).trim(),sku:sku,qty:RM.num(v.qty),min:RM.num(v.min),cost:RM.num(v.cost),price:RM.num(v.price)};
      if(rec.price>0&&rec.price<rec.cost)ui.toast('Atenção: preço de venda menor que o custo.','err');
      if(p)Object.assign(p,rec);else data.parts.unshift(Object.assign({id:RM.uid()},rec));
      RM.persist();ui.toast('Peça salva.');
    }});
}
A['part.new']=function(){openPartForm(null)};
A['part.edit']=function(ds){var p=DATA().parts.find(function(x){return x.id===ds.id});if(p)openPartForm(p)};
A['part.scan']=function(){
  var el=document.querySelector('#modalbox [name="sku"]');
  if(!RM.br('AndroidScanner')){if(el&&el.focus){el.focus();ui.toast('Passe o código no leitor USB (ou digite) neste campo.')}return}
  RM.scan(function(code){if(el)el.value=code});
};
A['part.del']=function(ds){var p=DATA().parts.find(function(x){return x.id===ds.id});if(!p)return;ui.confirm('Excluir "'+p.name+'" do estoque?\nOrdens já lançadas continuam com o nome e o valor da peça.',function(){DATA().parts=DATA().parts.filter(function(x){return x.id!==p.id});RM.persist()},{danger:true,okLabel:'Excluir'})};
A['inv.restock']=function(){
  var list=d.restock(DATA());
  ui.open({title:'Lista de reposição',render:function(){return list.length?'<div class="list">'+list.map(function(x){return '<div class="hrow"><div><b>'+esc(x.part.name)+'</b><div class="muted small">Estoque '+RM.num(x.part.qty)+' / mínimo '+RM.num(x.part.min)+'</div></div><div class="item-side"><b>comprar ~'+x.suggest+'</b></div></div>'}).join('')+'</div>':ui.empty('Nada para repor','')},
    actions:function(){return '<button type="button" class="btn" data-act="ui.close">Fechar</button><button type="button" class="btn" data-act="inv.restockCopy">Copiar</button><button type="button" class="btn primary" data-act="inv.restockSend">💬 Enviar</button>'}});
};
A['inv.restockCopy']=function(){RM.copy(P.restockText(d.restock(DATA())));ui.toast('Lista copiada.')};
A['inv.restockSend']=function(){RM.open(RM.waLink('',P.restockText(d.restock(DATA()))))};

/* ======================= FINANCEIRO ======================= */
pages.finance={title:'Financeiro',icon:'💰',label:'Financeiro',
render:function(){
  var tabs=ui.tabs('finance',[['cash','Caixa'],['recv','A receber'],['pay','A pagar'],['close','Fechamento'],['profit','Lucro']]);
  var t=ui.tab.finance,body={cash:cashTab,recv:recvTab,pay:payTab,close:closeTab,profit:profitTab}[t]||cashTab;
  return '<div class="toolbar"><h2>Financeiro</h2></div>'+tabs+body();
}};

/* ---- Caixa ---- */
function cashRow(x){
  var linked=!!x.ref,isIn=x.type==='Entrada';
  return '<div class="item static"><div class="item-main"><b>'+esc(x.desc)+'</b><span class="muted small">'+RM.dateBR(x.date)+' · '+esc(x.method||'')+' · '+esc(x.category||'')+(linked?' · vinculado':'')+'</span></div>'
   +'<div class="item-side"><b class="'+(isIn?'pos':'neg')+'">'+(isIn?'+':'−')+' '+money(x.amount)+'</b><button type="button" class="btn danger sm" data-act="cash.del" data-id="'+esc(x.id)+'" aria-label="Excluir">🗑</button></div></div>';
}
function cashTab(){
  var data=DATA(),key=ui.q.cashRange||'month',r=rangeFor(key),list=data.cash.filter(function(x){return x.date>=r[0]&&x.date<=r[1]}).sort(function(a,b){return String(b.date).localeCompare(String(a.date))});
  var t=d.cashTotals(data,r[0],r[1]);
  return '<div class="toolbar"><span></span><button type="button" class="btn primary" data-act="cash.new">＋ Novo lançamento</button></div>'+rangeChips('cashRange','month')
   +'<div class="stats mini3">'+ui.stat('Entradas',money(t.in),'','positive')+ui.stat('Saídas',money(t.out),'','')+ui.stat('Saldo',money(t.balance),'',t.balance<0?'neg':'')+'</div>'
   +'<div class="card">'+(list.length?'<div class="list">'+list.map(cashRow).join('')+'</div>':ui.empty('Nenhum lançamento no período','Registre entradas e saídas para acompanhar o caixa.'))+'</div>';
}
var cashDraft=null;
function openCashForm(){
  cashDraft={desc:'',type:'Entrada',category:'Serviço',amount:'',method:'Pix',date:RM.today()};
  ui.open({title:'Novo lançamento de caixa',submitLabel:'Lançar',
    render:function(){
      var cats=cashDraft.type==='Entrada'?d.CASH_IN:d.CASH_OUT,b=function(n,l,t,x){return Object.assign({name:n,label:l,type:t||'text',value:cashDraft[n],required:false,attrs:'data-bind="'+n+'"'},x||{})};
      return ui.fields([b('desc','Descrição'),b('type','Tipo','select',{options:[['Entrada','Entrada'],['Saída','Saída']]}),b('category','Categoria','select',{options:cats.map(function(c){return [c,c]})}),b('amount','Valor (R$)','number',{step:'0.01',min:0.01}),b('method','Forma de pagamento','select',{options:ui.METHODS}),b('date','Data','date')])
       +'<p class="muted small">Saídas “Compra de estoque” e “Retirada do dono” não contam como despesa no cálculo de lucro.</p>';
    },
    onBind:function(k,v){
      if(k==='type'){if(cashDraft.type===v)return;cashDraft.type=v;cashDraft.category=v==='Entrada'?'Serviço':'Despesa';ui.refresh();return}
      cashDraft[k]=v;
    },
    onSubmit:function(){
      if(!String(cashDraft.desc).trim()){ui.toast('Informe a descrição.','err');return false}
      if(RM.num(cashDraft.amount)<=0){ui.toast('Informe um valor maior que zero.','err');return false}
      DATA().cash.unshift({id:RM.uid(),desc:String(cashDraft.desc).trim(),type:cashDraft.type,category:cashDraft.category,amount:RM.r2(RM.num(cashDraft.amount)),method:cashDraft.method,date:cashDraft.date||RM.today()});
      RM.persist();ui.toast('Lançamento salvo.');
    }});
}
A['cash.new']=function(){openCashForm()};
A['cash.del']=function(ds){
  var x=DATA().cash.find(function(y){return y.id===ds.id});if(!x)return;
  if(x.ref){ui.alert('Este lançamento veio de '+(x.ref.type==='os'?'um pagamento de OS':x.ref.type==='pay'?'uma conta paga':x.ref.type==='rec'?'um recebimento':'um pagamento de comissão')+'. Para desfazer, use a tela de origem (pagamento da OS, conta a pagar etc.).');return}
  ui.confirm('Excluir o lançamento "'+x.desc+'"?',function(){DATA().cash=DATA().cash.filter(function(y){return y.id!==x.id});RM.persist()},{danger:true,okLabel:'Excluir'});
};

/* ---- A receber / fiado ---- */
function recvTab(){
  var data=DATA(),list=d.debtors(data);
  var cards=list.map(function(x){
    return '<div class="card"><div class="cardhead"><h2>'+esc(x.name)+'</h2><b class="owe">'+money(x.total)+'</b></div>'
     +x.items.map(function(i){return '<div class="payrow"><span>'+esc(i.label)+'<br><small class="muted">'+RM.dateBR(i.date)+'</small></span><b>'+money(i.balance)+'</b><button type="button" class="btn sm" data-act="'+(i.kind==='os'?'order.pay':'rec.pay')+'" data-id="'+esc(i.id)+'">Receber</button></div>'}).join('')
     +'<div class="btnrow"><button type="button" class="btn" data-act="rec.charge" data-key="'+esc(x.key)+'">💬 Cobrar no WhatsApp</button></div></div>';
  }).join('');
  return '<div class="toolbar"><span class="muted">Total a receber: <b class="owe">'+money(d.totalReceivable(data))+'</b></span><button type="button" class="btn primary" data-act="rec.new">＋ Valor a receber</button></div>'
   +(cards||'<div class="card">'+ui.empty('Nada a receber','Ordens entregues com saldo e fiados lançados aparecem aqui.')+'</div>');
}
A['rec.new']=function(){
  var data=DATA();
  ui.open({title:'Novo valor a receber (fiado)',submitLabel:'Salvar',
    render:function(){return ui.fields([{name:'customerId',label:'Cliente cadastrado (opcional)',type:'select',required:false,full:true,options:[['','— Digitar nome abaixo —']].concat(data.customers.map(function(c){return [c.id,c.name+(c.bike?' — '+c.bike:'')]}))},{name:'customer',label:'Nome do cliente',required:false},{name:'desc',label:'Descrição',value:'Fiado'},{name:'amount',label:'Valor (R$)',type:'number',step:'0.01',min:0.01},{name:'due',label:'Vencimento',type:'date',value:RM.addDays(RM.today(),7),required:false}])},
    onSubmit:function(v){
      var c=v.customerId?data.customers.find(function(x){return x.id===v.customerId}):null,name=c?c.name:String(v.customer||'').trim();
      if(!name){ui.toast('Informe o cliente.','err');return false}
      if(RM.num(v.amount)<=0){ui.toast('Informe o valor.','err');return false}
      d.addReceivable(data,{desc:v.desc,customerId:c?c.id:'',customer:name,amount:v.amount,due:v.due});RM.persist();ui.toast('Salvo.');
    }});
};
A['rec.pay']=function(ds){
  var r=DATA().receivables.find(function(x){return x.id===ds.id});if(!r)return;var bal=d.recvBalance(r);
  ui.open({title:'Receber',submitLabel:'Registrar',
    render:function(){return '<p class="muted">'+esc(r.desc)+' — saldo <b>'+money(bal)+'</b></p>'+ui.fields([{name:'amount',label:'Valor (R$)',type:'number',value:bal,step:'0.01',min:0.01,full:true},{name:'method',label:'Forma de pagamento',type:'select',options:ui.METHODS},{name:'date',label:'Data',type:'date',value:RM.today()}])},
    onSubmit:function(v){var x=d.receiveManual(DATA(),r.id,v);if(!x.ok){ui.toast(x.error,'err');return false}RM.persist();ui.toast('Recebimento registrado.')}});
};
A['rec.charge']=function(ds){var x=d.debtors(DATA()).find(function(y){return y.key===ds.key});if(x)RM.open(RM.waLink(x.phone,P.chargeText(x)))};

/* ---- A pagar ---- */
function payTab(){
  var data=DATA(),today=RM.today(),pend=d.payablesPending(data).sort(function(a,b){return a.due.localeCompare(b.due)}),paid=data.payables.filter(function(x){return x.paid}).sort(function(a,b){return String(b.paidDate).localeCompare(String(a.paidDate))}).slice(0,10);
  var tot=RM.r2(pend.reduce(function(a,x){return a+RM.num(x.amount)},0));
  function row(x){var late=!x.paid&&x.due<today;return '<div class="item static"><div class="item-main"><b>'+esc(x.desc)+'</b><span class="muted small">'+(x.supplier?esc(x.supplier)+' · ':'')+(x.paid?'Paga em '+RM.dateBR(x.paidDate):'Vence '+RM.dateBR(x.due))+' · '+esc(x.category)+'</span></div><div class="item-side">'+(late?ui.pill('Vencida','red'):x.paid?ui.pill('Paga','green'):'')+'<b>'+money(x.amount)+'</b><div class="btnrow tight">'+(x.paid?'<button type="button" class="btn sm" data-act="pay.undo" data-id="'+esc(x.id)+'">Desfazer</button>':'<button type="button" class="btn primary sm" data-act="pay.pay" data-id="'+esc(x.id)+'">Pagar</button><button type="button" class="btn danger sm" data-act="pay.del" data-id="'+esc(x.id)+'" aria-label="Excluir">🗑</button>')+'</div></div></div>'}
  return '<div class="toolbar"><span class="muted">A pagar: <b>'+money(tot)+'</b></span><button type="button" class="btn primary" data-act="pay.new">＋ Nova conta</button></div>'
   +'<div class="card"><div class="cardhead"><h2>Pendentes</h2></div>'+(pend.length?'<div class="list">'+pend.map(row).join('')+'</div>':ui.empty('Nenhuma conta pendente',''))+'</div>'
   +(paid.length?'<div class="card"><div class="cardhead"><h2>Pagas recentemente</h2></div><div class="list">'+paid.map(row).join('')+'</div></div>':'');
}
A['pay.new']=function(){
  ui.open({title:'Nova conta a pagar',submitLabel:'Salvar',
    render:function(){return ui.fields([{name:'desc',label:'Descrição',full:true},{name:'supplier',label:'Fornecedor / para quem',required:false},{name:'amount',label:'Valor (R$)',type:'number',step:'0.01',min:0.01},{name:'due',label:'Vencimento',type:'date',value:RM.today()},{name:'category',label:'Categoria',type:'select',options:[['Despesa','Despesa (aluguel, luz, etc.)'],['Compra de estoque','Compra de estoque']]}])},
    onSubmit:function(v){if(RM.num(v.amount)<=0){ui.toast('Informe o valor.','err');return false}d.addPayable(DATA(),v);RM.persist();ui.toast('Conta salva.')}});
};
A['pay.pay']=function(ds){
  var x=DATA().payables.find(function(y){return y.id===ds.id});if(!x)return;
  ui.open({title:'Pagar conta',submitLabel:'Confirmar pagamento',
    render:function(){return '<p class="muted">'+esc(x.desc)+' — <b>'+money(x.amount)+'</b></p>'+ui.fields([{name:'method',label:'Forma de pagamento',type:'select',options:ui.METHODS},{name:'date',label:'Data do pagamento',type:'date',value:RM.today()}])},
    onSubmit:function(v){d.payPayable(DATA(),x.id,v);RM.persist();ui.toast('Pago e lançado no caixa.')}});
};
A['pay.undo']=function(ds){d.unpayPayable(DATA(),ds.id);RM.persist()};
A['pay.del']=function(ds){ui.confirm('Excluir esta conta?',function(){DATA().payables=DATA().payables.filter(function(x){return x.id!==ds.id});RM.persist()},{danger:true,okLabel:'Excluir'})};

/* ---- Fechamento de caixa ---- */
function closeTab(){
  var data=DATA(),date=ui.q.closeDate||RM.today(),t=d.dayTotals(data,date),cl=data.closings.find(function(c){return c.date===date});
  function rows(m){var k=Object.keys(m);return k.length?k.map(function(x){return kv(x,money(m[x]))}).join(''):'<div class="muted small">—</div>'}
  return '<div class="toolbar"><label class="inl">Dia: <input type="date" data-q="closeDate" value="'+esc(date)+'"></label><button type="button" class="btn primary" data-act="close.new" data-date="'+esc(date)+'">'+(cl?'Refazer fechamento':'Fechar o caixa')+'</button></div>'
   +'<div class="stats mini3">'+ui.stat('Entradas',money(t.in),'','positive')+ui.stat('Saídas',money(t.out),'','')+ui.stat('Saldo do dia',money(t.balance),'',t.balance<0?'neg':'')+'</div>'
   +'<div class="grid2"><div class="card"><div class="cardhead"><h2>Entradas</h2></div>'+rows(t.byIn)+'</div><div class="card"><div class="cardhead"><h2>Saídas</h2></div>'+rows(t.byOut)+'</div></div>'
   +(cl?'<div class="card"><div class="cardhead"><h2>Fechamento salvo</h2><span class="muted small">'+RM.dateBR(cl.date)+'</span></div>'+kv('Troco inicial',money(cl.opening))+kv('Esperado em caixa (dinheiro)',money(cl.expected))+kv('Contado',money(cl.counted))+'<div class="kv big"><span>Diferença</span><b class="'+(cl.diff<0?'neg':cl.diff>0?'pos':'')+'">'+money(cl.diff)+'</b></div>'+(cl.note?'<div class="note">'+esc(cl.note)+'</div>':'')+'<div class="btnrow"><button type="button" class="btn" data-act="close.print" data-id="'+esc(cl.id)+'">📄 PDF</button><button type="button" class="btn" data-act="close.send" data-id="'+esc(cl.id)+'">💬 Enviar resumo</button></div></div>':'')
   +(data.closings.length?'<div class="card"><div class="cardhead"><h2>Fechamentos anteriores</h2></div><div class="list">'+data.closings.slice(0,10).map(function(c){return '<div class="hrow" data-act="close.pick" data-date="'+esc(c.date)+'"><div><b>'+RM.dateBR(c.date)+'</b><div class="muted small">Entradas '+money(c.in)+' · Saídas '+money(c.out)+'</div></div><div class="item-side"><b class="'+(c.diff<0?'neg':c.diff>0?'pos':'')+'">'+(c.diff===0?'Confere':'Dif. '+money(c.diff))+'</b></div></div>'}).join('')+'</div></div>':'');
}
A['close.pick']=function(ds){ui.q.closeDate=ds.date;ui.render(true)};
A['close.new']=function(ds){
  var data=DATA(),date=ds.date,t=d.dayTotals(data,date),prev=data.closings.filter(function(c){return c.date<date})[0],cl=data.closings.find(function(c){return c.date===date});
  var f={opening:cl?cl.opening:(prev?prev.counted:0),counted:cl?cl.counted:'',note:cl?cl.note:''};
  function exp(){return RM.r2(RM.num(f.opening)+t.cashIn-t.cashOut)}
  function info(){var c=f.counted===''?null:RM.r2(RM.num(f.counted)-exp());return '<div class="totals" id="closeInfo">'+kv('Dinheiro recebido no dia',money(t.cashIn))+kv('Dinheiro pago no dia','− '+money(t.cashOut))+'<div class="kv big"><span>Esperado em caixa</span><b>'+money(exp())+'</b></div>'+(c===null?'':'<div class="kv"><span>Diferença</span><b class="'+(c<0?'neg':c>0?'pos':'')+'">'+money(c)+'</b></div>')+'</div>'}
  ui.open({title:'Fechar o caixa — '+RM.dateBR(date),submitLabel:'Salvar fechamento',
    render:function(){var b=function(n,l,t2,x){return Object.assign({name:n,label:l,type:t2||'text',value:f[n],required:false,attrs:'data-bind="'+n+'"'},x||{})};return '<p class="muted small">Considere só o dinheiro físico da gaveta. Pix e cartão não entram na conferência.</p>'+ui.fields([b('opening','Troco inicial na gaveta (R$)','number',{step:'0.01',min:0}),b('counted','Dinheiro contado agora (R$)','number',{step:'0.01',min:0}),b('note','Observação','textarea',{full:true,rows:2})])+info()},
    onBind:function(k,v){f[k]=v;var el=RM.$('closeInfo');if(el)el.outerHTML=info()},
    onSubmit:function(){if(f.counted===''){ui.toast('Informe o dinheiro contado.','err');return false}d.saveClosing(DATA(),{date:date,opening:f.opening,counted:f.counted,note:f.note});ui.q.closeDate=date;RM.persist();ui.toast('Caixa fechado.')}});
};
A['close.print']=function(ds){var c=DATA().closings.find(function(x){return x.id===ds.id});if(c)P.doc(P.closingHtml(c),'Fechamento-'+c.date)};
A['close.send']=function(ds){
  var c=DATA().closings.find(function(x){return x.id===ds.id});if(!c)return;var co=DATA().settings.company.name||'Oficina';
  RM.open(RM.waLink('',['*Fechamento de caixa — '+co+'*',RM.dateBR(c.date),'','Entradas: '+money(c.in),'Saídas: '+money(c.out),'Saldo do dia: '+money(c.in-c.out),'','Dinheiro esperado: '+money(c.expected),'Contado: '+money(c.counted),'Diferença: '+money(c.diff)+(c.note?'\nObs.: '+c.note:'')].join('\n')));
};

/* ---- Lucro por período ---- */
function profitTab(){
  var data=DATA(),from=ui.q.profitFrom,to=ui.q.profitTo,key=ui.q.profitRange||'month';
  var r=(from||to)?[from||'0000-01-01',to||RM.today()]:rangeFor(key),p=d.profit(data,r[0],r[1]);
  var top=p.top.length?p.top.map(function(x){return '<div class="payrow"><span>'+esc(x.name)+'</span><b>'+x.qty+' un · '+money(x.revenue)+'</b></div>'}).join(''):'<div class="muted small">Sem peças vendidas por ordens do estoque no período.</div>';
  return rangeChips('profitRange','month').replace(/data-key="profitRange"/g,'data-key="profitRange" data-clear="1"')
   +'<div class="toolbar"><label class="inl">De <input type="date" data-q="profitFrom" value="'+esc(r[0]==='0000-01-01'?'':r[0])+'"></label><label class="inl">até <input type="date" data-q="profitTo" value="'+esc(r[1]==='9999-12-31'?'':r[1])+'"></label></div>'
   +'<div class="stats mini3">'+ui.stat('Faturamento',money(p.revenue),p.count+' OS concluídas/entregues','positive')+ui.stat('Lucro bruto',money(p.gross),'Faturamento − custo das peças','')+ui.stat('Lucro líquido',money(p.net),'Após comissões e despesas',p.net<0?'neg':'positive')+'</div>'
   +'<div class="card"><div class="cardhead"><h2>Como chegamos nesse resultado</h2></div>'+kv('Mão de obra',money(p.labor))+kv('Peças vendidas',money(p.parts))+(p.discount>0?kv('Descontos','− '+money(p.discount)):'')+'<div class="kv big"><span>Faturamento</span><b>'+money(p.revenue)+'</b></div>'+kv('Custo das peças','− '+money(p.costParts))+kv('Comissões dos mecânicos','− '+money(p.commissions))+kv('Despesas (caixa)','− '+money(p.expenses))+'<div class="kv big"><span>Lucro líquido</span><b class="'+(p.net<0?'neg':'pos')+'">'+money(p.net)+'</b></div></div>'
   +'<div class="grid2"><div class="card"><div class="cardhead"><h2>Indicadores</h2></div>'+kv('Ticket médio',money(p.avgTicket))+kv('Recebido no caixa',money(p.received))+kv('Compras de estoque (fora do lucro)',money(p.purchases))+kv('Retiradas do dono (fora do lucro)',money(p.withdrawals))+'</div><div class="card"><div class="cardhead"><h2>Peças mais vendidas</h2></div>'+top+'</div></div>'
   +(p.legacyNoCost?'<div class="notice">'+p.legacyNoCost+' ordem(ns) antiga(s) não têm o custo das peças registrado; o lucro bruto delas considera custo zero.</div>':'');
}
document.addEventListener('change',function(e){
  var el=e.target;if(!el||!el.getAttribute)return;var q=el.getAttribute('data-q');if(!q)return;
  ui.q[q]=el.value;
  ui.render(true);
});
var rangeAct=A['fin.range'];
A['fin.range']=function(ds,el){if(ds.key==='profitRange'){ui.q.profitFrom='';ui.q.profitTo=''}rangeAct(ds)};

/* ======================= MECÂNICOS E COMISSÕES ======================= */
pages.team={title:'Mecânicos e comissões',icon:'🛠',label:'Mecânicos',
render:function(){
  var data=DATA(),key=ui.q.teamRange||'month',r=rangeFor(key),rep=d.mechanicReport(data,r[0],r[1]);
  var mech=rep.map(function(x){
    var m=x.mechanic;
    return '<div class="card"><div class="cardhead"><h2>'+esc(m.name)+'</h2><span class="muted small">'+RM.num(m.commission)+'% sobre a mão de obra</span></div>'
     +kv('Ordens no período',String(x.orders.length))+kv('Mão de obra no período',money(x.labor))+'<div class="kv big"><span>Comissão no período</span><b>'+money(x.commission)+'</b></div>'+kv('Pendente de pagamento (total)','<span class="'+(x.pending>0?'owe':'')+'">'+money(x.pending)+'</span>')
     +(x.pendingOrders.length?'<div class="muted small" style="margin-top:6px">'+x.pendingOrders.slice(0,6).map(function(o){return '#'+esc(o.number)+' ('+money(d.commission(data,o))+')'}).join(' · ')+(x.pendingOrders.length>6?' …':'')+'</div>':'')
     +'<div class="btnrow">'+(x.pending>0?'<button type="button" class="btn primary" data-act="mech.pay" data-id="'+esc(m.id)+'">💵 Pagar comissões ('+money(x.pending)+')</button>':'')+'<button type="button" class="btn" data-act="mech.edit" data-id="'+esc(m.id)+'">✏️ Editar</button><button type="button" class="btn danger" data-act="mech.del" data-id="'+esc(m.id)+'">🗑</button></div></div>';
  }).join('');
  return '<div class="toolbar"><h2>Mecânicos e comissões</h2><button type="button" class="btn primary" data-act="mech.new">＋ Novo mecânico</button></div>'+rangeChips('teamRange','month')
   +(mech||'<div class="card">'+ui.empty('Nenhum mecânico cadastrado','Cadastre os mecânicos e a % de comissão; depois escolha o mecânico em cada OS.')+'</div>')
   +'<div class="notice">A comissão é calculada sobre a <b>mão de obra</b> das ordens concluídas/entregues e é “congelada” no momento da conclusão.</div>';
}};
function openMechForm(m){
  ui.open({title:m?'Editar mecânico':'Novo mecânico',submitLabel:'Salvar',
    render:function(){var v=m||{};return ui.fields([{name:'name',label:'Nome',value:v.name,full:true},{name:'commission',label:'Comissão (% da mão de obra)',type:'number',value:v.commission!==undefined?v.commission:'',step:'0.5',min:0}])},
    onSubmit:function(v){var rec={name:String(v.name).trim(),commission:RM.num(v.commission)};if(rec.commission>100){ui.toast('Comissão acima de 100%.','err');return false}if(m)Object.assign(m,rec);else DATA().mechanics.push(Object.assign({id:RM.uid()},rec));RM.persist();ui.toast('Salvo.')}});
}
A['mech.new']=function(){openMechForm(null)};
A['mech.edit']=function(ds){var m=DATA().mechanics.find(function(x){return x.id===ds.id});if(m)openMechForm(m)};
A['mech.del']=function(ds){var m=DATA().mechanics.find(function(x){return x.id===ds.id});if(!m)return;ui.confirm('Excluir o mecânico '+m.name+'?\nAs ordens antigas mantêm o vínculo, mas a comissão pendente deixa de ser calculada.',function(){DATA().mechanics=DATA().mechanics.filter(function(x){return x.id!==m.id});RM.persist()},{danger:true,okLabel:'Excluir'})};
A['mech.pay']=function(ds){
  var data=DATA(),rep=d.mechanicReport(data,'0000-01-01','9999-12-31').find(function(x){return x.mechanic.id===ds.id});if(!rep)return;
  ui.open({title:'Pagar comissões — '+rep.mechanic.name,submitLabel:'Registrar pagamento',
    render:function(){return '<p class="muted">'+rep.pendingOrders.length+' ordem(ns) pendente(s). Total: <b>'+money(rep.pending)+'</b>. O valor sairá no caixa como “Comissão”.</p>'+ui.fields([{name:'method',label:'Forma de pagamento',type:'select',options:ui.METHODS,value:'Dinheiro'},{name:'date',label:'Data',type:'date',value:RM.today()}])},
    onSubmit:function(v){var t=d.payCommissions(DATA(),ds.id,rep.pendingOrders.map(function(o){return o.id}),v);RM.persist();ui.toast('Pago: '+money(t))}});
};
})();

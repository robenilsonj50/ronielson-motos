/* pages-ops.js — Visão geral, Ordens de serviço, Clientes e motos, Lembretes */
(function(){
'use strict';
var RM=window.RM,ui=RM.ui,d=RM.d,esc=RM.esc,money=RM.money,P=RM.print,A=RM.act,pages=RM.pages;
function DATA(){return RM.data}
function findOrder(id){return DATA().orders.find(function(x){return x.id===id})}
function findCustomer(id){return DATA().customers.find(function(x){return x.id===id})}
function customerLabel(c){return c.name+(c.bike?' — '+c.bike:'')+(c.plate?' ('+c.plate+')':'')}
function kv(k,v){return '<div class="kv"><span>'+esc(k)+'</span><b>'+v+'</b></div>'}

/* ======================= VISÃO GERAL ======================= */
pages.dashboard={title:'Visão geral',icon:'▦',label:'Visão geral',
render:function(){
  var data=DATA(),today=RM.today(),owner=ui.isOwner(),ms=RM.monthStart(today),me=RM.monthEnd(today);
  var open=data.orders.filter(function(o){return d.isOpen(o.status)}).length,quotes=data.orders.filter(function(o){return o.status==='Orçamento'}).length;
  var low=d.lowParts(data).length,rem=d.reminders(data,today,data.settings.reminderWindow).filter(function(x){return !x.sent}).length;
  var stats=owner?[
    ui.stat('Entradas no mês',money(d.cashTotals(data,ms,me).in),'Recebimentos lançados','positive','↗'),
    ui.stat('A receber',money(d.totalReceivable(data)),'Fiado e saldos em aberto','','$'),
    ui.stat('OS em aberto',String(open),'Serviços em andamento','','☷'),
    ui.stat('Estoque baixo',String(low),'Itens no mínimo ou abaixo','warning','!')
  ]:[
    ui.stat('OS em aberto',String(open),'Serviços em andamento','','☷'),
    ui.stat('Orçamentos',String(quotes),'Aguardando aprovação','','📝'),
    ui.stat('Estoque baixo',String(low),'Itens no mínimo ou abaixo','warning','!'),
    ui.stat('Lembretes',String(rem),'Clientes para avisar','','⏰')
  ];
  var al=[];
  if(owner){var lb=data.settings.lastBackupAt,days=lb?RM.daysBetween(lb.slice(0,10),today):null;
    if(days===null||days>7)al.push(['💾',days===null?'Você ainda não fez nenhum backup.':'Último backup há '+days+' dias.','Fazer backup','settings.backup','']);
    var due=d.payablesPending(data).filter(function(x){return x.due<=RM.addDays(today,3)}).length;
    if(due)al.push(['💳',due+' conta(s) a pagar vencida(s) ou vencendo.','Ver contas','dash.payables','']);
    var debt=d.debtors(data).length;if(debt)al.push(['💰',debt+' cliente(s) com valor em aberto.','Ver fiado','dash.recv','']);
  }
  if(rem)al.push(['⏰',rem+' cliente(s) para avisar da revisão.','Ver lembretes','go','reminders']);
  if(low)al.push(['📦',low+' peça(s) em falta ou no mínimo.','Ver estoque','go','inventory']);
  if(quotes&&owner)al.push(['📝',quotes+' orçamento(s) aguardando aprovação.','Ver','orders.filterquote','']);
  var alertsHtml=al.length?al.map(function(a){return '<div class="alertrow"><span>'+a[0]+' '+esc(a[1])+'</span><button type="button" class="btn sm" data-act="'+a[3]+'" data-page="'+a[4]+'">'+esc(a[2])+'</button></div>'}).join(''):'<div class="muted small">Tudo em dia por aqui. 👍</div>';
  var recent=data.orders.slice(0,5).map(orderCard).join('')||ui.empty('Nenhuma ordem ainda','Use “Novo orçamento” para começar.');
  var quick='<button type="button" data-act="order.new" data-status="Orçamento"><span class="qicon">📝</span><b>Novo orçamento</b><span>Enviar ao cliente</span></button>'
   +'<button type="button" data-act="order.new" data-status="Aprovada"><span class="qicon">＋</span><b>Nova OS direta</b><span>Abrir serviço</span></button>'
   +'<button type="button" data-act="customer.new"><span class="qicon">♙</span><b>Novo cliente</b><span>Cliente e moto</span></button>'
   +(owner?'<button type="button" data-act="part.new"><span class="qicon">▤</span><b>Cadastrar peça</b><span>Adicionar ao estoque</span></button><button type="button" data-act="cash.new"><span class="qicon">↔</span><b>Lançar caixa</b><span>Entrada ou saída</span></button>':'');
  return '<div class="stats">'+stats.join('')+'</div>'
   +'<div class="grid2"><div class="card"><div class="cardhead"><h2>Ordens recentes</h2><button type="button" class="btn" data-act="go" data-page="orders">Ver todas →</button></div><div class="list">'+recent+'</div></div>'
   +'<div><div class="card" style="margin-bottom:16px"><div class="cardhead"><h2>Atenção</h2></div>'+alertsHtml+'</div>'
   +'<div class="card"><div class="cardhead"><h2>Ações rápidas</h2></div><div class="quick">'+quick+'</div></div></div></div>'
   +'<div class="footer">'+esc(data.settings.company.name||'Oficina')+' • Gestão da oficina • v'+RM.VERSION+'</div>';
}};
A['dash.payables']=function(){ui.tab.finance='pay';ui.go('finance')};
A['dash.recv']=function(){ui.tab.finance='recv';ui.go('finance')};
A['orders.filterquote']=function(){ui.q.ordersFilter='quote';ui.go('orders')};

/* ======================= ORDENS DE SERVIÇO ======================= */
function orderCard(o){
  var bal=d.balance(o),g=d.inWarranty(o,RM.today());
  return '<div class="item" data-act="order.view" data-id="'+esc(o.id)+'"><div class="item-main"><b>#'+esc(o.number)+' · '+esc(o.customer||'Cliente')+'</b>'
   +'<span class="muted">'+esc(String(o.bike||'—').replace(/ — .*$/,''))+(o.plate?' · '+esc(o.plate):'')+'</span><span class="muted small">'+esc(o.problem||'')+'</span></div>'
   +'<div class="item-side">'+ui.statusPill(o.status)+(g?' '+ui.pill('Garantia','green'):'')+'<b>'+money(d.orderTotal(o))+'</b>'+(bal>0?'<span class="owe">Deve '+money(bal)+'</span>':'')+'</div></div>';
}
var ORDER_FILTERS={all:['Todas',function(){return true}],quote:['Orçamentos',function(o){return o.status==='Orçamento'}],open:['Em aberto',function(o){return d.isOpen(o.status)}],done:['Concluídas',function(o){return d.isDone(o.status)}],recv:['A receber',function(o){return d.balance(o)>0}],canceled:['Canceladas',function(o){return o.status==='Cancelada'}]};
pages.orders={title:'Ordens de serviço',icon:'☷',label:'Ordens',
filtered:function(){
  var q=String(ui.q.orders||'').toLowerCase().trim(),np=d.normPlate(q),f=ORDER_FILTERS[ui.q.ordersFilter||'all']||ORDER_FILTERS.all;
  return DATA().orders.filter(function(o){
    if(!f[1](o))return false;if(!q)return true;
    var c=o.plate?null:P.customerOf(o),plate=o.plate||(c&&c.plate)||'';
    var hay=(o.number+' '+o.customer+' '+o.bike+' '+plate+' '+(o.problem||'')).toLowerCase();
    return hay.indexOf(q)>-1||(np&&d.normPlate(plate).indexOf(np)>-1);
  });
},
list:function(){
  var list=pages.orders.filtered();
  return list.length?'<div class="list">'+list.map(orderCard).join('')+'</div>':ui.empty('Nenhuma ordem encontrada','Ajuste o filtro ou crie um novo orçamento.');
},
render:function(){
  var cur=ui.q.ordersFilter||'all';
  var chips=Object.keys(ORDER_FILTERS).map(function(k){return '<button type="button" class="chip'+(cur===k?' active':'')+'" data-act="orders.filter" data-k="'+k+'">'+esc(ORDER_FILTERS[k][0])+'</button>'}).join('');
  return '<div class="toolbar"><h2>Ordens de serviço</h2><button type="button" class="btn primary" data-act="order.new" data-status="Orçamento">＋ Novo orçamento</button></div>'
   +'<div class="card"><div class="chips">'+chips+'</div><div class="toolbar">'+ui.searchBox('orders','Buscar nº, cliente, moto, placa ou serviço...')+'</div><div id="list-orders">'+pages.orders.list()+'</div></div>';
}};
A['orders.filter']=function(ds){ui.q.ordersFilter=ds.k;ui.render(true)};

/* ---- formulário de orçamento/OS (rascunho em memória; cada campo atualiza o rascunho) ---- */
var draft=null;
function orderDraft(o,pre){
  var S=DATA().settings;
  if(o)return {id:o.id,customerId:o.customerId||'',customer:o.customer||'',bike:o.bike||'',plate:o.plate||'',km:o.km===undefined?'':o.km,problem:o.problem||'',labor:o.labor||'',discount:o.discount||'',
    items:(o.items||[]).map(function(i){return Object.assign({},i)}),mechanicId:o.mechanicId||'',warrantyDays:o.warrantyDays!==undefined?o.warrantyDays:0,nextDate:o.nextDate||'',nextKm:o.nextKm===undefined?'':o.nextKm,notes:o.notes||'',status:o.status,_partsLegacy:(!o.items||!o.items.length)?RM.num(o.partsCost):0};
  var c=pre&&pre.customerId?findCustomer(pre.customerId):null;
  return {id:'',customerId:c?c.id:'',customer:c?c.name:'',bike:c?(c.bike||''):'',plate:c?(c.plate||''):'',km:c&&c.km!==''&&c.km!=null?c.km:'',problem:'',labor:'',discount:'',items:[],mechanicId:'',warrantyDays:S.warrantyDays,nextDate:'',nextKm:'',notes:'',status:(pre&&pre.status)||'Orçamento',_partsLegacy:0};
}
function draftOrderLike(){return {items:draft.items,labor:draft.labor,discount:draft.discount,partsCost:draft._partsLegacy}}
function totalsHtml(){
  var o=draftOrderLike();
  return kv('Peças',money(d.itemsTotal(o)))+kv('Mão de obra',money(RM.num(draft.labor)))+(RM.num(draft.discount)>0?kv('Desconto','− '+money(RM.num(draft.discount))):'')+'<div class="kv big"><span>TOTAL</span><b>'+money(d.orderTotal(o))+'</b></div>';
}
function orderFormBody(){
  var data=DATA(),owner=ui.isOwner(),isNew=!draft.id;
  var custOpts=[['','— Cliente avulso / digitar abaixo —']].concat(data.customers.map(function(c){return [c.id,customerLabel(c)]}));
  var items=draft.items.map(function(i,idx){
    var p=i.partId?data.parts.find(function(x){return x.id===i.partId}):null,roPrice=(!owner&&i.partId)?' readonly':'';
    var warn=p&&RM.num(i.qty)>RM.num(p.qty)?'<small class="warn">Estoque: '+RM.num(p.qty)+'</small>':(p?'<small class="muted">Estoque: '+RM.num(p.qty)+'</small>':'');
    return '<div class="orow"><div class="oname">'+(i.partId?esc(i.name):'<input type="text" data-bind="item.'+idx+'.name" value="'+esc(i.name)+'" placeholder="Descrição do item">')+warn+'</div>'
     +'<label>Qtd<input type="number" inputmode="decimal" step="any" min="0" data-bind="item.'+idx+'.qty" value="'+esc(i.qty)+'"></label>'
     +'<label>Valor un.<input type="number" inputmode="decimal" step="0.01" min="0" data-bind="item.'+idx+'.price" value="'+esc(i.price)+'"'+roPrice+'></label>'
     +'<button type="button" class="btn danger sm" data-act="order.itemDel" data-i="'+idx+'" aria-label="Remover">✕</button></div>';
  }).join('')||'<div class="muted small">Nenhuma peça lançada.</div>';
  var partOpts=data.parts.slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name))}).map(function(p){return '<option value="'+esc(p.id)+'">'+esc(p.name)+' — '+money(p.price)+' (est. '+RM.num(p.qty)+')</option>'}).join('');
  var addRow='<div class="addrow">'+(partOpts?'<select id="partPick"><option value="">Escolher peça do estoque…</option>'+partOpts+'</select><button type="button" class="btn sm" data-act="order.addPart">＋ Peça</button>':'')
    +'<button type="button" class="btn sm" data-act="order.scanPart">📷 Escanear</button><button type="button" class="btn sm" data-act="order.addFree">＋ Item livre</button></div>';
  var b=function(name,label,type,extra){return Object.assign({name:name,label:label,type:type||'text',value:draft[name],required:false,attrs:'data-bind="'+name+'"'},extra||{})};
  var mechs=data.mechanics.length?ui.field(b('mechanicId','Mecânico','select',{options:[['','— Não informado —']].concat(data.mechanics.map(function(m){return [m.id,m.name]}))})):'';
  var statusField=isNew?ui.field(b('status','Situação inicial','select',{options:[['Orçamento','Orçamento (aguardando aprovação)'],['Aprovada','OS aprovada'],['Em andamento','Em andamento (baixa o estoque)']]})):'';
  return '<div class="formgrid">'
   +ui.field(b('customerId','Cliente / moto cadastrados','select',{options:custOpts,full:true}))
   +ui.field(b('customer','Nome do cliente'))+ui.field(b('bike','Moto'))+ui.field(b('plate','Placa'))+ui.field(b('km','Km atual','number',{step:'1',min:0}))
   +ui.field(b('problem','Defeito relatado / serviço','textarea',{full:true,rows:2}))+statusField+mechs+'</div>'
   +'<h3 class="subh">Peças</h3><div id="orderItems">'+items+'</div>'+addRow
   +'<div class="formgrid" style="margin-top:12px">'+ui.field(b('labor','Mão de obra (R$)','number',{step:'0.01',min:0}))+(owner?ui.field(b('discount','Desconto (R$)','number',{step:'0.01',min:0})):'')+'</div>'
   +'<div class="totals" id="ordTotals">'+totalsHtml()+'</div>'
   +'<h3 class="subh">Garantia e próxima revisão</h3><div class="formgrid">'+ui.field(b('warrantyDays','Garantia (dias)','number',{step:'1',min:0}))
   +ui.field(b('nextDate','Próxima revisão (data)','date'))+ui.field(b('nextKm','Próxima revisão (km)','number',{step:'1',min:0}))+'</div>'
   +'<div class="chips"><span class="muted small">Sugerir revisão em:</span> <button type="button" class="chip" data-act="order.nextIn" data-m="3">3 meses</button><button type="button" class="chip" data-act="order.nextIn" data-m="6">6 meses</button><button type="button" class="chip" data-act="order.nextIn" data-m="12">1 ano</button></div>'
   +'<div class="formgrid" style="margin-top:12px">'+ui.field(b('notes','Observações','textarea',{full:true,rows:2}))+'</div>';
}
function openOrderForm(o,pre){
  draft=orderDraft(o,pre);
  ui.open({title:o?'Editar #'+o.number:(draft.status==='Orçamento'?'Novo orçamento':'Nova ordem de serviço'),submitLabel:o?'Salvar alterações':'Salvar',
    render:orderFormBody,
    onBind:function(key,val,el,changed){
      if(key==='customerId'){
        if(draft.customerId===val)return;draft.customerId=val;var c=val?findCustomer(val):null;
        if(c){draft.customer=c.name;draft.bike=c.bike||'';draft.plate=c.plate||'';draft.km=c.km!==''&&c.km!=null?c.km:''}
        ui.refresh();return;
      }
      var m=/^item\.(\d+)\.(\w+)$/.exec(key);
      if(m){var it=draft.items[+m[1]];if(it)it[m[2]]=val}else draft[key]=val;
      var t=RM.$('ordTotals');if(t)t.innerHTML=totalsHtml();
    },
    onSubmit:function(){
      var data=DATA();
      if(!String(draft.customer||'').trim()){ui.toast('Informe o nome do cliente.','err');return false}
      if(!String(draft.problem||'').trim()&&!draft.items.length&&!RM.num(draft.labor)){ui.toast('Descreva o serviço, lance peças ou a mão de obra.','err');return false}
      var wasNew=!draft.id,wantStatus=draft.status;
      var r=d.saveOrder(data,draft,RM.today());
      if(wasNew&&wantStatus&&wantStatus!=='Orçamento'){var s=d.setStatus(data,r.order.id,wantStatus,RM.today());r.warnings=r.warnings.concat(s.warnings)}
      RM.persist();
      r.warnings.forEach(function(w){ui.toast(w,'err')});
      if(wasNew){ui.close();openOrder(r.order.id);ui.toast('Salvo: #'+r.order.number);return false}
      ui.toast('Alterações salvas.');
    }});
}
A['order.new']=function(ds){openOrderForm(null,{status:ds.status||'Orçamento',customerId:ds.customer||''})};
A['order.edit']=function(ds){var o=findOrder(ds.id);if(o)openOrderForm(o)};
A['order.itemDel']=function(ds){draft.items.splice(+ds.i,1);ui.refresh()};
A['order.addFree']=function(){draft.items.push({partId:'',name:'',qty:1,price:'',cost:0});ui.refresh()};
function addPartToDraft(p){
  var ex=draft.items.find(function(i){return i.partId===p.id});
  if(ex)ex.qty=RM.num(ex.qty)+1;else draft.items.push({partId:p.id,name:p.name,qty:1,price:p.price,cost:p.cost});
  ui.refresh();
}
A['order.addPart']=function(){var sel=RM.$('partPick');if(!sel||!sel.value){ui.toast('Escolha uma peça.','err');return}var p=DATA().parts.find(function(x){return x.id===sel.value});if(p)addPartToDraft(p)};
A['order.scanPart']=function(){RM.scan(function(code){var p=DATA().parts.find(function(x){return x.sku&&String(x.sku)===String(code)});if(p){addPartToDraft(p);ui.toast('Adicionado: '+p.name)}else ui.toast('Código não encontrado no estoque: '+code,'err')},{prompt:true})};
A['order.nextIn']=function(ds){draft.nextDate=RM.addMonths(RM.today(),+ds.m);ui.refresh()};

/* ---- detalhe da ordem ---- */
function nextStep(o){
  var s=o.status;
  if(s==='Orçamento')return ['Aprovada','✅ Aprovar orçamento'];
  if(s==='Aprovada'||s==='Aberta')return ['Em andamento','🔧 Iniciar serviço'];
  if(s==='Em andamento'||s==='Aguardando peça')return ['Concluída','✔ Marcar concluída'];
  if(s==='Concluída')return ['Entregue','📦 Entregar ao cliente'];
  return null;
}
function photosHtml(o){
  if(!RM.photos.available())return '<div class="muted small">As fotos antes/depois funcionam no aplicativo Android.</div>';
  var out='';
  ['antes','depois'].forEach(function(kind){
    var list=(o.photos||[]).filter(function(p){return p.kind===kind});
    out+='<div class="photoblock"><div class="photohead"><b>'+(kind==='antes'?'Antes':'Depois')+'</b><button type="button" class="btn sm" data-act="photo.take" data-id="'+esc(o.id)+'" data-kind="'+kind+'">📷 Foto '+kind+'</button></div><div class="photos">'
      +(list.map(function(p){var src=RM.photos.get(p.name,360);return src?'<img class="thumb" src="'+src+'" alt="" data-act="photo.view" data-id="'+esc(o.id)+'" data-name="'+esc(p.name)+'">':'<div class="thumb missing" data-act="photo.view" data-id="'+esc(o.id)+'" data-name="'+esc(p.name)+'">indisponível</div>'}).join('')||'<span class="muted small">Sem fotos.</span>')+'</div></div>';
  });
  return out;
}
function orderDetailHtml(o){
  var data=DATA(),c=P.customerOf(o),owner=ui.isOwner(),total=d.orderTotal(o),paid=d.paid(o),bal=d.balance(o),w=d.warrantyUntil(o),step=nextStep(o);
  var items=(o.items||[]).map(function(i){return '<tr><td>'+esc(i.name)+'</td><td class="r">'+RM.num(i.qty)+'</td><td class="r">'+money(i.price)+'</td><td class="r">'+money(RM.num(i.qty)*RM.num(i.price))+'</td></tr>'}).join('');
  if(!items&&RM.num(o.partsCost)>0)items='<tr><td>Peças (valor lançado)</td><td class="r">1</td><td class="r">'+money(o.partsCost)+'</td><td class="r">'+money(o.partsCost)+'</td></tr>';
  var pays=(o.payments||[]).map(function(p){return '<div class="payrow"><span>'+RM.dateBR(p.date)+' · '+esc(p.method)+'</span><b>'+money(p.amount)+'</b>'+(owner?'<button type="button" class="btn danger sm" data-act="order.payDel" data-id="'+esc(o.id)+'" data-pay="'+esc(p.id)+'" aria-label="Remover pagamento">✕</button>':'')+'</div>'}).join('');
  var mech=o.mechanicId?data.mechanics.find(function(m){return m.id===o.mechanicId}):null;
  var statusSel='<select data-bind="status" aria-label="Alterar situação">'+d.statusOptions(o.status).map(function(s){return '<option'+(s===o.status?' selected':'')+'>'+esc(s)+'</option>'}).join('')+'</select>';
  var money2=function(label,v,cls){return '<div class="kv '+(cls||'')+'"><span>'+label+'</span><b>'+v+'</b></div>'};
  return '<div class="odhead"><div><b class="odnum">#'+esc(o.number)+'</b> '+ui.statusPill(o.status)+(d.inWarranty(o,RM.today())?' '+ui.pill('Em garantia','green'):'')+'</div><div class="muted small">Criada em '+RM.dateBR(o.created)+(o.doneAt?' • Concluída em '+RM.dateBR(o.doneAt):'')+'</div></div>'
   +'<div class="card2">'+kv('Cliente',esc(o.customer||'—')+(c&&c.phone?' · '+esc(c.phone):''))+kv('Moto',esc(String(o.bike||'—').replace(/ — .*$/,''))+(o.plate?' · '+esc(o.plate):''))+(o.km!==''&&o.km!=null?kv('Km',RM.num(o.km)):'')+(mech?kv('Mecânico',esc(mech.name)):'')+kv('Serviço',esc(o.problem||'—'))+'</div>'
   +(step&&ui.can('orders.status')?'<button type="button" class="btn primary wide" data-act="order.step" data-id="'+esc(o.id)+'">'+step[1]+'</button>':'')
   +'<div class="field"><label>Situação</label>'+statusSel+'</div>'
   +'<h3 class="subh">Peças e valores</h3><div class="tablewrap"><table class="mini"><thead><tr><th>Item</th><th class="r">Qtd</th><th class="r">Unit.</th><th class="r">Total</th></tr></thead><tbody>'+(items||'<tr><td colspan="4" class="muted">Sem peças.</td></tr>')+'</tbody></table></div>'
   +'<div class="totals">'+money2('Mão de obra',money(o.labor))+(RM.num(o.discount)>0?money2('Desconto','− '+money(o.discount)):'')+money2('TOTAL',money(total),'big')
   +(o.status==='Orçamento'||o.status==='Cancelada'||o.balanceExempt?'':money2('Pago',money(paid))+money2('Saldo a receber',money(bal),bal>0?'owe':''))+'</div>'
   +(pays?'<div class="payrows">'+pays+'</div>':'')
   +(bal>0&&ui.can('orders.payment')?'<button type="button" class="btn wide" data-act="order.pay" data-id="'+esc(o.id)+'">💵 Registrar pagamento</button>':'')
   +(w||o.nextDate?'<div class="card2" style="margin-top:12px">'+(RM.num(o.warrantyDays)>0?kv('Garantia',RM.num(o.warrantyDays)+' dias'+(w?' (até '+RM.dateBR(w)+')':' após a entrega')):'')+(o.nextDate?kv('Próxima revisão',RM.dateBR(o.nextDate)+(o.nextKm?' ou '+RM.num(o.nextKm)+' km':'')):'')+'</div>':'')
   +(o.notes?'<div class="note">'+esc(o.notes)+'</div>':'')
   +(ui.can('photos')?'<h3 class="subh">Fotos</h3>'+photosHtml(o):'')
   +'<div class="btnrow"><button type="button" class="btn" data-act="order.print" data-id="'+esc(o.id)+'">📄 PDF / Imprimir</button><button type="button" class="btn" data-act="order.whats" data-id="'+esc(o.id)+'">💬 WhatsApp</button>'
   +(ui.can('orders.edit')?'<button type="button" class="btn" data-act="order.edit" data-id="'+esc(o.id)+'">✏️ Editar</button>':'')+(owner?'<button type="button" class="btn danger" data-act="order.del" data-id="'+esc(o.id)+'">🗑 Excluir</button>':'')+'</div>';
}
function openOrder(id){
  ui.open({live:true,title:function(){var o=findOrder(id);return o?(o.status==='Orçamento'?'Orçamento':'Ordem de serviço'):''},
    render:function(){var o=findOrder(id);return o?orderDetailHtml(o):'<p class="muted">Ordem não encontrada.</p>'},
    onBind:function(k,v,el,changed){if(k==='status'&&changed)changeStatus(id,v)}});
}
A['order.view']=function(ds){openOrder(ds.id)};
function changeStatus(id,status){
  var data=DATA(),o=findOrder(id);if(!o||o.status===status)return;
  function apply(){
    var r=d.setStatus(data,id,status,RM.today());
    if(d.isDone(status)&&!o.nextDate&&RM.num(data.settings.reminderMonths)>0)o.nextDate=RM.addMonths(RM.today(),RM.num(data.settings.reminderMonths));
    RM.persist();r.warnings.forEach(function(w){ui.toast(w,'err')});
    if(!r.warnings.length)ui.toast('Situação: '+status);
    if(status==='Entregue'&&d.balance(o)>0)ui.toast('Há saldo a receber: '+money(d.balance(o))+'. Registre o pagamento ou deixe como fiado.');
  }
  if(status==='Cancelada'||(d.isDone(o.status)&&!d.isDone(status)))ui.confirm('Mudar de "'+o.status+'" para "'+status+'"?'+(status==='Cancelada'?'\nAs peças serão devolvidas ao estoque.':''),apply,{okLabel:'Mudar',danger:status==='Cancelada'});
  else apply();
  ui.refresh();
}
A['order.step']=function(ds){var o=findOrder(ds.id),s=o&&nextStep(o);if(s)changeStatus(ds.id,s[0])};
A['order.pay']=function(ds){
  var o=findOrder(ds.id);if(!o)return;var bal=d.balance(o);
  ui.open({title:'Registrar pagamento',submitLabel:'Registrar',
    render:function(){return '<p class="muted">Saldo a receber: <b>'+money(bal)+'</b></p>'+ui.fields([{name:'amount',label:'Valor (R$)',type:'number',value:bal,step:'0.01',min:0.01,full:true},{name:'method',label:'Forma de pagamento',type:'select',options:ui.METHODS},{name:'date',label:'Data',type:'date',value:RM.today()}])},
    onSubmit:function(v){var r=d.addPayment(DATA(),o.id,v);if(!r.ok){ui.toast(r.error,'err');return false}RM.persist();ui.toast('Pagamento registrado.')}});
};
A['order.payDel']=function(ds){ui.confirm('Remover este pagamento? Ele também sai do caixa.',function(){d.removePayment(DATA(),ds.id,ds.pay);RM.persist()},{danger:true,okLabel:'Remover'})};
A['order.print']=function(ds){var o=findOrder(ds.id);if(o)P.printOrder(o)};
A['order.whats']=function(ds){var o=findOrder(ds.id);if(!o)return;var c=P.customerOf(o);RM.open(RM.waLink(c&&c.phone,P.orderText(o)))};
A['order.del']=function(ds){var o=findOrder(ds.id);if(!o)return;ui.confirm('Excluir a OS #'+o.number+'?\nPagamentos dela saem do caixa e as peças voltam ao estoque. Isso não pode ser desfeito.',function(){
  (o.photos||[]).forEach(function(p){try{var b=RM.br('AndroidPhoto');if(b&&b.deletePhoto)b.deletePhoto(p.name)}catch(e){}});
  d.deleteOrder(DATA(),ds.id);ui.closeAll();RM.persist();ui.toast('Ordem excluída.')},{danger:true,okLabel:'Excluir'})};
A['photo.take']=function(ds){RM.photos.capture(ds.id,ds.kind)};
A['photo.view']=function(ds){
  var src=RM.photos.get(ds.name,1200);
  ui.open({title:'Foto',render:function(){return src?'<img class="photofull" src="'+src+'" alt="">':'<p class="muted">Arquivo da foto não encontrado neste aparelho (ele não vem junto no backup).</p>'},
    actions:function(){return '<button type="button" class="btn" data-act="ui.close">Fechar</button><button type="button" class="btn danger" data-act="photo.del" data-id="'+esc(ds.id)+'" data-name="'+esc(ds.name)+'">Excluir foto</button>'}});
};
A['photo.del']=function(ds){ui.confirm('Excluir esta foto?',function(){RM.photos.remove(ds.id,ds.name);ui.close()},{danger:true,okLabel:'Excluir'})};

/* ======================= CLIENTES E MOTOS ======================= */
function customerCard(c){
  var data=DATA(),orders=d.vehicleOrders(data,c),today=RM.today(),last=orders.find(function(o){return d.isDone(o.status)});
  var owe=d.debtors(data).find(function(x){return x.key===c.id}),rem=d.reminders(data,today,60).find(function(r){return r.customer.id===c.id});
  return '<div class="item" data-act="customer.view" data-id="'+esc(c.id)+'"><div class="item-main"><b>'+esc(c.name)+'</b><span class="muted">'+esc(c.bike||'Moto não informada')+(c.plate?' · '+esc(c.plate):'')+'</span>'
   +'<span class="muted small">'+(c.phone?esc(c.phone)+' · ':'')+orders.length+' serviço(s)'+(last?' · último em '+RM.dateBR(d.orderDate(last)):'')+'</span></div>'
   +'<div class="item-side">'+(owe?'<span class="owe">Deve '+money(owe.total)+'</span>':'')+(rem?ui.pill(rem.overdue?'Revisão atrasada':'Revisão '+RM.dateBR(rem.date),rem.overdue?'red':'yellow'):'')+(c.km!==''&&c.km!=null?'<span class="muted small">'+RM.num(c.km)+' km</span>':'')+'</div></div>';
}
pages.customers={title:'Clientes e motos',icon:'♙',label:'Clientes',
filtered:function(){
  var q=String(ui.q.customers||'').toLowerCase().trim(),np=d.normPlate(q);
  return DATA().customers.filter(function(c){return !q||(c.name+' '+c.phone+' '+c.bike+' '+c.plate).toLowerCase().indexOf(q)>-1||(np&&d.normPlate(c.plate).indexOf(np)>-1)});
},
list:function(){
  var q=String(ui.q.customers||'').toLowerCase().trim(),list=pages.customers.filtered();
  return list.length?'<div class="list">'+list.map(customerCard).join('')+'</div>':ui.empty(q?'Nada encontrado':'Nenhum cliente cadastrado',q?'Tente outro nome, telefone ou placa.':'Cadastre clientes e suas motocicletas.');
},
render:function(){return '<div class="toolbar"><h2>Clientes e motos</h2><button type="button" class="btn primary" data-act="customer.new">＋ Novo cliente</button></div><div class="card"><div class="toolbar">'+ui.searchBox('customers','Buscar cliente, telefone, moto ou placa...')+'</div><div id="list-customers">'+pages.customers.list()+'</div></div>'}};
function openCustomerForm(c){
  ui.open({title:c?'Editar cliente':'Cadastrar cliente e moto',submitLabel:'Salvar',
    render:function(){var v=c||{};return ui.fields([{name:'name',label:'Nome do cliente',value:v.name},{name:'phone',label:'Telefone / WhatsApp',type:'tel',value:v.phone,required:false},{name:'bike',label:'Moto (marca, modelo e ano)',value:v.bike,required:false},{name:'plate',label:'Placa',value:v.plate,required:false,attrs:'style="text-transform:uppercase"'},{name:'km',label:'Quilometragem atual',type:'number',value:v.km,step:'1',min:0,required:false},{name:'notes',label:'Observações',type:'textarea',value:v.notes,rows:2,full:true,required:false}])},
    onSubmit:function(v){
      var data=DATA(),plate=String(v.plate||'').trim().toUpperCase(),np=d.normPlate(plate);
      if(!String(v.name||'').trim()){ui.toast('Informe o nome.','err');return false}
      if(np&&data.customers.some(function(x){return x.id!==(c&&c.id)&&d.normPlate(x.plate)===np})){ui.toast('Já existe uma moto cadastrada com esta placa.','err');return false}
      var rec={name:String(v.name).trim(),phone:String(v.phone||'').trim(),bike:String(v.bike||'').trim(),plate:plate,km:v.km===''?'':RM.num(v.km),notes:String(v.notes||'').trim()};
      if(c){Object.assign(c,rec);data.orders.forEach(function(o){if(o.customerId===c.id){o.customer=c.name;o.bike=c.bike;o.plate=c.plate}})}
      else data.customers.unshift(Object.assign({id:RM.uid(),created:RM.today()},rec));
      RM.persist();ui.toast('Cliente salvo.');
    }});
}
A['customer.new']=function(){openCustomerForm(null)};
A['customer.edit']=function(ds){var c=findCustomer(ds.id);if(c)openCustomerForm(c)};
function customerDetailHtml(c){
  var data=DATA(),orders=d.vehicleOrders(data,c),today=RM.today(),owner=ui.isOwner();
  var done=orders.filter(function(o){return d.isDone(o.status)}),spent=RM.r2(done.reduce(function(a,o){return a+d.orderTotal(o)},0));
  var owe=d.debtors(data).find(function(x){return x.key===c.id}),nx=done[0]&&done[0].nextDate?done[0]:null;
  var hist=orders.map(function(o){return '<div class="hrow" data-act="order.view" data-id="'+esc(o.id)+'"><div><b>#'+esc(o.number)+'</b> · '+RM.dateBR(d.orderDate(o))+(o.km!==''&&o.km!=null?' · '+RM.num(o.km)+' km':'')+'<div class="muted small">'+esc(o.problem||'')+'</div></div><div class="item-side">'+ui.statusPill(o.status)+(d.inWarranty(o,today)?ui.pill('Garantia','green'):'')+'<b>'+money(d.orderTotal(o))+'</b></div></div>'}).join('')||'<div class="muted small">Sem serviços registrados.</div>';
  return '<div class="card2">'+kv('Moto',esc(c.bike||'—'))+kv('Placa',esc(c.plate||'—'))+kv('Telefone',esc(c.phone||'—'))+(c.km!==''&&c.km!=null?kv('Km',RM.num(c.km)):'')+(c.notes?kv('Obs.',esc(c.notes)):'')+'</div>'
   +'<div class="stats mini3">'+ui.stat('Serviços',String(orders.length),'','')+(owner?ui.stat('Total gasto',money(spent),'','')+ui.stat('Em aberto',money(owe?owe.total:0),'',owe?'warning':''):'')+'</div>'
   +(nx?'<div class="note"><b>Próxima revisão:</b> '+RM.dateBR(nx.nextDate)+(nx.nextKm?' ou '+RM.num(nx.nextKm)+' km':'')+(nx.nextDate<today?' <span class="owe">(atrasada)</span>':'')+'</div>':'')
   +'<h3 class="subh">Histórico da moto</h3><div class="list">'+hist+'</div>'
   +'<div class="btnrow"><button type="button" class="btn primary" data-act="order.new" data-status="Orçamento" data-customer="'+esc(c.id)+'">📝 Novo orçamento</button><button type="button" class="btn" data-act="customer.whats" data-id="'+esc(c.id)+'">💬 WhatsApp</button>'
   +(ui.can('customers.edit')?'<button type="button" class="btn" data-act="customer.edit" data-id="'+esc(c.id)+'">✏️ Editar</button>':'')+(owner?'<button type="button" class="btn danger" data-act="customer.del" data-id="'+esc(c.id)+'">🗑 Excluir</button>':'')+'</div>';
}
A['customer.view']=function(ds){ui.open({live:true,title:function(){var c=findCustomer(ds.id);return c?c.name:''},render:function(){var c=findCustomer(ds.id);return c?customerDetailHtml(c):'<p class="muted">Cliente não encontrado.</p>'}})};
A['customer.whats']=function(ds){var c=findCustomer(ds.id);if(c)RM.open(RM.waLink(c.phone,''))};
A['customer.del']=function(ds){var c=findCustomer(ds.id);if(!c)return;var n=d.vehicleOrders(DATA(),c).length;
  ui.confirm('Excluir '+c.name+'?'+(n?'\nAs '+n+' ordem(ns) dele(a) continuam salvas, mas sem vínculo com o cadastro.':''),function(){DATA().customers=DATA().customers.filter(function(x){return x.id!==c.id});ui.closeAll();RM.persist();ui.toast('Cliente excluído.')},{danger:true,okLabel:'Excluir'})};

/* ======================= LEMBRETES DE REVISÃO ======================= */
pages.reminders={title:'Lembretes de revisão',icon:'⏰',label:'Lembretes',
render:function(){
  var data=DATA(),today=RM.today(),win=RM.num(data.settings.reminderWindow)||15,list=d.reminders(data,today,win);
  var winSel='<select data-act-change="rem.window" id="remWindow" class="inl">'+[7,15,30,60].map(function(n){return '<option value="'+n+'"'+(n===win?' selected':'')+'>próximos '+n+' dias</option>'}).join('')+'</select>';
  function card(r){
    var c=r.customer,o=r.order,when=r.overdue?'atrasada há '+(-r.days)+' dia(s)':(r.days===0?'é hoje':'em '+r.days+' dia(s)');
    return '<div class="item static"><div class="item-main"><b>'+esc(c.name)+'</b><span class="muted">'+esc(c.bike||'Moto')+(c.plate?' · '+esc(c.plate):'')+'</span><span class="muted small">Revisão '+RM.dateBR(r.date)+' ('+when+')'+(o.nextKm?' ou '+RM.num(o.nextKm)+' km':'')+' · última OS #'+esc(o.number)+'</span>'+(r.sent?'<span class="small" style="color:var(--green)">✓ Aviso enviado em '+RM.dateBR(o.reminderSentAt.slice(0,10))+'</span>':'')+'</div>'
     +'<div class="item-side">'+(r.overdue?ui.pill('Atrasada','red'):ui.pill('Próxima','yellow'))+'<button type="button" class="btn primary sm" data-act="rem.send" data-id="'+esc(o.id)+'" data-c="'+esc(c.id)+'">💬 Avisar</button><button type="button" class="btn sm" data-act="rem.snooze" data-id="'+esc(o.id)+'">Adiar 30 dias</button></div></div>';
  }
  var late=list.filter(function(r){return r.overdue}),soon=list.filter(function(r){return !r.overdue});
  return '<div class="toolbar"><h2>Lembretes de revisão</h2>'+winSel+'</div>'
   +'<div class="notice">A data da próxima revisão é sugerida ao concluir uma OS (prazo configurável em Ajustes). Toque em “Avisar” para abrir o WhatsApp com a mensagem pronta.</div>'
   +(late.length?'<div class="card"><div class="cardhead"><h2>Atrasadas ('+late.length+')</h2></div><div class="list">'+late.map(card).join('')+'</div></div>':'')
   +'<div class="card"><div class="cardhead"><h2>Próximas ('+soon.length+')</h2></div>'+(soon.length?'<div class="list">'+soon.map(card).join('')+'</div>':ui.empty('Nenhuma revisão nesse período','Conclua ordens de serviço para gerar lembretes.'))+'</div>';
}};
document.addEventListener('change',function(e){var el=e.target;if(el&&el.id==='remWindow'){DATA().settings.reminderWindow=+el.value;RM.persist()}});
A['rem.send']=function(ds){
  var data=DATA(),o=findOrder(ds.id),c=findCustomer(ds.c);if(!o||!c)return;
  var text=d.fillTemplate(data.settings.reminderTemplate||RM.DEFAULT_REMINDER,d.reminderVars(data,c,o));
  o.reminderSentAt=new Date().toISOString();RM.persist();RM.open(RM.waLink(c.phone,text));
};
A['rem.snooze']=function(ds){var o=findOrder(ds.id);if(!o)return;o.nextDate=RM.addDays(o.nextDate&&o.nextDate>RM.today()?o.nextDate:RM.today(),30);o.reminderSentAt='';RM.persist();ui.toast('Adiado para '+RM.dateBR(o.nextDate))};

RM.openOrder=openOrder;RM.orderCard=orderCard;RM.changeStatus=changeStatus;RM.customerCard=customerCard;RM.ORDER_FILTERS=ORDER_FILTERS;
})();

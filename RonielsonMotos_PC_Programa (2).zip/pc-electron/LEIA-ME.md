# Ronielson Motos — programa para Windows

Janela própria (sem abas nem barra de endereço), instalador com atalhos na área de trabalho e no menu Iniciar,
e uma versão portátil (um único .exe, sem instalar).

## Antes de gerar
Edite `app/js/config.js` (WhatsApp do administrador, chave Pix, valor) — ou faça isso depois e gere de novo.

## Como gerar o .exe (GitHub Actions — não precisa de Windows nem de programação)
1. No seu repositório do GitHub: **Add file → Upload files** e envie o arquivo **RonielsonMotos_PC_Programa.zip** inteiro (sem extrair).
2. **Add file → Create new file**. No nome digite `.github/workflows/gerar-programa-windows.yml` (as barras criam as pastas) e cole o conteúdo do arquivo `gerar-programa-windows.yml`. Salve (Commit).
3. Aba **Actions** → **Gerar programa do Windows (PC)** → **Run workflow**. Leva uns 5 a 8 minutos.
4. Quando ficar verde, abra a execução e, no final da página, em **Artifacts**, baixe **Ronielson-Motos-PC-Windows**. Dentro há:
   - `Ronielson-Motos-Instalador-1.0.0.exe` — instala no computador do cliente (recomendado)
   - `Ronielson-Motos-Portatil-1.0.0.exe` — roda direto, sem instalar

## Aviso do Windows (SmartScreen)
Como o programa ainda não tem assinatura digital paga, o Windows pode mostrar “O Windows protegeu seu computador”.
Clique em **Mais informações → Executar assim mesmo**. (Para eliminar o aviso é preciso comprar um certificado de assinatura de código.)

## Onde ficam os dados
`%APPDATA%\RonielsonMotos` — não muda entre versões; instalar uma versão nova por cima **não** apaga os dados e desinstalar também não.
Faça backup pelo botão “Backup” e guarde o arquivo fora do computador.

## Licença
O código de ativação da versão para COMPUTADOR é diferente do do celular. O ID do computador vem do identificador da própria máquina
e uma cópia do estado do teste fica fora da pasta de dados (limpar os dados não reinicia o teste).

## Se o build falhar
Abra a execução com erro na aba Actions e me envie um print do trecho em vermelho.

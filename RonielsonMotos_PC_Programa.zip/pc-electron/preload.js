'use strict';
/* Ponte segura entre o sistema (páginas) e o programa. Não expõe Node nem acesso livre ao disco. */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('RMDesktop', {
  isDesktop: true,
  machineId: function () { return ipcRenderer.sendSync('rm:machine-id'); },
  shadowRead: function () { return ipcRenderer.sendSync('rm:shadow-read'); },
  shadowWrite: function (json) { return ipcRenderer.sendSync('rm:shadow-write', String(json)); },
  version: function () { return ipcRenderer.sendSync('rm:version'); },
  copy: function (text) { ipcRenderer.send('rm:copy', String(text == null ? '' : text)); },
  openExternal: function (url) { ipcRenderer.send('rm:open', String(url)); },
  printHtml: function (html, title) { ipcRenderer.send('rm:print', String(html), String(title || 'Documento')); }
});

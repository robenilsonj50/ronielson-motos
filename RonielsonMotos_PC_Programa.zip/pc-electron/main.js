'use strict';
/* Ronielson Motos — programa para Windows (Electron). Janela própria, dados em %APPDATA%\RonielsonMotos. */
const { app, BrowserWindow, Menu, ipcMain, shell, dialog, clipboard, session, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const cp = require('child_process');
const crypto = require('crypto');

app.setName('Ronielson Motos');
if (process.platform === 'win32') app.setAppUserModelId('br.com.ronielsonmotos.pc');
// Pasta de dados FIXA: não muda entre versões, então atualizar o programa nunca perde os dados.
app.setPath('userData', path.join(app.getPath('appData'), 'RonielsonMotos'));

let win = null;

/* ---------- registro de erros ---------- */
function logErro(err) {
  try {
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    fs.appendFileSync(path.join(app.getPath('userData'), 'erros.log'), new Date().toISOString() + ' ' + String(err && err.stack || err) + '\n');
  } catch (e) { /* ignora */ }
}
process.on('uncaughtException', logErro);
process.on('unhandledRejection', logErro);

/* ---------- posição/tamanho da janela ---------- */
function stateFile() { return path.join(app.getPath('userData'), 'janela.json'); }
function loadState() { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')) || {}; } catch (e) { return {}; } }
function saveState() {
  try {
    if (!win || win.isDestroyed()) return;
    const b = win.getNormalBounds ? win.getNormalBounds() : win.getBounds();
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    fs.writeFileSync(stateFile(), JSON.stringify({ x: b.x, y: b.y, width: b.width, height: b.height, maximized: win.isMaximized() }));
  } catch (e) { logErro(e); }
}
function visibleOnSomeDisplay(st) {
  try {
    if (typeof st.x !== 'number' || typeof st.y !== 'number') return false;
    return screen.getAllDisplays().some(function (d) {
      const a = d.workArea;
      return st.x >= a.x - 20 && st.y >= a.y - 20 && st.x < a.x + a.width - 100 && st.y < a.y + a.height - 100;
    });
  } catch (e) { return false; }
}

/* ---------- janela ---------- */
function createWindow() {
  const st = loadState();
  const opts = {
    width: Math.max(1000, st.width || 1366), height: Math.max(640, st.height || 840),
    minWidth: 1000, minHeight: 640, backgroundColor: '#080b12', title: 'Ronielson Motos',
    icon: path.join(__dirname, 'build', 'icon.ico'), autoHideMenuBar: true, show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true,
      devTools: !app.isPackaged, spellcheck: false
    }
  };
  if (visibleOnSomeDisplay(st)) { opts.x = st.x; opts.y = st.y; }
  win = new BrowserWindow(opts);
  win.once('ready-to-show', function () { if (st.maximized) win.maximize(); win.show(); });
  win.on('close', saveState);
  win.on('closed', function () { win = null; });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  // links externos (WhatsApp, etc.) abrem no navegador padrão; a janela do sistema nunca navega para fora
  win.webContents.setWindowOpenHandler(function (d) {
    if (/^https:\/\//i.test(d.url)) shell.openExternal(d.url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', function (e, url) {
    if (!/^file:/i.test(url)) { e.preventDefault(); if (/^https:\/\//i.test(url)) shell.openExternal(url); }
  });
  win.webContents.on('render-process-gone', function (e, d) { logErro('render-process-gone: ' + JSON.stringify(d)); });
}

function buildMenu() {
  const tpl = [
    { label: 'Arquivo', submenu: [
      { label: 'Recarregar', accelerator: 'CmdOrCtrl+R', click: function () { if (win) win.reload(); } },
      { type: 'separator' }, { role: 'quit', label: 'Sair' } ] },
    { label: 'Editar', submenu: [
      { role: 'undo', label: 'Desfazer' }, { role: 'redo', label: 'Refazer' }, { type: 'separator' },
      { role: 'cut', label: 'Recortar' }, { role: 'copy', label: 'Copiar' }, { role: 'paste', label: 'Colar' }, { role: 'selectAll', label: 'Selecionar tudo' } ] },
    { label: 'Exibir', submenu: [
      { role: 'resetZoom', label: 'Zoom padrão' }, { role: 'zoomIn', label: 'Aumentar zoom' }, { role: 'zoomOut', label: 'Diminuir zoom' },
      { type: 'separator' }, { role: 'togglefullscreen', label: 'Tela cheia' } ] }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}

/* ---------- identificador da máquina (licença) ---------- */
function machineGuid() {
  try {
    if (process.platform === 'win32') {
      const out = cp.execFileSync('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'], { encoding: 'utf8', windowsHide: true, timeout: 5000 });
      const m = /MachineGuid\s+REG_SZ\s+([0-9a-fA-F-]{16,})/.exec(out);
      if (m) return m[1].toLowerCase();
    }
  } catch (e) { /* cai no plano B */ }
  const f = path.join(app.getPath('userData'), 'maquina.txt');
  try { const v = fs.readFileSync(f, 'utf8').trim(); if (v) return v; } catch (e) { /* cria */ }
  const id = crypto.randomUUID();
  try { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.writeFileSync(f, id); } catch (e) { /* ignora */ }
  return id;
}

/* cópia do estado do teste/licença fora do armazenamento do app (resiste a "limpar dados") */
function shadowPaths() {
  const list = [];
  if (process.env.ProgramData) list.push(path.join(process.env.ProgramData, 'RonielsonMotos', 'lic.dat'));
  list.push(path.join(app.getPath('userData'), 'lic.dat'));
  return list;
}
function shadowRead() {
  let best = null;
  shadowPaths().forEach(function (p) {
    try {
      const o = JSON.parse(Buffer.from(fs.readFileSync(p, 'utf8'), 'base64').toString('utf8'));
      if (!best) best = o;
      else {
        if (o.trialStart && (!best.trialStart || o.trialStart < best.trialStart)) best.trialStart = o.trialStart;
        if ((o.lastSeen || 0) > (best.lastSeen || 0)) best.lastSeen = o.lastSeen;
        if (o.clockFlag) best.clockFlag = true;
        if (!best.code && o.code) best.code = o.code;
      }
    } catch (e) { /* arquivo ausente/ilegível */ }
  });
  return JSON.stringify(best || {});
}
function shadowWrite(json) {
  const data = Buffer.from(String(json), 'utf8').toString('base64');
  let ok = false;
  shadowPaths().forEach(function (p) { try { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, data); ok = true; } catch (e) { /* tenta o próximo */ } });
  return ok;
}

/* ---------- IPC ---------- */
function safeName(s) { return String(s || 'Documento').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 80) || 'Documento'; }
function setupIpc() {
  ipcMain.on('rm:machine-id', function (e) { e.returnValue = machineGuid(); });
  ipcMain.on('rm:shadow-read', function (e) { e.returnValue = shadowRead(); });
  ipcMain.on('rm:shadow-write', function (e, json) { e.returnValue = shadowWrite(json); });
  ipcMain.on('rm:version', function (e) { e.returnValue = app.getVersion(); });
  ipcMain.on('rm:copy', function (e, text) { clipboard.writeText(String(text == null ? '' : text)); });
  ipcMain.on('rm:open', function (e, url) { if (/^https:\/\//i.test(String(url))) shell.openExternal(String(url)); });
  ipcMain.on('rm:print', async function (e, html, title) {
    const tmp = path.join(app.getPath('temp'), 'rm-doc-' + Date.now() + '.html');
    const w = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true, javascript: false } });
    try {
      fs.writeFileSync(tmp, String(html), 'utf8');
      await w.loadFile(tmp);
      const pdf = await w.webContents.printToPDF({ pageSize: 'A4', printBackground: true, preferCSSPageSize: true });
      const r = await dialog.showSaveDialog(win, {
        title: 'Salvar PDF', defaultPath: path.join(app.getPath('documents'), safeName(title) + '.pdf'),
        filters: [{ name: 'PDF', extensions: ['pdf'] }]
      });
      if (!r.canceled && r.filePath) { fs.writeFileSync(r.filePath, pdf); shell.openPath(r.filePath); }
    } catch (err) {
      logErro(err);
      dialog.showErrorBox('Não foi possível gerar o PDF', String(err && err.message || err));
    } finally {
      try { if (!w.isDestroyed()) w.destroy(); } catch (x) { /* ignora */ }
      try { fs.unlinkSync(tmp); } catch (x) { /* ignora */ }
    }
  });
}

/* ---------- início ---------- */
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', function () { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.on('window-all-closed', function () { app.quit(); });
  app.whenReady().then(function () {
    session.defaultSession.setPermissionRequestHandler(function (wc, permission, cb) {
      cb(['clipboard-sanitized-write', 'clipboard-read', 'fullscreen'].indexOf(permission) > -1);
    });
    setupIpc();
    buildMenu();
    createWindow();
  });
}

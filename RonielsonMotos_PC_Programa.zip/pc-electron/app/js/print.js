/* print.js — documentos (orçamento/OS, fechamento) para imprimir/PDF e textos para WhatsApp */
(function(){
'use strict';
var RM=window.RM,esc=RM.esc,d=RM.d,money=RM.money;
var P=RM.print={};

P.css='*{box-sizing:border-box}body{font:13px/1.45 Arial,Helvetica,sans-serif;color:#111;margin:0;padding:22px}h1{font-size:19px;margin:0}h2{font-size:14px;margin:18px 0 6px;border-bottom:2px solid #d91432;padding-bottom:3px;text-transform:uppercase;letter-spacing:.5px}'
 +'.head{display:flex;justify-content:space-between;gap:16px;align-items:center;border-bottom:3px solid #d91432;padding-bottom:12px}.head img{width:74px;height:74px;border-radius:50%}.co{display:flex;gap:12px;align-items:center}.co small{display:block;color:#444}.doc{text-align:right}.doc b{font-size:18px;color:#d91432}'
 +'table{width:100%;border-collapse:collapse}th{background:#f1f1f1;text-align:left;font-size:11px;text-transform:uppercase;padding:6px 8px;border:1px solid #ccc}td{padding:6px 8px;border:1px solid #ddd}td.r,th.r{text-align:right}.grid{display:grid;grid-template-columns:1fr 1fr;gap:4px 18px}.grid div span{color:#555}'
 +'.tot td{border:0;padding:3px 8px}.tot .big td{font-size:16px;font-weight:bold;border-top:2px solid #111}.note{background:#fafafa;border:1px solid #e3e3e3;border-radius:6px;padding:8px 10px;margin-top:10px;font-size:12px}.sign{display:flex;gap:40px;margin-top:46px}.sign div{flex:1;border-top:1px solid #111;text-align:center;padding-top:4px;font-size:11px}.foot{margin-top:22px;text-align:center;color:#666;font-size:11px}';

P.doc=function(html,title){
  var b=RM.br('AndroidPrint');
  if(b&&b.printHtml){b.printHtml(html,title||'Documento');return}
  var dk=window.RMDesktop;if(dk&&dk.printHtml){dk.printHtml(html,title||'Documento');return}
  try{
    var f=document.createElement('iframe');f.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';document.body.appendChild(f);
    var w=f.contentWindow;w.document.open();w.document.write(html);w.document.close();
    setTimeout(function(){try{w.focus();w.print()}catch(e){}setTimeout(function(){try{f.parentNode.removeChild(f)}catch(e){}},3000)},350);
    return;
  }catch(e){RM.logError('impressão',e.message)}
  var w2=window.open('','_blank');
  if(w2){w2.document.write(html);w2.document.close();setTimeout(function(){try{w2.print()}catch(e){}},400)}
  else if(RM.ui)RM.ui.toast('Impressão indisponível neste ambiente.','err');
};
P.page=function(title,body){return '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>'+esc(title)+'</title><style>'+P.css+'</style></head><body>'+body+'</body></html>'};
P.header=function(titleHtml,sub){
  var c=RM.data.settings.company;
  return '<div class="head"><div class="co"><img src="'+(RM.LOGO_DATA||'')+'" alt=""><div><h1>'+esc(c.name||'Oficina')+'</h1>'+(c.doc?'<small>CNPJ/CPF: '+esc(c.doc)+'</small>':'')+(c.phone?'<small>Tel/WhatsApp: '+esc(c.phone)+'</small>':'')+(c.address?'<small>'+esc(c.address)+'</small>':'')+'</div></div><div class="doc">'+titleHtml+(sub?'<br><small>'+sub+'</small>':'')+'</div></div>';
};
P.customerOf=function(o){
  var D=RM.data;if(o.customerId)return D.customers.find(function(c){return c.id===o.customerId})||null;
  return D.customers.find(function(c){return c.name&&c.name.toLowerCase()===String(o.customer||'').toLowerCase()})||null;
};
P.isQuote=function(o){return o.status==='Orçamento'};
P.mechanicName=function(o){var m=o.mechanicId&&RM.data.mechanics.find(function(x){return x.id===o.mechanicId});return m?m.name:''};

P.orderHtml=function(o){
  var quote=P.isQuote(o),c=P.customerOf(o),kind=quote?'ORÇAMENTO':'ORDEM DE SERVIÇO',today=RM.today();
  var rows=(o.items||[]).map(function(i){return '<tr><td>'+esc(i.name)+'</td><td class="r">'+RM.num(i.qty)+'</td><td class="r">'+money(i.price)+'</td><td class="r">'+money(RM.num(i.qty)*RM.num(i.price))+'</td></tr>'}).join('');
  if(!rows&&RM.num(o.partsCost)>0)rows='<tr><td>Peças (valor lançado)</td><td class="r">1</td><td class="r">'+money(o.partsCost)+'</td><td class="r">'+money(o.partsCost)+'</td></tr>';
  if(!rows)rows='<tr><td colspan="4" style="color:#777">Nenhuma peça lançada</td></tr>';
  var total=d.orderTotal(o),paid=d.paid(o),bal=d.balance(o),w=d.warrantyUntil(o),extra='';
  if(quote)extra+='<div class="note">Orçamento válido por <b>7 dias</b> a partir de '+RM.dateBR(o.created)+'. Valores sujeitos a alteração se houver necessidade de outras peças ou serviços.</div>';
  if(RM.num(o.warrantyDays)>0)extra+='<div class="note"><b>Garantia:</b> '+RM.num(o.warrantyDays)+' dias a partir da entrega'+(w?' (até '+RM.dateBR(w)+')':'')+'. A garantia cobre defeitos do serviço/peça instalada e não cobre mau uso, quedas ou desgaste normal.</div>';
  if(o.nextDate)extra+='<div class="note"><b>Próxima revisão sugerida:</b> '+RM.dateBR(o.nextDate)+(o.nextKm?' ou aos '+RM.num(o.nextKm)+' km':'')+'.</div>';
  if(o.notes)extra+='<div class="note"><b>Observações:</b> '+esc(o.notes)+'</div>';
  var body=P.header('<b>'+kind+' Nº '+esc(o.number)+'</b>','Data: '+RM.dateBR(o.created)+(quote?'':' • Situação: '+esc(o.status)))
   +'<h2>Cliente e moto</h2><div class="grid"><div><span>Cliente:</span> <b>'+esc(o.customer||'—')+'</b></div><div><span>Telefone:</span> '+esc((c&&c.phone)||'—')+'</div><div><span>Moto:</span> '+esc(o.bike||(c&&c.bike)||'—')+'</div><div><span>Placa:</span> '+esc(o.plate||(c&&c.plate)||'—')+'</div><div><span>Km:</span> '+(o.km!==''&&o.km!=null?RM.num(o.km):'—')+'</div><div><span>Mecânico:</span> '+esc(P.mechanicName(o)||'—')+'</div></div>'
   +'<h2>Serviço / defeito relatado</h2><div>'+esc(o.problem||'—')+'</div>'
   +'<h2>Peças</h2><table><thead><tr><th>Descrição</th><th class="r">Qtd</th><th class="r">Unit.</th><th class="r">Total</th></tr></thead><tbody>'+rows+'</tbody></table>'
   +'<table class="tot" style="margin-top:8px"><tr><td class="r">Peças:</td><td class="r" style="width:120px">'+money(d.itemsTotal(o))+'</td></tr><tr><td class="r">Mão de obra:</td><td class="r">'+money(o.labor)+'</td></tr>'
   +(RM.num(o.discount)>0?'<tr><td class="r">Desconto:</td><td class="r">− '+money(o.discount)+'</td></tr>':'')
   +'<tr class="big"><td class="r">TOTAL:</td><td class="r">'+money(total)+'</td></tr>'
   +(!quote&&!o.balanceExempt?'<tr><td class="r">Pago:</td><td class="r">'+money(paid)+'</td></tr><tr><td class="r"><b>Saldo a pagar:</b></td><td class="r"><b>'+money(bal)+'</b></td></tr>':'')
   +'</table>'+extra
   +'<div class="sign"><div>Cliente</div><div>'+esc(RM.data.settings.company.name||'Oficina')+'</div></div><div class="foot">Documento gerado em '+RM.dateBR(today)+' • '+esc(RM.data.settings.company.name||'')+'</div>';
  return P.page(kind+' '+o.number,body);
};
P.printOrder=function(o){P.doc(P.orderHtml(o),(P.isQuote(o)?'Orcamento-':'OS-')+o.number)};

P.closingHtml=function(c){
  function rows(m){var k=Object.keys(m||{});return k.length?k.map(function(x){return '<tr><td>'+esc(x)+'</td><td class="r">'+money(m[x])+'</td></tr>'}).join(''):'<tr><td colspan="2" style="color:#777">—</td></tr>'}
  var body=P.header('<b>FECHAMENTO DE CAIXA</b>','Data: '+RM.dateBR(c.date))
   +'<h2>Entradas por forma de pagamento</h2><table><tbody>'+rows(c.byIn)+'</tbody></table><h2>Saídas por forma de pagamento</h2><table><tbody>'+rows(c.byOut)+'</tbody></table>'
   +'<h2>Resumo</h2><table class="tot"><tr><td class="r">Total de entradas:</td><td class="r" style="width:130px">'+money(c.in)+'</td></tr><tr><td class="r">Total de saídas:</td><td class="r">'+money(c.out)+'</td></tr><tr class="big"><td class="r">Saldo do dia:</td><td class="r">'+money(c.in-c.out)+'</td></tr></table>'
   +'<h2>Conferência do dinheiro</h2><table class="tot"><tr><td class="r">Troco inicial:</td><td class="r" style="width:130px">'+money(c.opening)+'</td></tr><tr><td class="r">Esperado em caixa:</td><td class="r">'+money(c.expected)+'</td></tr><tr><td class="r">Contado:</td><td class="r">'+money(c.counted)+'</td></tr><tr class="big"><td class="r">Diferença:</td><td class="r">'+money(c.diff)+'</td></tr></table>'
   +(c.note?'<div class="note"><b>Obs.:</b> '+esc(c.note)+'</div>':'')+'<div class="sign"><div>Responsável</div><div>Dono</div></div>';
  return P.page('Fechamento '+c.date,body);
};

/* ---------- textos para WhatsApp ---------- */
P.orderText=function(o){
  var co=RM.data.settings.company.name||'Oficina',quote=P.isQuote(o);
  var L=[(quote?'*ORÇAMENTO*':'*ORDEM DE SERVIÇO*')+' nº '+o.number+' — '+co,'Cliente: '+(o.customer||'—'),'Moto: '+(o.bike||'—')+(o.plate?' ('+o.plate+')':'')];
  if(o.problem)L.push('Serviço: '+o.problem);
  L.push('');(o.items||[]).forEach(function(i){L.push('• '+i.name+' — '+RM.num(i.qty)+' x '+money(i.price))});
  if(RM.num(o.labor)>0)L.push('• Mão de obra — '+money(o.labor));
  if(RM.num(o.discount)>0)L.push('Desconto: − '+money(o.discount));
  L.push('*TOTAL: '+money(d.orderTotal(o))+'*');
  if(!quote&&!o.balanceExempt&&d.balance(o)>0)L.push('Saldo a pagar: '+money(d.balance(o)));
  if(quote)L.push('','Orçamento válido por 7 dias. Responda "OK" para aprovar. 🏍️');
  else if(RM.num(o.warrantyDays)>0)L.push('','Garantia de '+RM.num(o.warrantyDays)+' dias.');
  return L.join('\n');
};
P.chargeText=function(debtor){
  var co=RM.data.settings.company.name||'Oficina',L=['Olá '+String(debtor.name||'').split(' ')[0]+'! Aqui é da '+co+'. Passando para lembrar do valor em aberto:',''];
  debtor.items.forEach(function(i){L.push('• '+i.label+': '+money(i.balance))});
  L.push('','*Total: '+money(debtor.total)+'*');
  var cfg=RM.CONFIG||{};if(cfg.pixKey)L.push('Pix: '+cfg.pixKey);
  L.push('Qualquer dúvida é só chamar. Obrigado! 🙏');return L.join('\n');
};
P.pickText=function(o){
  var L=['*Separar peças — OS #'+o.number+'*',(o.customer||'')+(o.bike?' · '+String(o.bike).replace(/ — .*$/,''):'')+(o.plate?' · '+o.plate:''),''];
  d.pickingList(RM.data,o).forEach(function(g){L.push((g.key==='~avulso'?'🧰 ':'📍 ')+g.name);g.items.forEach(function(i){L.push('   ☐ '+i.name+' × '+i.qty+(i.sku?' ['+i.sku+']':''))});L.push('')});
  return L.join('\n').trim();
};
P.pickHtml=function(o){
  var groups=d.pickingList(RM.data,o).map(function(g){return '<h2>'+(g.key==='~avulso'?'🧰 ':'📍 ')+esc(g.name)+'</h2><table><tbody>'+g.items.map(function(i){return '<tr><td style="width:28px">☐</td><td><b>'+esc(i.name)+'</b>'+(i.sku?'<br><small>Código '+esc(i.sku)+'</small>':'')+'</td><td class="r" style="width:70px"><b>× '+i.qty+'</b></td></tr>'}).join('')+'</tbody></table>'}).join('')||'<p>Esta ordem não tem peças.</p>';
  return P.page('Separação '+o.number,P.header('<b>SEPARAÇÃO DE PEÇAS</b>','OS nº '+esc(o.number)+' • '+RM.dateBR(o.created))+'<div class="grid" style="margin-top:12px"><div><span>Cliente:</span> <b>'+esc(o.customer||'—')+'</b></div><div><span>Moto:</span> '+esc(String(o.bike||'—').replace(/ — .*$/,''))+(o.plate?' · '+esc(o.plate):'')+'</div></div>'+groups+'<div class="foot">Lista interna — não entregar ao cliente</div>');
};
P.restockText=function(list){
  var co=RM.data.settings.company.name||'Oficina',L=['*Lista de reposição — '+co+'* ('+RM.dateBR(RM.today())+')',''];
  list.forEach(function(x){L.push('• '+x.part.name+(x.part.sku?' ['+x.part.sku+']':'')+(x.part.location?' 📍'+x.part.location:'')+' — estoque '+RM.num(x.part.qty)+' / mín. '+RM.num(x.part.min)+' → comprar ~'+x.suggest)});
  return L.join('\n');
};
})();

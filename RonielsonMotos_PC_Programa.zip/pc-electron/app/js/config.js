/* ============================================================
   CONFIGURAÇÕES DO ADMINISTRADOR  (edite aqui e gere o APK de novo)
   ============================================================ */
window.RM = window.RM || {};
RM.CONFIG = {
  companyName: 'Ronielson Motos',

  /* Assinatura / tela de bloqueio */
  adminWhatsapp: 'JRS Emplementos',   // Vazio = esconde o botão
  pixKey: '+5583987549152',          // Vazio = esconde o botão "Pagar via Pix"
  pixName: 'José Robenilson',       
  valor: 'R$ 35,00/mês',           
  /* Aviso de atualização (opcional). Aponte para um arquivo version.json público, ex.:
     {"version":"0.9","url":"https://github.com/SEU-USUARIO/SEU-REPO/releases","notes":"Novidades..."}
     Vazio = não verifica. */
  versionUrl: ''
};

/* ui.js — navegação, modais, formulários, avisos, modo dono/funcionário (PIN) */
(function(){
'use strict';
var RM=window.RM,esc=RM.esc,$=RM.$;
var ui=RM.ui={mode:'owner',page:'dashboard',tab:{finance:'cash',team:'comm'},q:{},stack:[],pinFails:0,pinLockUntil:0,hiddenAt:0};
RM.act={};RM.pages={};

ui.can=function(perm){return RM.d.can(ui.mode,perm)};
ui.isOwner=function(){return ui.mode==='owner'};

/* ---------- aviso rápido ---------- */
ui.toast=function(msg,kind){var el=$('toast');if(!el)return;el.textContent=msg;el.className='toast show '+(kind||'');clearTimeout(ui._tt);ui._tt=setTimeout(function(){el.className='toast'},kind==='err'?5200:2600)};

/* ---------- componentes de texto/HTML ---------- */
ui.pill=function(t,c){return '<span class="pill '+(c||'')+'">'+esc(t)+'</span>'};
ui.statusPill=function(s){var c={'Orçamento':'blue','Aprovada':'blue','Aberta':'red','Em andamento':'blue','Aguardando peça':'yellow','Concluída':'green','Entregue':'green','Cancelada':'gray'}[s]||'';return ui.pill(s,c)};
ui.stat=function(label,value,note,cls,icon){return '<div class="stat"><div class="stathead">'+esc(label)+(icon?' <span class="staticon">'+icon+'</span>':'')+'</div><div class="statvalue '+(cls||'')+'">'+value+'</div>'+(note?'<div class="statnote">'+esc(note)+'</div>':'')+'</div>'};
ui.empty=function(title,msg){return '<div class="empty"><b>'+esc(title)+'</b>'+esc(msg||'')+'</div>'};
ui.tabs=function(name,items){return '<div class="tabs">'+items.map(function(t){return '<button type="button" class="tab'+(ui.tab[name]===t[0]?' active':'')+'" data-act="ui.tab" data-name="'+name+'" data-key="'+t[0]+'">'+esc(t[1])+'</button>'}).join('')+'</div>'};
RM.act['ui.tab']=function(ds){ui.tab[ds.name]=ds.key;ui.render(true)};

/* ---------- campos de formulário ---------- */
ui.field=function(f){
  var req=f.required===false?'':' required',val=f.value==null?'':f.value,n=esc(f.name),ctl;
  if(f.type==='select'){ctl='<select name="'+n+'"'+req+(f.attrs?' '+f.attrs:'')+'>'+(f.options||[]).map(function(o){return '<option value="'+esc(o[0])+'"'+(String(o[0])===String(val)?' selected':'')+'>'+esc(o[1])+'</option>'}).join('')+'</select>'}
  else if(f.type==='textarea'){ctl='<textarea name="'+n+'" rows="'+(f.rows||3)+'"'+req+(f.placeholder?' placeholder="'+esc(f.placeholder)+'"':'')+(f.attrs?' '+f.attrs:'')+'>'+esc(val)+'</textarea>'}
  else{var t=f.type||'text',extra='';if(t==='number')extra=' inputmode="decimal" step="'+(f.step||'any')+'"'+(f.min!==undefined?' min="'+f.min+'"':'');
    ctl='<input name="'+n+'" type="'+t+'" value="'+esc(val)+'"'+extra+req+(f.placeholder?' placeholder="'+esc(f.placeholder)+'"':'')+(f.maxlength?' maxlength="'+f.maxlength+'"':'')+(f.attrs?' '+f.attrs:'')+' autocomplete="off">'}
  return '<div class="field'+(f.full?' full':'')+'"><label>'+esc(f.label)+'</label>'+ctl+(f.hint?'<small class="hint">'+esc(f.hint)+'</small>':'')+'</div>';
};
ui.fields=function(list){return '<div class="formgrid">'+list.map(ui.field).join('')+'</div>'};

/* ---------- modais (pilha) ---------- */
ui.open=function(def){ui.stack.push(def);ui.paint(false)};
ui.close=function(){var def=ui.stack.pop();if(def&&def.onClose)def.onClose();ui.paint(false)};
ui.closeAll=function(){while(ui.stack.length){var def=ui.stack.pop();if(def&&def.onClose)def.onClose()}ui.paint(false)};
ui.top=function(){return ui.stack[ui.stack.length-1]};
ui.paint=function(keepScroll){
  var back=$('modalback'),box=$('modalbox');if(!back||!box)return;
  var def=ui.top();
  if(!def){back.classList.remove('show');box.innerHTML='';return}
  var sc=keepScroll?box.scrollTop:0;
  var body=def.render?def.render():'';
  var actions=def.actions?def.actions():(def.onSubmit?'<button type="button" class="btn" data-act="ui.close">'+esc(def.cancelLabel||'Cancelar')+'</button><button type="submit" class="btn primary">'+esc(def.submitLabel||'Salvar')+'</button>':'<button type="button" class="btn" data-act="ui.close">Fechar</button>');
  var inner=body+'<div class="modalactions">'+actions+'</div>';
  var title=typeof def.title==='function'?def.title():def.title;
  box.innerHTML='<h2>'+esc(title||'')+'</h2>'+(def.onSubmit?'<form id="mform">'+inner+'</form>':inner);
  back.classList[def.center?'add':'remove']('center');
  back.classList.add('show');box.scrollTop=sc;
  if(!keepScroll&&box.querySelector){var af=box.querySelector('[autofocus]');if(af&&af.focus)try{af.focus()}catch(e){}}
  if(def.onMount)def.onMount(box);
};
ui.refresh=function(){if(ui.top())ui.paint(true)};
ui.confirm=function(msg,onYes,o){o=o||{};ui.open({center:true,title:o.title||'Confirmar',render:function(){return '<p class="msg">'+esc(msg).replace(/\n/g,'<br>')+'</p>'},
  actions:function(){return '<button type="button" class="btn" data-act="ui.close">Cancelar</button><button type="button" class="btn '+(o.danger?'danger':'primary')+'" data-act="ui.confirmYes">'+esc(o.okLabel||'Confirmar')+'</button>'},_yes:onYes})};
ui.alert=function(msg,title){ui.open({center:true,title:title||'Aviso',render:function(){return '<p class="msg">'+esc(msg).replace(/\n/g,'<br>')+'</p>'}})};
RM.act['ui.close']=function(){ui.close()};
RM.act['ui.confirmYes']=function(){var def=ui.top();ui.close();if(def&&def._yes)def._yes()};

/* ---------- eventos globais (delegação) ---------- */
document.addEventListener('click',function(e){
  var back=$('modalback');
  if(e.target===back){var d=ui.top();if(d&&!d.onSubmit)ui.close();return}
  var el=e.target&&e.target.closest?e.target.closest('[data-act]'):null;if(!el)return;
  var fn=RM.act[el.getAttribute('data-act')];if(!fn)return;
  e.preventDefault();
  try{fn(el.dataset,el,e)}catch(err){RM.logError('acao',err&&err.message,el.getAttribute('data-act'));ui.toast('Algo deu errado. Veja Ajustes › Relatório de erros.','err')}
});
document.addEventListener('submit',function(e){
  if(!e.target||e.target.id!=='mform')return;e.preventDefault();
  var def=ui.top();if(!def||!def.onSubmit)return;
  var vals={};new FormData(e.target).forEach(function(v,k){vals[k]=v});
  try{if(def.onSubmit(vals,e.target)!==false)ui.close()}catch(err){RM.logError('form',err&&err.message);ui.toast('Não foi possível salvar: '+(err&&err.message),'err')}
});
document.addEventListener('input',function(e){
  var el=e.target;if(!el||!el.getAttribute)return;
  var s=el.getAttribute('data-search');if(s){ui.q[s]=el.value;ui.renderList(s);return}
  var b=el.getAttribute('data-bind');var def=ui.top();if(b&&def&&def.onBind)def.onBind(b,el.value,el);
});
document.addEventListener('change',function(e){var el=e.target;if(!el||!el.getAttribute)return;var b=el.getAttribute('data-bind'),def=ui.top();if(b&&def&&def.onBind)def.onBind(b,el.value,el,true)});
document.addEventListener('visibilitychange',function(){
  if(document.hidden){ui.hiddenAt=Date.now();return}
  if(ui.isOwner()&&RM.d.pinHas(RM.data)&&ui.hiddenAt&&Date.now()-ui.hiddenAt>2*60*1000){ui.lock(true)}
});

/* ---------- páginas e navegação ---------- */
ui.pages=function(){return ui.isOwner()?RM.d.OWNER_PAGES:RM.d.STAFF_PAGES};
ui.go=function(page){if(ui.pages().indexOf(page)<0)page='dashboard';ui.page=page;ui.render(false);if(window.scrollTo)window.scrollTo(0,0)};
RM.act['go']=function(ds){ui.go(ds.page)};
ui.badge=function(p){
  var n=0;try{
    if(p==='reminders')n=RM.d.reminders(RM.data,RM.today(),RM.data.settings.reminderWindow).filter(function(x){return !x.sent}).length;
    if(p==='inventory')n=RM.d.lowParts(RM.data).length;
    if(p==='finance'&&ui.isOwner())n=RM.d.payablesPending(RM.data).filter(function(x){return x.due<=RM.today()}).length;
  }catch(e){}
  return n?'<span class="navbadge">'+n+'</span>':'';
};
ui.renderNav=function(){
  var nav=$('nav');if(!nav)return;
  nav.innerHTML=ui.pages().map(function(p){var pg=RM.pages[p];if(!pg)return '';return '<button type="button" class="'+(ui.page===p?'active':'')+'" data-act="go" data-page="'+p+'"><span class="navicon">'+pg.icon+'</span>'+esc(pg.label)+ui.badge(p)+'</button>'}).join('');
};
ui.renderChrome=function(){
  var b=$('modeBtn');if(!b)return;var has=RM.d.pinHas(RM.data);
  if(!has){b.style.display='none'}else{b.style.display='';b.textContent=ui.isOwner()?'🔓 Dono':'🔒 Funcionário';b.setAttribute('data-act',ui.isOwner()?'ui.lock':'ui.unlock')}
  var tb=$('topBackup');if(tb)tb.style.display=ui.isOwner()?'':'none';
  var t=$('modeNote');if(t)t.innerHTML=has?(ui.isOwner()?'<b style="color:#e2e8f0">Modo dono</b><br>Acesso total.':'<b style="color:#e2e8f0">Modo funcionário</b><br>Caixa, preços e ajustes protegidos.'):'<b style="color:#e2e8f0">Modo local</b><br>Defina um PIN em Ajustes para proteger o caixa.';
};
ui.render=function(keep){
  var pg=RM.pages[ui.page];if(!pg){return}
  if(ui.pages().indexOf(ui.page)<0)ui.page='dashboard',pg=RM.pages.dashboard;
  var y=keep&&window.pageYOffset?window.pageYOffset:0;
  $('view').innerHTML=pg.render();
  if(pg.after)pg.after();
  $('pageTitle').textContent=pg.title;
  ui.renderNav();ui.renderChrome();
  if(keep&&window.scrollTo)window.scrollTo(0,y);
  if(ui.checkTerms&&!ui.stack.length)ui.checkTerms();
};
ui.renderList=function(name){var pg=RM.pages[name],el=$('list-'+name);if(pg&&pg.list&&el)el.innerHTML=pg.list();else ui.render(true)};
ui.searchBox=function(name,placeholder){return '<input class="search" data-search="'+name+'" value="'+esc(ui.q[name]||'')+'" placeholder="'+esc(placeholder)+'" autocomplete="off">'};

/* ---------- modo dono / funcionário ---------- */
ui.lock=function(silent){
  if(!RM.d.pinHas(RM.data))return;
  ui.mode='staff';ui.closeAll();if(ui.pages().indexOf(ui.page)<0)ui.page='dashboard';ui.render(false);
  if(!silent)ui.toast('Modo funcionário ativado.');
};
RM.act['ui.lock']=function(){ui.lock(false)};
ui.unlock=function(then){
  if(ui.isOwner()){if(then)then();return}
  ui.open({title:'Entrar como dono',submitLabel:'Entrar',
    render:function(){var left=Math.ceil((ui.pinLockUntil-Date.now())/1000);return '<p class="muted">Digite o PIN do dono.</p>'+(left>0?'<p class="msg err">Muitas tentativas. Aguarde '+left+'s.</p>':'')+ui.fields([{name:'pin',label:'PIN',type:'password',full:true,maxlength:8,attrs:'inputmode="numeric" autofocus'}])+'<p class="small"><a href="#" data-act="ui.forgotPin">Esqueci o PIN</a></p>'},
    onSubmit:function(v){
      if(Date.now()<ui.pinLockUntil){ui.refresh();return false}
      if(RM.d.pinCheck(RM.data,String(v.pin||''))){ui.pinFails=0;ui.mode='owner';ui.stack.length=0;ui.paint(false);ui.render(false);ui.toast('Modo dono ativado.');if(then)then();return false}
      ui.pinFails++;if(ui.pinFails>=5){ui.pinLockUntil=Date.now()+30000;ui.pinFails=0}
      ui.toast('PIN incorreto.','err');return false;
    }});
};
RM.act['ui.unlock']=function(){ui.unlock()};
RM.act['ui.forgotPin']=function(){
  ui.open({title:'Recuperar PIN',submitLabel:'Validar código',
    render:function(){return '<p class="muted">Peça ao administrador um <b>código de recuperação de PIN</b> para este aparelho (informe o ID abaixo) e cole aqui.</p><p><b>ID do aparelho:</b> <span class="mono">'+esc(ui.deviceId())+'</span></p>'+ui.fields([{name:'code',label:'Código de recuperação',type:'textarea',rows:3,full:true}])},
    onSubmit:function(v){
      var b=RM.br('AndroidLicense'),ok=false;try{ok=!!(b&&b.verifyPinReset&&b.verifyPinReset(String(v.code||'')))}catch(e){}
      if(!ok){ui.toast('Código inválido ou vencido.','err');return false}
      RM.d.pinClear(RM.data);RM.persist();ui.mode='owner';ui.stack.length=0;ui.paint(false);ui.render(false);ui.toast('PIN removido. Defina um novo em Ajustes.');return false;
    }});
};
ui.deviceId=function(){try{var b=RM.br('AndroidLicense');return b&&b.getDeviceId?b.getDeviceId():'—'}catch(e){return '—'}};

/* quando os dados mudam: redesenha a tela (e o modal, se for do tipo "live") */
RM.onChange(function(){ui.render(true);var t=ui.top();if(t&&t.live)ui.refresh()});
})();

/* ---------- leitor de código de barras (ponte nativa) e constantes ---------- */
(function(){
var RM=window.RM,ui=RM.ui;
ui.METHODS=[['Pix','Pix'],['Dinheiro','Dinheiro'],['Cartão de débito','Cartão de débito'],['Cartão de crédito','Cartão de crédito'],['Transferência','Transferência'],['Outro','Outro']];
RM.scanCb=null;
RM.scan=function(cb,opts){
  var b=RM.br('AndroidScanner');
  if(!b||!b.scan){
    if(opts&&opts.prompt){ui.open({center:true,title:'Ler código de barras',submitLabel:'OK',
      render:function(){return '<p class="muted small">Passe o código no leitor USB (ele digita e dá Enter) ou digite o código.</p>'+ui.fields([{name:'code',label:'Código',full:true,attrs:'autofocus'}])},
      onSubmit:function(v){var c=String(v.code||'').trim();if(c)cb(c)}});return}
    ui.toast('O leitor de câmera funciona no aplicativo Android. Digite o código.','err');return}
  RM.scanCb=cb;try{b.scan('x')}catch(e){RM.scanCb=null;ui.toast('Não foi possível iniciar o leitor.','err')}
};
window.onNativeBarcodeScanned=function(v){var cb=RM.scanCb;RM.scanCb=null;if(cb)cb(v)};
window.onNativeBarcodeCancelled=function(){RM.scanCb=null};
})();

/* download de arquivo (navegador/PC) */
RM.download=function(filename,text,mime){
  var blob=new Blob([text],{type:mime||'text/plain'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.parentNode.removeChild(a);setTimeout(function(){URL.revokeObjectURL(url)},1500);
};

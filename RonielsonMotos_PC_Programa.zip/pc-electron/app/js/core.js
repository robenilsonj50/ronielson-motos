/* core.js — utilitários, estado (localStorage, MESMA chave do app original), migração e registro de erros */
(function(){
'use strict';
var RM=window.RM=window.RM||{};
RM.VERSION='0.9';
RM.KEY='oficinaOS_v01';           // chave de armazenamento: inalterada (compatível com backups e dados antigos)
RM.ERR_KEY='oficinaOS_errors';    // registro pequeno de erros (diagnóstico)
RM.SCHEMA=2;
RM.EDITION=(typeof document!=='undefined'&&document.body&&String(document.body.className).indexOf('pc')>-1)?'pc':'mobile';

/* ---------- utilitários ---------- */
RM.$=function(id){return document.getElementById(id)};
RM.esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
RM.num=function(v){if(typeof v==='number')return isFinite(v)?v:0;var n=Number(String(v==null?'':v).replace(/\./g,function(m,i,s){return s.indexOf(',')>-1?'':m}).replace(',','.'));return isFinite(n)?n:0};
RM.r2=function(x){return Math.round((x+Number.EPSILON)*100)/100};
RM.money=function(n){return Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})};
RM.uid=function(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)};
RM.localISO=function(d){d=d||new Date();var p=function(n){return String(n).padStart(2,'0')};return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())};
RM.today=function(){return RM.localISO()};
RM.parseISO=function(s){var a=String(s).split('-').map(Number);return new Date(a[0],(a[1]||1)-1,a[2]||1,12,0,0)};
RM.addDays=function(s,n){var d=RM.parseISO(s);d.setDate(d.getDate()+n);return RM.localISO(d)};
RM.addMonths=function(s,n){var d=RM.parseISO(s),day=d.getDate();d.setDate(1);d.setMonth(d.getMonth()+n);var last=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(day,last));return RM.localISO(d)};
RM.daysBetween=function(a,b){return Math.round((RM.parseISO(b)-RM.parseISO(a))/86400000)};
RM.dateBR=function(s){return s?RM.parseISO(s).toLocaleDateString('pt-BR'):'—'};
RM.monthStart=function(s){return s.slice(0,8)+'01'};
RM.monthEnd=function(s){var d=RM.parseISO(s);return RM.localISO(new Date(d.getFullYear(),d.getMonth()+1,0,12))};
RM.phoneDigits=function(p){return String(p||'').replace(/\D/g,'')};
RM.waLink=function(phone,text){var n=RM.phoneDigits(phone);if(n&&n.length<=11)n='55'+n;return 'https://wa.me/'+n+'?text='+encodeURIComponent(text||'')};
RM.br=function(name){return window[name]||null};
RM.open=function(url){var dk=window.RMDesktop;if(dk&&dk.openExternal){dk.openExternal(url);return}var b=RM.br('AndroidLicense');if(b&&b.openExternal){b.openExternal(url);return}window.open(url,'_blank')};
RM.copy=function(text){var dk=window.RMDesktop;if(dk&&dk.copy){dk.copy(text);return true}var b=RM.br('AndroidLicense');if(b&&b.copyText){b.copyText(text);return true}try{navigator.clipboard.writeText(text);return true}catch(e){return false}};

/* SHA-256 (usado só para guardar o PIN sem texto puro) */
RM.sha256=function(msg){
  var bytes=[],u=unescape(encodeURIComponent(msg)),i,o;for(i=0;i<u.length;i++)bytes.push(u.charCodeAt(i));
  var K=new Uint32Array([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
  var H=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
  var l=bytes.length;bytes.push(0x80);while(bytes.length%64!==56)bytes.push(0);
  var hi=Math.floor(l*8/0x100000000),lo=(l*8)>>>0;
  for(i=3;i>=0;i--)bytes.push((hi>>>(i*8))&255);for(i=3;i>=0;i--)bytes.push((lo>>>(i*8))&255);
  var w=new Uint32Array(64),rotr=function(x,n){return (x>>>n)|(x<<(32-n))};
  for(o=0;o<bytes.length;o+=64){
    for(i=0;i<16;i++)w[i]=(bytes[o+4*i]<<24)|(bytes[o+4*i+1]<<16)|(bytes[o+4*i+2]<<8)|bytes[o+4*i+3];
    for(i=16;i<64;i++){var s0=rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>>3),s1=rotr(w[i-2],17)^rotr(w[i-2],19)^(w[i-2]>>>10);w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0}
    var a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
    for(i=0;i<64;i++){var S1=rotr(e,6)^rotr(e,11)^rotr(e,25),ch=(e&f)^(~e&g),t1=(h+S1+ch+K[i]+w[i])>>>0,S0=rotr(a,2)^rotr(a,13)^rotr(a,22),mj=(a&b)^(a&c)^(b&c),t2=(S0+mj)>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0}
    H[0]+=a;H[1]+=b;H[2]+=c;H[3]+=d;H[4]+=e;H[5]+=f;H[6]+=g;H[7]+=h;
  }
  return Array.prototype.map.call(H,function(x){return x.toString(16).padStart(8,'0')}).join('');
};

/* ---------- registro de erros ---------- */
RM.getErrors=function(){try{return JSON.parse(localStorage.getItem(RM.ERR_KEY)||'[]')}catch(e){return []}};
RM.clearErrors=function(){try{localStorage.removeItem(RM.ERR_KEY)}catch(e){}};
RM.logError=function(kind,msg,src){try{var arr=RM.getErrors();arr.unshift({at:new Date().toISOString(),kind:kind,msg:String(msg==null?'':msg).slice(0,300),src:String(src||'').slice(0,160)});localStorage.setItem(RM.ERR_KEY,JSON.stringify(arr.slice(0,30)))}catch(e){}};
if(window.addEventListener){
  window.addEventListener('error',function(e){RM.logError('erro',e.message,String(e.filename||'').split('/').pop()+':'+e.lineno)});
  window.addEventListener('unhandledrejection',function(e){RM.logError('promessa',e.reason&&e.reason.message||e.reason)});
}

/* ---------- dados ---------- */
RM.DEFAULT_REMINDER='Olá {nome}! Aqui é da {oficina}. A revisão da sua {moto} ({placa}) está prevista para {data}. Vamos agendar? 🏍️';
RM.defaults=function(){return {
  orders:[],parts:[],cash:[],customers:[],
  mechanics:[],payables:[],receivables:[],closings:[],
  settings:{company:{name:(RM.CONFIG&&RM.CONFIG.companyName)||'Ronielson Motos',phone:'',address:'',doc:''},
    warrantyDays:30,reminderMonths:6,reminderWindow:15,reminderTemplate:RM.DEFAULT_REMINDER,
    pinHash:'',pinSalt:'',termsAccepted:null,lastBackupAt:'',seq:1},
  meta:{schema:RM.SCHEMA}
}};

/* Migração aditiva: aceita dados/backup antigos (4 listas) e completa o que falta, sem apagar nada. */
RM.migrate=function(raw){
  var base=RM.defaults(),d=Object.assign({},base,(raw&&typeof raw==='object')?raw:{});
  ['orders','parts','cash','customers','mechanics','payables','receivables','closings'].forEach(function(k){if(!Array.isArray(d[k]))d[k]=[]});
  d.settings=Object.assign({},base.settings,d.settings||{});
  d.settings.company=Object.assign({},base.settings.company,d.settings.company||{});
  d.meta=Object.assign({},d.meta||{},{schema:RM.SCHEMA});
  d.customers.forEach(function(c){if(!c.id)c.id=RM.uid();c.name=c.name||'';c.km=c.km===''||c.km==null?'':RM.num(c.km)});
  d.parts.forEach(function(p){if(!p.id)p.id=RM.uid();p.qty=RM.num(p.qty);p.min=RM.num(p.min);p.cost=RM.num(p.cost);p.price=RM.num(p.price);p.location=String(p.location==null?'':p.location).replace(/\s+/g,' ').trim().slice(0,40)});
  d.cash.forEach(function(x){if(!x.id)x.id=RM.uid();x.amount=RM.num(x.amount);if(!x.category)x.category=x.type==='Saída'?'Despesa':'Serviço'});
  d.mechanics.forEach(function(m){if(!m.id)m.id=RM.uid();m.commission=RM.num(m.commission)});
  d.orders.forEach(function(o){
    if(!o.id)o.id=RM.uid();
    if(!Array.isArray(o.items))o.items=[];
    if(!Array.isArray(o.photos))o.photos=[];
    if(!Array.isArray(o.history))o.history=[];
    if(!Array.isArray(o.payments)){o.payments=[];if(o.balanceExempt===undefined)o.balanceExempt=true} // ordens antigas: sem controle de saldo
    o.labor=RM.num(o.labor);o.discount=RM.num(o.discount);
    o.partsCost=o.items.length?RM.r2(o.items.reduce(function(a,i){return a+RM.num(i.qty)*RM.num(i.price)},0)):RM.num(o.partsCost);
    o.total=Math.max(0,RM.r2(o.labor+o.partsCost-o.discount));
    if(!o.created)o.created=RM.today();
  });
  var max=d.settings.seq||1;d.settings.seq=Math.max(1,RM.num(max));
  return d;
};

RM.data=null;
RM.load=function(){
  var raw=null,s=null;
  try{s=localStorage.getItem(RM.KEY);if(s)raw=JSON.parse(s)}catch(e){
    RM.logError('load',e.message);
    try{localStorage.setItem(RM.KEY+'_corrompido',s)}catch(x){} // guarda cópia antes de qualquer regravação
  }
  RM.data=RM.migrate(raw);return RM.data;
};
RM.save=function(){
  try{localStorage.setItem(RM.KEY,JSON.stringify(RM.data));return true}
  catch(e){RM.logError('save',e.message);if(RM.ui&&RM.ui.toast)RM.ui.toast('Não foi possível salvar os dados (armazenamento cheio?).','err');return false}
};
RM.listeners=[];
RM.persist=function(){var ok=RM.save();RM.listeners.forEach(function(f){try{f()}catch(e){RM.logError('render',e.message)}});return ok};
RM.onChange=function(f){RM.listeners.push(f)};
})();

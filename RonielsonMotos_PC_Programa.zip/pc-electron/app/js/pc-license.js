/* pc-license.js — licença na versão para COMPUTADOR: teste de 30 dias + código assinado.
   A assinatura (ECDSA P-256 / SHA-256) é verificada em JavaScript puro, com a mesma chave pública do app do celular.
   Oferece a mesma interface "AndroidLicense" que o app usa, então telas e regras são as mesmas. */
(function(){
'use strict';
var RM=window.RM;
var PUB_B64='MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEuk3CaRa4Lk+E+ZldMilV2mi7+KjTFEQUzHLWSDBQAtoJoP82F60xYj4GrQ8GSjDc8AdmHWmkmi77hMYuWWi0VA==';
var KEY='oficinaOS_pc_lic',DAY=86400000,TRIAL_MS=30*DAY,TRIAL_DAYS=30;

/* ---------- ECDSA P-256 (BigInt) ---------- */
var P=0xffffffff00000001000000000000000000000000ffffffffffffffffffffffffn;
var N=0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551n;
var GX=0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296n,GY=0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5n;
function mod(a,m){var r=a%m;return r>=0n?r:r+m}
function inv(a,m){
  var lm=1n,hm=0n,low=mod(a,m),high=m,r,nm,nw;
  while(low>1n){r=high/low;nm=hm-lm*r;nw=high-low*r;hm=lm;high=low;lm=nm;low=nw}
  return mod(lm,m);
}
function add(p,q){
  if(!p)return q;if(!q)return p;
  var x1=p[0],y1=p[1],x2=q[0],y2=q[1],l,x3;
  if(x1===x2){
    if(mod(y1+y2,P)===0n)return null;
    l=mod((3n*x1*x1-3n)*inv(2n*y1,P),P);
  }else l=mod((y2-y1)*inv(x2-x1,P),P);
  x3=mod(l*l-x1-x2,P);return [x3,mod(l*(x1-x3)-y1,P)];
}
function mul(k,p){var r=null,a=p;while(k>0n){if(k&1n)r=add(r,a);a=add(a,a);k>>=1n}return r}
function verify(hashHex,r,s,Q){
  if(r<=0n||r>=N||s<=0n||s>=N)return false;
  var w=inv(s,N),z=BigInt('0x'+hashHex),u1=mod(z*w,N),u2=mod(r*w,N),R=add(mul(u1,[GX,GY]),mul(u2,Q));
  return !!R&&mod(R[0],N)===r;
}
function b64uToBytes(s){s=String(s).replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';var bin=atob(s),u=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u}
function bytesToBig(u,a,b){var h='';for(var i=a;i<b;i++)h+=(u[i]<16?'0':'')+u[i].toString(16);return BigInt('0x'+(h||'0'))}
function parseDER(sig){
  var i=0;if(sig[i++]!==0x30)throw new Error('der');
  var len=sig[i++];if(len&0x80)i+=len&0x7f;
  if(sig[i++]!==0x02)throw new Error('der');var rl=sig[i++],r0=i;i+=rl;
  if(sig[i++]!==0x02)throw new Error('der');var sl=sig[i++],s0=i;
  return [bytesToBig(sig,r0,r0+rl),bytesToBig(sig,s0,s0+sl)];
}
function pubPoint(){var u=b64uToBytes(PUB_B64.replace(/\+/g,'-').replace(/\//g,'_'));var o=u.length-65;if(u[o]!==4)throw new Error('chave');return [bytesToBig(u,o+1,o+33),bytesToBig(u,o+33,o+65)]}

/* ---------- estado local ---------- */
/* No programa instalado (Electron), o ID vem do identificador da máquina e uma cópia do estado fica fora do armazenamento do app
   (assim "limpar dados" não zera o teste). No navegador, usa um ID aleatório guardado no localStorage. */
var DK=window.RMDesktop||null;
function machineId12(){try{if(DK&&DK.machineId){var g=DK.machineId();if(g)return RM.sha256('RMPC|'+String(g).toLowerCase()).slice(0,12).toUpperCase()}}catch(e){}return null}
function load(){
  var st={};try{st=JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){st={}}
  if(DK&&DK.shadowRead){try{
    var sh=JSON.parse(DK.shadowRead()||'{}')||{};
    if(sh.trialStart&&(!st.trialStart||sh.trialStart<st.trialStart))st.trialStart=sh.trialStart;
    if((sh.lastSeen||0)>(st.lastSeen||0))st.lastSeen=sh.lastSeen;
    if(sh.clockFlag)st.clockFlag=true;
    if(!st.code&&sh.code)st.code=sh.code;
    if(!st.id&&sh.id)st.id=sh.id;
  }catch(e){}}
  return st;
}
function save(st){try{localStorage.setItem(KEY,JSON.stringify(st))}catch(e){}if(DK&&DK.shadowWrite){try{DK.shadowWrite(JSON.stringify(st))}catch(e){}}}
function rnd12(){var s='',h='0123456789ABCDEF',i;try{var a=new Uint8Array(6);crypto.getRandomValues(a);for(i=0;i<6;i++)s+=(a[i]<16?'0':'')+a[i].toString(16)}catch(e){for(i=0;i<12;i++)s+=h[Math.floor(Math.random()*16)]}return s.toUpperCase().slice(0,12)}
function state(){var st=load(),mid=machineId12(),ch=false;if(mid&&st.id!==mid){st.id=mid;ch=true}if(!st.id){st.id=rnd12();ch=true}if(ch)save(st);return st}
function pretty(raw){return raw.slice(0,4)+'-'+raw.slice(4,8)+'-'+raw.slice(8,12)}
function touchClock(st){var real=Date.now(),last=st.lastSeen||0;if(last>0&&real<last-DAY)st.clockFlag=true;if(real>last)st.lastSeen=real;save(st);return Math.max(real,last)}

/* Retorna fim da validade (ms) se autêntico e deste computador; -1 inválido; -2 outro computador; -3 tipo de código errado */
function checkCode(code,prefix,st){
  try{
    if(!code)return -1;
    var c=String(code).replace(/\s+/g,''),dot=c.indexOf('.');if(dot<=0||dot>=c.length-1)return -1;
    var pb=b64uToBytes(c.slice(0,dot)),sig=parseDER(b64uToBytes(c.slice(dot+1))),payload='';
    for(var i=0;i<pb.length;i++)payload+=String.fromCharCode(pb[i]);
    if(!verify(RM.sha256(payload),sig[0],sig[1],pubPoint()))return -1;
    var parts=payload.split('|');if(parts.length!==3)return -1;
    if(parts[0]!==prefix)return ['RM1','RMPC','RMPIN'].indexOf(parts[0])>-1?-3:-1;
    if(parts[1].toUpperCase()!==st.id.toUpperCase())return -2;
    var d=parts[2];if(!/^\d{8}$/.test(d))return -1;
    return new Date(+d.slice(0,4),+d.slice(4,6)-1,+d.slice(6,8),23,59,59).getTime();
  }catch(e){return -1}
}
function pad(n){return String(n).padStart(2,'0')}

window.AndroidLicense={
  getDeviceId:function(){return pretty(state().id)},
  getAppVersion:function(){return RM.VERSION},
  activate:function(code){
    var st=state(),r=checkCode(code,'RMPC',st),msg;
    if(r===-2)msg='Este código é de outro computador. Envie ao administrador o ID mostrado nesta tela.';
    else if(r===-3)msg='Este código não é de licença da versão para COMPUTADOR. Peça o código correto ao administrador.';
    else if(r<0)msg='Código inválido. Confira se copiou o código inteiro.';
    if(msg)return JSON.stringify({ok:false,message:msg});
    var now=touchClock(st);if(r<now)return JSON.stringify({ok:false,message:'Este código já venceu. Peça um código novo ao administrador.'});
    var old=st.code?checkCode(st.code,'RMPC',st):-1;
    if(old>r)return JSON.stringify({ok:true,message:'Seu acesso já está ativo até uma data posterior.'});
    st.code=String(code).replace(/\s+/g,'');save(st);
    return JSON.stringify({ok:true,message:'Ativado com sucesso!'});
  },
  verifyPinReset:function(code){var st=state(),e=checkCode(code,'RMPIN',st);return e>0&&touchClock(st)<=e},
  getTrialStatus:function(){
    try{
      var st=state(),real=Date.now();
      if(!st.trialStart){st.trialStart=real;st.lastSeen=real;save(st)}
      var now=touchClock(st),elapsed=Math.max(0,now-st.trialStart),remaining=Math.max(0,TRIAL_MS-elapsed);
      var trialActive=!st.clockFlag&&elapsed<TRIAL_MS;
      var exp=st.code?checkCode(st.code,'RMPC',st):-1,had=exp>0,licensed=had&&now<=exp;
      var mode=licensed?'licensed':(trialActive?'trial':'expired');
      var days=licensed?Math.floor((exp-now+DAY-1)/DAY):Math.floor((remaining+DAY-1)/DAY);
      var r={active:licensed||trialActive,mode:mode,hadLicense:had,remainingDays:(licensed||trialActive)?days:0,trialDays:TRIAL_DAYS,trialStart:st.trialStart,deviceId:pretty(st.id)};
      if(had){var c=new Date(exp);r.licenseYear=c.getFullYear();r.licenseDate=pad(c.getDate())+'/'+pad(c.getMonth()+1)+'/'+c.getFullYear()}
      return JSON.stringify(r);
    }catch(e){return JSON.stringify({active:false,mode:'expired',remainingDays:0,trialDays:TRIAL_DAYS,deviceId:''})}
  }
};
RM._pcLic={checkCode:checkCode,verify:verify,state:state};
})();

package br.com.ronielsonmotos.oficina;

import com.journeyapps.barcodescanner.CaptureActivity;

/** Activity dedicada ao leitor embutido para evitar depender de um app externo. */
public class BarcodeCaptureActivity extends CaptureActivity {
}

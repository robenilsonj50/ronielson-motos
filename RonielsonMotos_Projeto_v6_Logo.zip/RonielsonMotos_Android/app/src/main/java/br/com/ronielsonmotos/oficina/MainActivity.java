package br.com.ronielsonmotos.oficina;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.content.pm.PackageManager;
import android.Manifest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.graphics.Color;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.json.JSONObject;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 7821;
    private static final long TRIAL_MILLIS = 30L * 24L * 60L * 60L * 1000L;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,16,32));
        getWindow().setNavigationBarColor(Color.rgb(11,16,32));
        webView = new WebView(this); webView.setBackgroundColor(Color.rgb(11,16,32));
        WebSettings settings=webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new BackupBridge(this),"AndroidBackup");
        webView.addJavascriptInterface(new ScannerBridge(this),"AndroidScanner");
        webView.addJavascriptInterface(new LicenseBridge(this),"AndroidLicense");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(PermissionRequest request){ runOnUiThread(()->{ boolean camera=false; for(String resource:request.getResources()){if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource))camera=true;} if(camera && checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}); else request.deny(); }); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null)filePathCallback.onReceiveValue(null); filePathCallback=callback;
                Intent intent=new Intent(Intent.ACTION_GET_CONTENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json");
                try{startActivityForResult(Intent.createChooser(intent,"Selecionar backup JSON"),FILE_CHOOSER_REQUEST);}catch(Exception e){filePathCallback=null;Toast.makeText(MainActivity.this,"Não foi possível abrir os arquivos.",Toast.LENGTH_LONG).show();return false;} return true;
            }
        }); setContentView(webView); if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_REQUEST); webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        IntentResult scanResult=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if(scanResult!=null){
            String value=scanResult.getContents();
            if(value!=null && webView!=null){
                String escaped=JSONObject.quote(value);
                webView.evaluateJavascript("window.onNativeBarcodeScanned && window.onNativeBarcodeScanned("+escaped+")",null);
            } else if(webView!=null){webView.evaluateJavascript("window.onNativeBarcodeCancelled && window.onNativeBarcodeCancelled()",null);}
        }
        if(requestCode==FILE_CHOOSER_REQUEST&&filePathCallback!=null){Uri[] results=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)results=new Uri[]{data.getData()};filePathCallback.onReceiveValue(results);filePathCallback=null;}
    }

    private static final int CAMERA_PERMISSION_REQUEST = 913;
    private boolean pendingScan = false;

    private void notifyScanCancelled(){
        if(webView!=null)webView.evaluateJavascript("window.onNativeBarcodeCancelled && window.onNativeBarcodeCancelled()",null);
    }

    private void launchScanner(){
        try{
            IntentIntegrator integrator=new IntentIntegrator(this);
            integrator.setCaptureActivity(BarcodeCaptureActivity.class);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
            integrator.setPrompt("Aponte a câmera para o código de barras");
            integrator.setCameraId(0); integrator.setBeepEnabled(false); integrator.setBarcodeImageEnabled(false);
            integrator.setOrientationLocked(false); integrator.initiateScan();
        }catch(Throwable t){
            Toast.makeText(this,"Não foi possível abrir o leitor: "+t.getMessage(),Toast.LENGTH_LONG).show();
            notifyScanCancelled();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode!=CAMERA_PERMISSION_REQUEST)return;
        boolean granted=grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED;
        if(pendingScan){
            pendingScan=false;
            if(granted){launchScanner();}
            else{Toast.makeText(this,"Permissão da câmera negada. Ative em Configurações > Apps > Ronielson Motos > Permissões, ou digite o código.",Toast.LENGTH_LONG).show();notifyScanCancelled();}
        }
    }

    public class ScannerBridge {
        private final Activity activity; ScannerBridge(Activity a){activity=a;}
        @JavascriptInterface public void scan(String target){runOnUiThread(()->{
            if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED){launchScanner();}
            else{pendingScan=true;requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION_REQUEST);}
        });}
    }

    public class LicenseBridge {
        private final Context context; LicenseBridge(Context c){context=c;}
        @JavascriptInterface public String getTrialStatus(){
            long now=System.currentTimeMillis(); android.content.SharedPreferences p=context.getSharedPreferences("ronielson_license",Context.MODE_PRIVATE);
            long start=p.getLong("trial_start",0L), last=p.getLong("last_seen",0L); boolean rollback=last>0L&&now<last-24L*60L*60L*1000L;
            if(start==0L){start=now;p.edit().putLong("trial_start",start).putLong("last_seen",now).apply();}else{if(rollback)p.edit().putBoolean("expired_by_clock_change",true).apply();if(now>last)p.edit().putLong("last_seen",now).apply();}
            boolean expired=p.getBoolean("expired_by_clock_change",false);long elapsed=Math.max(0L,now-start),remaining=Math.max(0L,TRIAL_MILLIS-elapsed);boolean active=!expired&&elapsed<TRIAL_MILLIS;long days=(remaining+86400000L-1L)/86400000L;
            try{JSONObject r=new JSONObject();r.put("active",active);r.put("remainingDays",days);r.put("trialDays",30);r.put("trialStart",start);return r.toString();}catch(Exception e){return "{\"active\":false,\"remainingDays\":0,\"trialDays\":30}";}
        }
    }
    public class BackupBridge {
        private final Context context; BackupBridge(Context c){context=c;}
        @JavascriptInterface public void saveBackup(String json,String filename){runOnUiThread(()->{OutputStream output=null;try{
            String safe=filename==null?"backup-ronielson-motos.json":filename.replaceAll("[^a-zA-Z0-9._-]","_");
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,safe);values.put(MediaStore.Downloads.MIME_TYPE,"application/json");values.put(MediaStore.Downloads.RELATIVE_PATH,"Download");values.put(MediaStore.Downloads.IS_PENDING,1);Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("Não foi possível criar o arquivo.");output=getContentResolver().openOutputStream(uri);if(output==null)throw new IOException("Não foi possível gravar o arquivo.");output.write(json.getBytes("UTF-8"));output.flush();output.close();output=null;ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,done,null,null);
            }else{File dir=getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);if(dir==null)throw new IOException("Pasta de downloads indisponível.");output=new FileOutputStream(new File(dir,safe));output.write(json.getBytes("UTF-8"));output.flush();output.close();output=null;}
            Toast.makeText(context,"Backup salvo em Downloads: "+safe,Toast.LENGTH_LONG).show();
        }catch(Exception e){try{if(output!=null)output.close();}catch(Exception ignored){}Toast.makeText(context,"Falha ao salvar backup: "+e.getMessage(),Toast.LENGTH_LONG).show();}});}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
